#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test
while IFS= read -r -d '' f; do
  swiftc -frontend -parse "$f" >/dev/null
done < <(find iOSApp Sources/RiderWiseCore -type f -name '*.swift' -print0)
python3 - <<'PY'
import gzip, json, pathlib, plistlib, collections
root=pathlib.Path('.')
plist=plistlib.loads((root/'iOSApp/Info.plist').read_bytes())
ent=plistlib.loads((root/'iOSApp/RiderWiseAI.entitlements').read_bytes())
assert plist.get('NSScreenCaptureUsageDescription')
assert 'screen-capture' in plist.get('UIBackgroundModes', [])
assert 'audio' in plist.get('UIBackgroundModes', [])
project=(root/'project.yml').read_text()
assert 'CODE_SIGN_ENTITLEMENTS: iOSApp/RiderWiseAI.entitlements' in project
assert ent.get('com.apple.developer.screen-recording') is True
assert 'RiderWiseAI.entitlements' in project
assert 'RiderWiseBroadcast:' not in project
assert 'iOS: "27.0"' in project
assert 'exactVersion: 0.18.0' in project
assert 'from: 0.18.0' not in project
capture=(root/'iOSApp/ScreenCaptureManager.swift').read_text()
app=(root/'iOSApp/RiderWiseApp.swift').read_text()
ocr=(root/'Sources/RiderWiseCore/OCRParser.swift').read_text()
engine=(root/'Sources/RiderWiseCore/RecommendationEngine.swift').read_text()
pip=(root/'iOSApp/PiPVideoRenderer.swift').read_text()
assert 'import ScreenCaptureKit' in capture
assert 'SCContentSharingPicker.shared' in capture
assert 'picker.present()' in capture
assert 'picker.isActive = true' in capture
assert 'pickerConfiguration.allowedPickerModes' not in capture
assert 'pickerConfiguration.showsMicrophoneControl = false' in capture
for unavailable_api in ['pickerConfiguration.allowsChangingSelectedContent =',
                        'picker.maximumStreamCount =',
                        'configuration.minimumFrameInterval =']:
    assert unavailable_api not in capture, f'iOS-unavailable ScreenCaptureKit API found: {unavailable_api}' 
assert capture.index('picker.isActive = true') < capture.index('picker.present()')
assert 'nanoseconds: 900_000_000' not in capture
assert 'picker.present(using: .display)' not in capture
assert 'VNRecognizeTextRequest' in capture
assert 'max(1.5, scanInterval)' in capture
assert 'TimeInterval = 1.5' in capture
assert 'configuration.width = 1284' in capture and 'configuration.height = 2778' in capture
assert 'configuration.queueDepth' not in capture
assert 'startFrameWatchdog()' in capture and 'handleMissingFrames(age: age)' in capture
assert 'lastFrameUptime' in capture and 'NO SCREEN FRAMES' in capture
assert 'ocrQueue.async' in capture
assert 'activeStreamIdentifier' in capture and 'ObjectIdentifier(nextStream)' in capture
assert 'let streamID = ObjectIdentifier(stream)' in capture
assert 'SCContentSharingPicker.shared.isActive = false' in capture
assert 'isOCRInFlight' in capture
assert 'self.stream === stream' in capture
assert 'isStarting = true' in capture
assert 'AcceptedBookingDetector.detect(lines: cleanLines' in app
assert 'accepted.matchedPreAcceptanceBookingID.flatMap' in app
assert 'referenceWasExplicitlyCleared' in app
assert 'explicitlyClearedReferenceID' in app
assert 'AcceptedBookingReferenceSelection.firstEligible' in app
assert 'referenceWasExplicitlyCleared && explicitlyClearedReferenceID == nil' in app
assert 'AcceptedBookingReferenceRecovery.recover' in app
assert 'isPostalRegionContinuation' in ocr
assert '"ride","photos","ride photos"' in ocr
assert 'referenceSnapshot' in app
assert 'explainEmptyReferenceBased' in app
assert 'Date.now.addingTimeInterval(-24*60*60)' in app
assert 'capture.hasRecentFrames' in app
assert 'scanStatus:' in app
assert 'recommendationLines: store.recommendations.prefix(3)' in app
assert 'recommendationLines: [String] = []' in pip
assert 'SAVED COMPATIBLE BOOKINGS' in pip
assert 'candidate.status != .delivered,candidate.status != .stale' in engine
assert 'Always retain every individually compatible booking' in engine
assert 'lhsFirstSeen' in app
assert 'No compatible booking yet' in app
assert 'Latest: \(latest.pickup' not in app
assert 'recommendationStatus' in app
assert 'onDashboardStateChanged' in app
assert 'store.onDashboardStateChanged = { [weak store, weak capture, weak pipRenderer]' in app
assert 'capture.isAppForeground' in app
assert 'RIDERWISE IS OPEN — switch to Lalamove' in app
assert 'incompleteVisibleCandidates' in app
assert 'Date.now.addingTimeInterval(-24*60*60)' in app
assert (root/'iOSApp/Assets.xcassets/AppIcon.appiconset/AppIcon.png').is_file()
assert (root/'.github/workflows/ios-device-build.yml').is_file()
workflow=(root/'.github/workflows/ios-device-build.yml').read_text()
assert 'com.apple.developer.screen-recording' in workflow
assert 'NSScreenCaptureUsageDescription' in workflow
assert 'screen-capture' in workflow
assert 'IPA_LIMIT_BYTES=25000000' in workflow
assert "RiderWiseAI_iOS_3.5.0*.zip" in workflow
assert 'RiderWiseAI_iOS_3.4.9*.zip' not in workflow
assert 'MARKETING_VERSION: \"3.5.0\"' in workflow
assert 'RiderWiseAI-3.5.0-unsigned.ipa' in workflow
assert 'RiderWiseAI-3.5.0.xcarchive.zip' in workflow
assert 'hasAcceptedReference' in pip
assert 'POTENTIAL ROUTE COMPARISONS · NO REFERENCE SELECTED' in pip
assert 'picker.isActive = false' in capture
assert 'AcceptedBookingReferenceSelection.firstEligible' in app
assert 'referenceWasExplicitlyCleared && explicitlyClearedReferenceID == nil' in app
assert 'explicitlyClearedReferenceID' in app
assert 'AcceptedBookingReferenceSelection' in (root/'Sources/RiderWiseCore/AcceptedBookingReference.swift').read_text()
assert 'testNextDistinctAcceptedBookingCanBecomeReferenceAfterManualClear' in (root/'Tests/RiderWiseCoreTests/CoreTests.swift').read_text()
assert 'zip -qry -9' in workflow
assert len(list((root/'.github/workflows').glob('*.yml'))) == 1, 'Expected one combined GitHub Actions workflow'
assert 'import ReplayKit' not in capture
assert '- sdk: ScreenCaptureKit.framework' not in project
assert 'OTHER_LDFLAGS[sdk=iphoneos*]' in project
assert not (root/'BroadcastExtension').exists()
geo=root/'Sources/RiderWiseCore'
for name in ['luzon_psgc_3q_2026.json','luzon_psgc_3q_2026.json.gz','geographic_centroids_legacy.json','riderwise_upgrade_config.json']:
    assert (geo/name).is_file(), f'Missing canonical RiderWiseCore geography resource: {name}'
assert not (root/'iOSApp/Resources/Geography').exists(), 'Duplicate app-bundle geography resources should not be packaged.'
assert 'iOSApp/Resources/Geography' not in project, 'Duplicate app resource copy would inflate the IPA.'
with gzip.open(root/'Sources/RiderWiseCore/luzon_psgc_3q_2026.json.gz','rt',encoding='utf-8') as f:
    data=json.load(f)
records=data['records']
codes={r['psgc'] for r in records}
counts=collections.Counter(r['level'] for r in records)
assert len(records)==21330 and len(codes)==len(records)
assert dict(counts)=={'Reg':8,'Prov':38,'City':77,'Mun':694,'SubMun':14,'Bgy':20499}
assert all(not r.get('parentPsgc') or r['parentPsgc'] in codes for r in records)
config=json.loads((geo/'riderwise_upgrade_config.json').read_text())
assert config['scan']['interval_ms']==1500
assert config['safety']['auto_accept_bookings'] is False
assert config['safety']['auto_reject_bookings'] is False
assert config['ai']['large_local_model_autostart'] is False
pip=(root/'iOSApp/PiPVideoRenderer.swift').read_text()
assert 'displayLayer.enqueue(sample)' in pip
assert 'activatePiPAudioSession()' in pip
assert 'setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])' in pip
assert 'setActive(true)' in pip
assert 'CMSetAttachment(' in pip and 'kCMSampleAttachmentKey_DisplayImmediately' in pip
assert 'receiver.enqueue' not in pip
assert '.onChange(of: pipFrameRevision)' in app
assert 'store.rideMode ? "ride-on" : "ride-off"' in app
assert 'store.bookings.map' in app
assert 'PiP frame enqueue failed: \\(error.localizedDescription)' not in pip
print('iOS-compatible ScreenCaptureKit picker activation, native iOS picker configuration, capture path, permission declaration and no-extension architecture: PASS')
print('PiP frame delivery: synchronous display-layer enqueue; no cancellable receiver task: PASS')
print('PiP background audio capability and activation: PASS')
print('Geographic resources: PASS')
print('PSGC dataset: PASS (21,330 records, unique codes, valid parent links)')
PY

# 3.4.5 capture, OCR, reference, and recommendation regression checks
python3 - <<'PY'
from pathlib import Path
import json
root=Path('.')
capture=(root/'iOSApp/ScreenCaptureManager.swift').read_text()
app=(root/'iOSApp/RiderWiseApp.swift').read_text()
project=(root/'project.yml').read_text()
config=json.loads((root/'Sources/RiderWiseCore/riderwise_upgrade_config.json').read_text())
ocr=(root/'Sources/RiderWiseCore/OCRParser.swift').read_text()
engine=(root/'Sources/RiderWiseCore/RecommendationEngine.swift').read_text()
route=(root/'Sources/RiderWiseCore/RouteCompatibility.swift').read_text()
matcher=(root/'Sources/RiderWiseCore/BookingMatcher.swift').read_text()
pip=(root/'iOSApp/PiPVideoRenderer.swift').read_text()
assert 'captureWasActiveKey' in capture
assert 'requiresReauthorization' in capture
assert 'Previous screen scan ended when RiderWise closed' in capture
assert 'refreshAfterForeground()' in capture
assert 'Tap Start authorized screen scan' in capture
assert 'scenePhase' in app and 'capture.refreshAfterForeground()' in app
assert 'riderwise.rideMode' in app
assert 'store.setRideMode(!store.rideMode)' in app
assert 'SCREEN SCAN NEEDS NEW iOS APPROVAL' in app
assert 'MARKETING_VERSION: "3.5.0"' in project
assert 'CURRENT_PROJECT_VERSION: "350"' in project
assert config['scan']['interval_ms']==1500
assert 'TimeInterval = 1.5' in capture
assert 'configuration.width = 1284' in capture and 'configuration.height = 2778' in capture
assert 'configuration.queueDepth' not in capture
assert 'startFrameWatchdog()' in capture and 'handleMissingFrames(age: age)' in capture
assert 'lastFrameUptime' in capture and 'NO SCREEN FRAMES' in capture
assert 'ocrQueue.async' in capture
assert 'activeStreamIdentifier' in capture and 'ObjectIdentifier(nextStream)' in capture
assert 'let streamID = ObjectIdentifier(stream)' in capture
assert 'SCContentSharingPicker.shared.isActive = false' in capture
assert 'isOCRInFlight' in capture
assert 'self.stream === stream' in capture
assert 'isStarting = true' in capture
assert 'AcceptedBookingDetector.detect(lines: cleanLines' in app
assert 'referenceSnapshot' in app
assert 'explainEmptyReferenceBased' in app
assert 'Date.now.addingTimeInterval(-24*60*60)' in app
assert 'capture.hasRecentFrames' in app
assert 'scanStatus:' in app
assert 'recommendationLines: store.recommendations.prefix(3)' in app
assert 'recommendationLines: [String] = []' in pip
assert 'SAVED COMPATIBLE BOOKINGS' in pip
assert 'candidate.status != .delivered,candidate.status != .stale' in engine
assert 'Always retain every individually compatible booking' in engine
assert 'lhsFirstSeen' in app
assert 'No compatible booking yet' in app
assert 'Latest: \(latest.pickup' not in app
assert 'recommendationStatus' in app
assert 'Date.now.addingTimeInterval(-24*60*60)' in app
assert (root/'iOSApp/Assets.xcassets/AppIcon.appiconset/AppIcon.png').is_file()
assert (root/'.github/workflows/ios-device-build.yml').is_file()
workflow=(root/'.github/workflows/ios-device-build.yml').read_text()
assert 'com.apple.developer.screen-recording' in workflow
assert 'NSScreenCaptureUsageDescription' in workflow
assert 'screen-capture' in workflow
assert 'removeRiderWiseOverlay(from lines:[OCRLine])' in ocr
assert 'testAcceptedScreenRejectsRideAndPhotosAsEndpointLabels' in (root/'Tests/RiderWiseCoreTests/CoreTests.swift').read_text()
assert 'testPostalCodeRegionWrappedLineStaysWithDropoffAddress' in (root/'Tests/RiderWiseCoreTests/CoreTests.swift').read_text()
assert 'testPersistedAcceptedHistoryRecoversFirstAcceptedReference' in (root/'Tests/RiderWiseCoreTests/CoreTests.swift').read_text()
assert 'guard match.feasible else { return nil }' in engine
assert 'pickupDeviation<=10 && dropDeviation<=10' in route
assert 'record.level != "Prov"' in engine and 'record.level != "Reg"' in engine
assert 'hasAddressContext' in matcher
assert 'persistAsync()' in app and 'persistenceQueue.sync' in app
assert 'ScreenCaptureKit active' in capture or 'LIVE SCREEN FRAMES' in capture
assert 'Vision OCR target %.1f seconds' in capture
assert 'let riderWiseIsForeground = UIApplication.shared.applicationState == .active' in capture
assert 'if riderWiseIsForeground && !lalamoveVisible' in capture
assert 'LalamoveOCRParser.hasLalamoveScreenEvidence(lines)' in capture
assert 'PiP can keep RiderWise\'s process active while Lalamove is the' in capture
assert 'displayLayer.flush()' in (root/'iOSApp/PiPVideoRenderer.swift').read_text()
assert 'status.contains("NO SCREEN FRAMES")' in app
print('3.5.0 capture watchdog, full-display picker, accepted-booking pipeline, reference snapshot, OCR filtering, geographic feasibility, and 1.5s OCR checks: PASS')
PY
