# RiderWise AI iOS 3.4.5 — Full Pipeline Repair

This source revision audits and repairs the iOS 27+ ScreenCaptureKit, OCR, booking, geographic recommendation, and native PiP pipeline. It retains the existing SwiftUI application and deterministic offline recommendation engine.

## Release changes

- Full-display-only ScreenCaptureKit picker; app/window capture is disabled.
- Apple screen-recording entitlement is wired into the iOS target, alongside the screen-capture background mode and usage description.
- Actual first-frame detection, active-stream identity protection, a six-second no-frame watchdog, and one automatic in-session recovery attempt.
- Separate serial Vision OCR queue with in-flight backpressure; OCR target interval is 1.5 seconds and capture is capped at 5 fps.
- PiP distinguishes `SCAN PAUSED`, `NO FRAMES`, `LIVE FRAMES`, and `LIVE OCR`.
- RiderWise PiP text is filtered out before Lalamove OCR parsing.
- Accepted-booking evidence is connected to live ingestion without double-counting the same card.
- Persistent accepted-reference snapshot survives booking-history pruning.
- Recommendation candidates must be complete, visible, and seen within 45 seconds.
- Exact locality centroids are preferred; province-only destinations are rejected. All legacy centroids remain approximate and require address verification.
- Both pickup and drop-off must pass route-corridor and direction checks. Approximate geographic recommendation scores are capped at 59%.
- Scheduled booking headers, leading OCR `O`/`0` noise, and bare-locality duplicate collisions are handled.
- Existing 2.5-second saved scan settings migrate once to 1.5 seconds.

## Validation

- **48 Swift core tests passed.**
- **20 iOS app/core Swift files parsed with no syntax errors.**
- Portable source audit passed.
- Luzon PSGC resource: 21,330 records with unique codes and valid parent links.
- GitHub workflow performs an iOS Simulator build and an unsigned iOS device archive using Xcode 27.

This environment does not include Xcode or a physical iPhone, so the iOS app target has not yet been type-checked/linked here and ScreenCaptureKit/PiP behavior has not been verified on the iPhone 13 Pro Max. The cloud Xcode workflow and physical-device test are still required.

## GitHub Actions build

1. Upload `RiderWiseAI_iOS_3.4.5_FullPipelineRepair_1p5sOCR_GitHub.zip` to the repository root.
2. Upload `riderwise-3.4.5-full-pipeline-repair.yml` into `.github/workflows/`.
3. Commit both files.
4. Open **Actions** and run **RiderWise AI 3.4.5 - Full Capture, OCR & Recommendation Repair**.
5. Download the Simulator/device logs and unsigned IPA from the workflow artifacts.

The source ZIP is under GitHub's 25 MB upload limit. The workflow's IPA is **unsigned**; it still needs valid Apple signing/provisioning before installation. iOS also requires the rider to approve a fresh full-display sharing session after RiderWise is force-closed; the app cannot silently restore that authorization.

## Architecture notes

- `Sources/RiderWiseCore/` contains portable booking, OCR parsing, PSGC/centroid resolution, recommendation, queue, profit, and diagnostic logic.
- `iOSApp/` contains SwiftUI, Vision OCR, ScreenCaptureKit capture, AVKit PiP, and optional LiteRT-LM offline AI.
- `Tests/RiderWiseCoreTests/` contains portable regression tests.
- `.github/workflows/riderwise-3.4.5-full-pipeline-repair.yml` builds with Xcode 27.

Geographic matching is a provisional straight-line estimate using legacy approximate centroids, not road routing, traffic, or ETA. Every candidate still requires the driver to verify full addresses and confirm the booking.
