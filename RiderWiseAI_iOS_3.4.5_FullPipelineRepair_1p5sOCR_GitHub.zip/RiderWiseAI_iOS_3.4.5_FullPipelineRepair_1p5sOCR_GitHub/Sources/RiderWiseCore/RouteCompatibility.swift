import Foundation
public struct GeoPoint:Codable,Hashable,Sendable { public let latitude:Double; public let longitude:Double; public init(latitude:Double,longitude:Double){self.latitude=latitude;self.longitude=longitude} }
public enum GeoMath {
    public static func distanceKm(_ a:GeoPoint,_ b:GeoPoint)->Double {
        let r=6371.0,p1=a.latitude * .pi/180,p2=b.latitude * .pi/180
        let dp=(b.latitude-a.latitude) * .pi/180,dl=(b.longitude-a.longitude) * .pi/180
        let h=pow(sin(dp/2),2)+cos(p1)*cos(p2)*pow(sin(dl/2),2)
        return 2*r*atan2(sqrt(h),sqrt(max(0,1-h)))
    }
    /// The Android source's progress/deviation estimate: excess path length divided by two.
    public static func progress(_ start:GeoPoint,_ end:GeoPoint,_ point:GeoPoint)->Double {
        let total=distanceKm(start,end)
        guard total>0,total.isFinite else{return .nan}
        return (distanceKm(start,point)+distanceKm(point,end)-total)/2
    }
}
public struct RouteMatch:Sendable {
    public let label:String
    public let score:Double
    public let deviationKm:Double?
    public let basis:String
    public let requiresVerification:Bool
    public let feasible:Bool
    public let usesParentLocalityFallback:Bool
    public init(label:String,score:Double,deviationKm:Double?,basis:String,requiresVerification:Bool,
                feasible:Bool=false,usesParentLocalityFallback:Bool=false) {
        self.label=label;self.score=score;self.deviationKm=deviationKm;self.basis=basis
        self.requiresVerification=requiresVerification;self.feasible=feasible
        self.usesParentLocalityFallback=usesParentLocalityFallback
    }
}
public enum RouteCompatibilityEngine {
    public static let basis="STRAIGHT-LINE GEOGRAPHIC ESTIMATE; NOT ROAD ROUTING, TRAFFIC OR ETA"
    public static let parentFallbackBasis="CITY-LEVEL STRAIGHT-LINE ESTIMATE; BARANGAY RESOLVED TO PARENT CITY; NOT BARANGAY-LEVEL OR ROAD ROUTING"
    public static func evaluate(referencePickup:GeoPoint?,referenceDropoff:GeoPoint?,candidatePickup:GeoPoint?,candidateDropoff:GeoPoint?,
                                usesParentLocalityFallback:Bool=false)->RouteMatch {
        let estimateBasis=usesParentLocalityFallback ? parentFallbackBasis : basis
        let suffix=usesParentLocalityFallback ? " (CITY-LEVEL APPROX.)" : ""
        guard let start=referencePickup,let end=referenceDropoff,let pickup=candidatePickup,let drop=candidateDropoff else {
            return RouteMatch(label:"POSSIBLE COMPATIBILITY"+suffix,score:0.25,deviationKm:nil,basis:estimateBasis,requiresVerification:true,feasible:false,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        let routeLength=GeoMath.distanceKm(start,end)
        let pickupDeviation=GeoMath.progress(start,end,pickup)
        let dropDeviation=GeoMath.progress(start,end,drop)
        let pickupProgress=GeoMath.distanceKm(start,pickup)
        let dropProgress=GeoMath.distanceKm(start,drop)
        let candidateLength=GeoMath.distanceKm(pickup,drop)
        let deviation=max(pickupDeviation,dropDeviation)
        guard routeLength.isFinite,candidateLength.isFinite,routeLength>=0.1 else {
            return RouteMatch(label:"POSSIBLE COMPATIBILITY"+suffix,score:0.2,deviationKm:nil,basis:estimateBasis,requiresVerification:true,feasible:false,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        if candidateLength>60 || pickupProgress>max(65,routeLength+35) {
            return RouteMatch(label:"INCOMPATIBLE"+suffix,score:0.03,deviationKm:deviation,basis:estimateBasis,requiresVerification:true,feasible:false,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        if dropProgress+3<pickupProgress {
            return RouteMatch(label:"REVERSE DIRECTION"+suffix,score:0.10,deviationKm:deviation,basis:estimateBasis,requiresVerification:true,feasible:false,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        if pickupProgress>routeLength+20 || pickupDeviation>20 || dropDeviation>25 {
            return RouteMatch(label:"EXCESSIVE BACKTRACKING"+suffix,score:0.08,deviationKm:deviation,basis:estimateBasis,requiresVerification:true,feasible:false,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        if pickupDeviation<=2 && dropDeviation<=2 {
            return RouteMatch(label:"SAME ROUTE"+suffix,score:0.95,deviationKm:deviation,basis:estimateBasis,requiresVerification:true,feasible:true,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        if pickupDeviation<=5 && dropDeviation<=7 {
            return RouteMatch(label:"ALONG THE WAY"+suffix,score:0.82,deviationKm:deviation,basis:estimateBasis,requiresVerification:true,feasible:true,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        if pickupDeviation<=10 && dropDeviation<=10 {
            return RouteMatch(label:"NEAR THE ROUTE"+suffix,score:0.60,deviationKm:deviation,basis:estimateBasis,requiresVerification:true,feasible:true,usesParentLocalityFallback:usesParentLocalityFallback)
        }
        return RouteMatch(label:"POSSIBLE COMPATIBILITY"+suffix,score:0.30,deviationKm:deviation,basis:estimateBasis,requiresVerification:true,feasible:false,usesParentLocalityFallback:usesParentLocalityFallback)
    }
    public static func consecutivePair(anchorDropoff:GeoPoint?,candidatePickup:GeoPoint?,candidateDropoff:GeoPoint?)->RouteMatch {
        guard let a=anchorDropoff,let b=candidatePickup,let c=candidateDropoff else {
            return RouteMatch(label:"NEEDS ADDRESS VERIFICATION",score:0.15,deviationKm:nil,basis:basis,requiresVerification:true)
        }
        let gap=GeoMath.distanceKm(a,b),candidateLeg=GeoMath.distanceKm(b,c)
        let label:String,score:Double
        if candidateLeg>60 { label="LONG CANDIDATE LEG — REVIEW"; score=0.05 }
        else if gap<=3 { label="POTENTIAL CONSECUTIVE PAIR"; score=0.65-gap/100 }
        else if gap<=10 { label="POSSIBLE CONSECUTIVE PAIR"; score=0.45-gap/100 }
        else { label="LARGE GAP — REVIEW"; score=max(0.05,0.30-gap/100) }
        return RouteMatch(label:label,score:score,deviationKm:gap,basis:basis,requiresVerification:true)
    }
}
