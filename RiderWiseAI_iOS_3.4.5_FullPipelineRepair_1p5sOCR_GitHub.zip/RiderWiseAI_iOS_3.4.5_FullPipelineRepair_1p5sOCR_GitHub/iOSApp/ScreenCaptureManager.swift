#if targetEnvironment(simulator)
import Foundation
import Combine
import SwiftUI
import RiderWiseCore

/// Simulator-safe stand-in. Full-display capture requires a physical iOS 27+ device.
@MainActor
final class ScreenCaptureManager: ObservableObject {
    @Published private(set) var isCapturing = false
    @Published private(set) var requiresReauthorization = false
    @Published private(set) var hasRecentFrames = false
    @Published private(set) var ocrPassCount = 0
    @Published private(set) var lastOCRLineCount = 0
    @Published private(set) var status = "Screen capture requires a physical iOS 27+ device."
    @Published var scanInterval: TimeInterval = 1.5
    var onOCRLines: (([OCRLine]) async -> Void)?

    func beginMonitoring() {}
    func refreshAfterForeground() {}
    func presentSystemPicker() {
        status = "ScreenCaptureKit full-display capture requires a physical iOS 27+ device."
    }
    func stop() {
        isCapturing = false
        hasRecentFrames = false
        status = "Screen capture is unavailable in the iOS Simulator."
    }
}
#else
import Foundation
import Combine
import SwiftUI
import UIKit
import ScreenCaptureKit
import Vision
import AVFoundation
import CoreMedia
import CoreVideo
import RiderWiseCore

/// User-authorized iOS 27+ full-display capture. No ReplayKit extension is required.
@MainActor
final class ScreenCaptureManager: NSObject, ObservableObject {
    @Published private(set) var isCapturing = false
    @Published private(set) var requiresReauthorization = false
    @Published private(set) var hasRecentFrames = false
    @Published private(set) var ocrPassCount = 0
    @Published private(set) var lastOCRLineCount = 0
    @Published private(set) var status = "Screen capture is off. Tap Start and choose the entire display in Apple's sharing picker."
    @Published var scanInterval: TimeInterval = 1.5 {
        didSet {
            let interval = max(1.5, scanInterval)
            frameQueue.async { [weak self] in self?.currentScanInterval = interval }
            if isCapturing {
                status = String(format: "ScreenCaptureKit active · Vision OCR target %.1f seconds", interval)
            }
        }
    }

    // These values are touched only on frameQueue, never concurrently without queue ordering.
    nonisolated(unsafe) private var currentScanInterval: TimeInterval = 1.5
    nonisolated(unsafe) private var lastOCRUptime: TimeInterval = 0
    nonisolated(unsafe) private var lastFrameUptime: TimeInterval = 0
    nonisolated(unsafe) private var streamStartUptime: TimeInterval = 0
    nonisolated(unsafe) private var didReportFirstFrame = false
    nonisolated(unsafe) private var isOCRInFlight = false
    nonisolated(unsafe) private var activeStreamIdentifier: ObjectIdentifier?
    nonisolated private let frameQueue = DispatchQueue(label: "ph.riderwise.screencapture.frames", qos: .userInitiated)
    nonisolated private let ocrQueue = DispatchQueue(label: "ph.riderwise.screencapture.ocr", qos: .userInitiated)

    var onOCRLines: (([OCRLine]) async -> Void)?

    private let picker = SCContentSharingPicker.shared
    private var stream: SCStream?
    private var activeFilter: SCContentFilter?
    private var isStarting = false
    private var isPickerObserverRegistered = false
    private var isPickerRequestPending = false
    private var watchdogTimer: DispatchSourceTimer?
    private var watchdogRecoveryAttempts = 0
    private let captureWasActiveKey = "ph.riderwise.captureWasActive"

    override init() {
        super.init()
        if UserDefaults.standard.bool(forKey: captureWasActiveKey) {
            requiresReauthorization = true
            status = "Previous screen scan ended when RiderWise closed. Tap Start authorized screen scan and approve the entire display again."
        }
    }

    func beginMonitoring() {
        guard stream == nil, !isCapturing else { return }
        if UserDefaults.standard.bool(forKey: captureWasActiveKey) {
            requiresReauthorization = true
            status = "Screen scan needs a fresh iOS approval. Tap Start authorized screen scan and choose the entire display."
        }
    }

    func refreshAfterForeground() {
        beginMonitoring()
        if isCapturing {
            status = hasRecentFrames
                ? String(format: "LIVE SCREEN FRAMES · Vision OCR target %.1f seconds", max(1.5, scanInterval))
                : "Screen stream is active; waiting for fresh frames…"
        }
    }

    func presentSystemPicker() {
        guard UIApplication.shared.applicationState == .active else {
            status = "Return to RiderWise and tap Start while RiderWise is in the foreground."
            return
        }
        guard picker.isAvailable else {
            status = "Apple's ScreenCaptureKit picker is unavailable on this device or OS version."
            return
        }
        guard !isCapturing, !isStarting, !isPickerRequestPending else {
            status = isCapturing ? "Screen scan is already active." : "Apple's screen-sharing picker is already opening."
            return
        }
        // Restrict the system picker to the full device display before activating it.
        // The default picker also offers app/window capture; choosing those would only
        // capture RiderWise itself and would never deliver the Lalamove screen to OCR.
        var pickerConfiguration = picker.defaultConfiguration
        pickerConfiguration.allowedPickerModes = .singleDisplay
        pickerConfiguration.showsMicrophoneControl = false
        picker.defaultConfiguration = pickerConfiguration
        if !isPickerObserverRegistered {
            picker.add(self)
            isPickerObserverRegistered = true
        }
        picker.isActive = true
        isPickerRequestPending = true
        status = "Opening Apple's sharing picker for the entire display only."
        picker.present()
    }

    func stop() {
        stopFrameWatchdog()
        let streamToStop = stream
        // Detach before awaiting stopCapture so an intentional stop callback cannot
        // overwrite the user-requested stopped state as an interruption.
        stream = nil
        activeFilter = nil
        isCapturing = false
        hasRecentFrames = false
        isStarting = true
        requiresReauthorization = false
        UserDefaults.standard.set(false, forKey: captureWasActiveKey)
        frameQueue.sync {
            activeStreamIdentifier = nil
            isOCRInFlight = false
        }
        guard let streamToStop else {
            isStarting = false
            picker.isActive = false
            status = "Screen capture is already stopped."
            return
        }
        status = "Stopping the authorized screen stream…"
        Task { [weak self] in
            do {
                try await streamToStop.stopCapture()
                await MainActor.run {
                    self?.isStarting = false
                    self?.picker.isActive = false
                    self?.status = "Screen scan stopped."
                }
            } catch {
                await MainActor.run {
                    guard let self else { return }
                    self.isStarting = false
                    self.requiresReauthorization = true
                    UserDefaults.standard.set(true, forKey: self.captureWasActiveKey)
                    self.status = "Could not stop screen capture cleanly: \(error.localizedDescription). Start a fresh authorized session."
                }
            }
        }
    }

    private func startCapture(using filter: SCContentFilter, isRecovery: Bool = false) {
        guard !isStarting else { return }
        isPickerRequestPending = false
        isStarting = true
        stopFrameWatchdog()
        activeFilter = filter
        isCapturing = false
        hasRecentFrames = false
        if !isRecovery { watchdogRecoveryAttempts = 0 }
        status = "Starting the screen stream you approved; waiting for the first frame…"

        Task { [weak self] in
            guard let self else { return }
            var createdStream: SCStream?
            do {
                if let oldStream = self.stream {
                    self.stream = nil
                    self.frameQueue.sync { self.activeStreamIdentifier = nil }
                    try await oldStream.stopCapture()
                }
                let configuration = SCStreamConfiguration()
                // iPhone 13 Pro Max aspect ratio; ScreenCaptureKit scales the selected display.
                configuration.width = 1284
                configuration.height = 2778
                // iOS ScreenCaptureKit does not expose minimumFrameInterval.
                // Keep capture at the system-provided cadence and throttle Vision OCR
                // independently on frameQueue using currentScanInterval (1.5 seconds).
                configuration.queueDepth = 3
                configuration.capturesAudio = false

                let nextStream = SCStream(filter: filter, configuration: configuration, delegate: self)
                createdStream = nextStream
                try nextStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: self.frameQueue)
                // Publish identity before startCapture; the first sample can arrive
                // before startCapture() resumes on the main actor.
                self.stream = nextStream
                self.frameQueue.sync {
                    self.activeStreamIdentifier = ObjectIdentifier(nextStream)
                    self.lastOCRUptime = 0
                    self.lastFrameUptime = 0
                    self.streamStartUptime = ProcessInfo.processInfo.systemUptime
                    self.didReportFirstFrame = false
                    self.isOCRInFlight = false
                    self.currentScanInterval = max(1.5, self.scanInterval)
                }
                self.ocrPassCount = 0
                self.lastOCRLineCount = 0
                try await nextStream.startCapture()
                guard self.stream === nextStream else { return }
                self.isCapturing = true
                self.requiresReauthorization = false
                UserDefaults.standard.set(true, forKey: self.captureWasActiveKey)
                self.status = self.hasRecentFrames
                    ? String(format: "LIVE SCREEN FRAMES · Vision OCR target %.1f seconds", max(1.5, self.scanInterval))
                    : "Screen stream started; waiting for the first delivered frame…"
                self.startFrameWatchdog()
            } catch {
                if let createdStream, self.stream === createdStream {
                    self.stream = nil
                    self.frameQueue.sync {
                        self.activeStreamIdentifier = nil
                        self.isOCRInFlight = false
                    }
                }
                self.stopFrameWatchdog()
                self.activeFilter = nil
                self.isCapturing = false
                self.hasRecentFrames = false
                self.requiresReauthorization = true
                self.picker.isActive = false
                UserDefaults.standard.set(true, forKey: self.captureWasActiveKey)
                self.status = "Screen scan could not start. Re-authorize the entire display and try again: \(error.localizedDescription)"
            }
            self.isStarting = false
        }
    }

    private func startFrameWatchdog() {
        stopFrameWatchdog()
        let timer = DispatchSource.makeTimerSource(queue: frameQueue)
        timer.schedule(deadline: .now() + 2, repeating: 2)
        timer.setEventHandler { [weak self] in
            guard let self else { return }
            let now = ProcessInfo.processInfo.systemUptime
            let reference = self.lastFrameUptime > 0 ? self.lastFrameUptime : self.streamStartUptime
            let age = now - reference
            if age < 6 {
                if now - self.streamStartUptime >= 30 {
                    Task { @MainActor [weak self] in self?.watchdogRecoveryAttempts = 0 }
                }
                return
            }
            Task { @MainActor [weak self] in self?.handleMissingFrames(age: age) }
        }
        watchdogTimer = timer
        timer.resume()
    }

    private func stopFrameWatchdog() {
        watchdogTimer?.setEventHandler {}
        watchdogTimer?.cancel()
        watchdogTimer = nil
    }

    private func handleMissingFrames(age: TimeInterval) {
        guard isCapturing, !isStarting, age >= 6 else { return }
        hasRecentFrames = false
        if watchdogRecoveryAttempts == 0, let filter = activeFilter {
            watchdogRecoveryAttempts += 1
            status = "NO SCREEN FRAMES for 6 seconds. Attempting one automatic stream recovery…"
            startCapture(using: filter, isRecovery: true)
            return
        }
        status = "No screen frames received after recovery. Return to RiderWise and authorize screen sharing again."
        isCapturing = false
        requiresReauthorization = true
        activeFilter = nil
        UserDefaults.standard.set(true, forKey: captureWasActiveKey)
        stopFrameWatchdog()
        let failedStream = stream
        stream = nil
        frameQueue.async { [weak self] in
            self?.activeStreamIdentifier = nil
            self?.isOCRInFlight = false
        }
        if let failedStream { Task { try? await failedStream.stopCapture() } }
    }

    nonisolated private func recognizeText(in pixelBuffer: CVPixelBuffer) -> [OCRLine] {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        request.recognitionLanguages = ["en-US"]
        do {
            try VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
            return (request.results ?? []).compactMap { observation in
                guard let candidate = observation.topCandidates(1).first else { return nil }
                let box = observation.boundingBox
                return OCRLine(text: candidate.string, confidence: Double(candidate.confidence),
                               x: box.minX, y: box.minY, width: box.width, height: box.height)
            }
        } catch {
            return []
        }
    }
}

extension ScreenCaptureManager: SCContentSharingPickerObserver {
    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker,
                                          didUpdateWith filter: SCContentFilter,
                                          for stream: SCStream?) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            self.isPickerRequestPending = false
            self.startCapture(using: filter)
        }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didCancelFor stream: SCStream?) {
        Task { @MainActor [weak self] in
            guard let self, !self.isCapturing else { return }
            self.isPickerRequestPending = false
            self.isStarting = false
            SCContentSharingPicker.shared.isActive = false
            self.status = "Screen sharing was cancelled. No screen content was captured. Tap Start authorized screen scan to try again."
        }
    }

    nonisolated func contentSharingPickerStartDidFailWithError(_ error: Error) {
        Task { @MainActor [weak self] in
            self?.isPickerRequestPending = false
            self?.isStarting = false
            self?.requiresReauthorization = true
            SCContentSharingPicker.shared.isActive = false
            self?.status = "Apple's screen-sharing picker failed: \(error.localizedDescription). Re-authorize from RiderWise."
        }
    }
}

extension ScreenCaptureManager: SCStreamOutput {
    nonisolated func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer,
                            of type: SCStreamOutputType) {
        guard type == .screen, sampleBuffer.isValid,
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
              activeStreamIdentifier == ObjectIdentifier(stream) else { return }
        let streamID = ObjectIdentifier(stream)
        let now = ProcessInfo.processInfo.systemUptime
        lastFrameUptime = now
        if !didReportFirstFrame {
            didReportFirstFrame = true
            Task { @MainActor [weak self] in
                guard let self, self.stream === stream else { return }
                // First frame can arrive before startCapture() returns; do not gate
                // frame receipt on the isCapturing flag.
                self.hasRecentFrames = true
                self.status = String(format: "LIVE SCREEN FRAMES · Vision OCR target %.1f seconds", max(1.5, self.scanInterval))
            }
        }
        guard now - lastOCRUptime >= currentScanInterval, !isOCRInFlight else { return }
        lastOCRUptime = now
        isOCRInFlight = true
        ocrQueue.async { [weak self] in
            guard let self else { return }
            let lines = self.recognizeText(in: pixelBuffer)
            Task { @MainActor [weak self] in
                guard let self else { return }
                defer {
                    self.frameQueue.async { [weak self] in
                        guard let self, self.activeStreamIdentifier == streamID else { return }
                        self.isOCRInFlight = false
                    }
                }
                guard self.stream === stream, self.isCapturing else { return }
                self.ocrPassCount += 1
                self.lastOCRLineCount = lines.count
                if lines.isEmpty {
                    self.status = "LIVE FRAMES · OCR pass \(self.ocrPassCount) found no readable text."
                } else {
                    self.status = "LIVE OCR · \(self.ocrPassCount) passes · \(lines.count) text lines · every \(String(format: "%.1f", max(1.5, self.scanInterval))) seconds"
                    await self.onOCRLines?(lines)
                }
            }
        }
    }
}

extension ScreenCaptureManager: SCStreamDelegate {
    nonisolated func stream(_ stream: SCStream, didStopWithError error: Error) {
        Task { @MainActor [weak self] in
            guard let self, self.stream === stream else { return }
            self.stopFrameWatchdog()
            self.stream = nil
            self.activeFilter = nil
            self.isCapturing = false
            self.hasRecentFrames = false
            self.isStarting = false
            self.requiresReauthorization = true
            self.picker.isActive = false
            UserDefaults.standard.set(true, forKey: self.captureWasActiveKey)
            self.frameQueue.async { [weak self] in
                self?.activeStreamIdentifier = nil
                self?.isOCRInFlight = false
            }
            self.status = "Screen scan stopped by iOS: \(error.localizedDescription). Tap Start authorized screen scan to resume."
        }
    }
}
#endif
