# RiderWise AI 3.4.5 — Full Pipeline Audit & Repair

## Source baseline
Audited the source archive supplied for the 3.4.4 capture-lifecycle build, then advanced the Xcode project and build number to 3.4.5 and added a matching GitHub Actions workflow. The active iOS 27+ capture architecture remains ScreenCaptureKit with Apple's system sharing picker. No ReplayKit Broadcast Upload Extension is required or included in the active target.

## Confirmed defects corrected in this revision
- Added the missing store state for actionable recommendation diagnostics and a persistent accepted-reference snapshot.
- Added the missing capture state observed by the app and PiP: `hasRecentFrames`, `ocrPassCount`, and `lastOCRLineCount`.
- Fixed a first-frame race. ScreenCaptureKit can deliver a frame before `startCapture()` returns; the old flow could discard that first frame and never mark frames as received. The new flow publishes the stream identity before starting and accepts the first valid frame without requiring the post-start `isCapturing` flag.
- Added active-stream identity checks so callbacks from a replaced or intentionally stopped stream cannot overwrite the state of the current stream. Fixed two capture-delegate compile blockers in the supplied source: the picker failure callback referenced an out-of-scope `picker`, and the OCR completion callback used an undefined `streamID`.
- Added a six-second frame watchdog, one automatic in-session recovery attempt, and an explicit reauthorization state if recovery fails. After 30 seconds of stable frame delivery, the recovery allowance resets for a later interruption.
- Moved Vision work to a dedicated serial OCR queue and added in-flight backpressure so slow OCR cannot accumulate an unbounded backlog.
- Kept OCR cadence at a 1.5-second minimum, with a five-frame-per-second capture cap and shallow frame queue.
- Separated intentional user stop from unexpected ScreenCaptureKit termination so a stop callback cannot incorrectly show a reauthorization error.
- Added OCR filtering for RiderWise's own PiP overlay so its labels and recommendation text are not parsed as Lalamove booking fields.
- Wired the accepted-booking evidence detector into live ingestion without counting a parsed accepted card twice. Re-observed cards restore their visible status and move to newest-first.
- Kept per-frame state persistence off the main thread while serializing critical user-triggered reference writes.
- Prevented bare locality substring collisions (for example, `San Mateo` vs `San Mateo Rizal`) from merging unrelated bookings.
- Clearing booking history now clears the saved reference snapshot too.
- PiP distinguishes a paused stream, no delivered frames, frames received before the first OCR pass, and active OCR. When no recommendation exists, it shows an explicit waiting/no-compatible state instead of mislabeling the latest detected booking as a recommendation.
- Restricted the system sharing picker to one full-display selection, disabled source switching, and hid microphone controls. This prevents accidental in-app/window capture of RiderWise itself.
- Repaired locality resolution so exact area centroids are preferred over collapsing every barangay to its parent city; province/region-only destinations are rejected as too coarse. All legacy centroids remain approximate and score-capped.
- Both pickup and drop-off must pass the route corridor and direction checks. The exact San Mateo → Commonwealth regression now keeps Antipolo/Marikina candidates in the provisional shortlist while rejecting Pasig/Valenzuela detours and province-only `Rizal`.
- Recommendation candidates must be complete, visible, and seen within 45 seconds. Empty results show per-candidate reasons in the main app and PiP.
- Added scheduled-booking card headers and cleaned a common leading `O`/`0` OCR artifact from locality names.
- Preserved the one-time migration from the old 2.5-second setting to 1.5 seconds; the Settings slider cannot go below 1.5 seconds.

## Platform configuration
- `NSScreenCaptureUsageDescription` is present.
- `UIBackgroundModes` includes `screen-capture` and `audio`.
- The app target links ScreenCaptureKit and includes Apple’s `com.apple.developer.screen-recording` entitlement. The usage-description key and `screen-capture` background mode are present in Info.plist.
- The rider must approve Apple's full-display sharing picker. iOS does not allow the app to silently recreate authorization after process termination.
- The native PiP surface is a RiderWise-generated dashboard, not a screen overlay or a copy of the Lalamove UI.

## Validation performed in this environment
- Swift package tests: **48 passed, 0 failed**.
- Swift parser: **20 Swift app/core files parsed, 0 syntax errors**.
- Portable source audit: PASS, including app/source contracts, PiP source checks, ScreenCaptureKit configuration, Info.plist, screen-recording entitlement, and geographic resources.
- Luzon PSGC dataset: **21,330 records**, unique codes and valid parent links.
- OCR overlay regression: PASS; PiP text is removed while the visible Lalamove booking card remains parseable.
- ZIP archive integrity: checked after packaging.

## Validation still required
This environment does not include Xcode, the iOS SDK, or a physical iPhone. Therefore it cannot type-check/link the iOS app target or certify ScreenCaptureKit, AVKit PiP, background execution, signing, or real OCR cadence on-device. The GitHub Xcode workflow must pass both Simulator build and unsigned device archive. Then a physical iPhone 13 Pro Max on iOS 27.3 must verify: full-display picker approval, frame delivery while Lalamove is foregrounded, 1.5-second OCR cadence, booking extraction, reference synchronization, geographic recommendations, and changing PiP content. A portable test pass is not proof of physical-device operation. The generated IPA is unsigned and requires signing/provisioning before installation.
