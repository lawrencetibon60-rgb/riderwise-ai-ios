# iOS port gap register — RiderWise AI 3.4.5

This register distinguishes implemented source from work that still requires an Apple SDK build or physical-device validation.

| Area | Current source state | Remaining validation / limitation |
|---|---|---|
| Xcode project | XcodeGen `project.yml`; app + RiderWiseCore targets | Generate and compile with Xcode 27 on GitHub Actions |
| Screen capture | Native iOS 27+ ScreenCaptureKit picker and SCStream; no ReplayKit extension in active target | Must verify full-display approval and continued frame delivery with Lalamove foregrounded on iPhone 13 Pro Max |
| Capture lifecycle | First-frame state, stream identity, six-second watchdog, one automatic stream recovery, reauthorization state | Verify interruptions, app backgrounding, process termination and recovery on device |
| OCR | On-device Vision; separate serial OCR queue; backpressure; minimum 1.5-second interval | Measure actual cadence, OCR latency, missed cards, orientation and thermal behavior on device |
| PiP | Native AVPictureInPictureController with RiderWise-generated AVSampleBufferDisplayLayer dashboard | Verify start/stop, background playback and changing PiP frames on iPhone |
| PiP/OCR isolation | PiP text filter removes RiderWise overlay text before Lalamove parsing | Test all PiP corner positions and different screen sizes |
| Accepted reference | Protected first accepted booking, separate persisted snapshot, explicit delivered/replace flow | Verify real Lalamove accepted-screen evidence and restart behavior on device |
| Booking parser | Multi-card segmentation, partial records, fare extraction, duplicate matching, accepted-screen evidence | Add more real-world Lalamove screen variants from device captures |
| Geographic resolver | Luzon PSGC hierarchy plus explicitly approximate legacy centroids | Validate full addresses; centroids are not street geocoding or road routing |
| Recommendations | Recent complete visible candidates; vehicle checks; route feasibility; approximate matches flagged and score-capped | Compare against driver-confirmed route scenarios; no guarantee of actual Lalamove order compatibility |
| Recommendation status | Empty-result reasons are surfaced in app and PiP | Confirm reasons remain understandable with real OCR results |
| Booking history | Seven-day retention, 1,500-record cap, first/last-seen tracking | Device storage pressure and migration test |
| Recommendation queue | Persistent actor and explicit lifecycle states | Device restart and storage-failure tests |
| Offline AI | Optional LiteRT-LM package/model ranking source; deterministic engine remains authoritative | Resolve package, download/load model, measure RAM/thermal behavior on iPhone 13 Pro Max |
| Live Activity | Not included as a target in this 3.4.5 project | Separate widget extension work required; do not assume it ships in this IPA |
| Floating overlay resizing | Not supported as Android-style cross-app overlay on iOS | Native PiP window size/position remain controlled by iOS |
| Profit estimate | Uses explicit driver-entered route distance, time, fuel price and efficiency | Validate against driver-entered values; pickup proximity is never delivery distance |
| Diagnostics | Bounded local diagnostics; no raw OCR text/customer details intended | Review logs on device and keep personal booking data out of diagnostics |
| IPA distribution | Workflow creates an unsigned IPA | Apple signing/provisioning is required before installation |

## Release blockers

1. GitHub Xcode 27 Simulator build passes.
2. GitHub Xcode 27 unsigned iOS device archive passes.
3. Archive metadata confirms version 3.4.5 / build 345, ScreenCaptureKit usage description, background modes and geography resources.
4. A signed build installs on the iPhone 13 Pro Max.
5. ScreenCaptureKit delivers frames while Lalamove is foregrounded.
6. OCR updates at the configured 1.5-second minimum without accumulating a queue backlog.
7. Accepted reference, candidate bookings, geographic recommendations and PiP state remain synchronized.
8. PiP displays changing recommendation data rather than a stale frame.
9. Offline model load and thermal/memory behavior are measured if that optional feature is enabled.

A portable test pass is not a substitute for Xcode compilation or physical-device acceptance testing.
