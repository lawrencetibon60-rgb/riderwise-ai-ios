> Historical implementation note: this document describes an earlier release. For the active 3.4.5 implementation and current 1.5-second cadence, see `IOS_3.4.5_FULL_PIPELINE_REPAIR.md`.

# iOS 3.3.7 Screen Scan and PiP repair

## Screen Scan
The active implementation remains ScreenCaptureKit on iOS 27+. The system picker observer is attached once before `present()`. The selected `SCContentFilter` callback is the only path that starts `SCStream`; cancelling the picker does not start capture. Startup/stop failures clear in-memory state and expose a retryable status. Vision OCR and the 2.5-second minimum throttle remain unchanged.

## PiP dashboard
The dashboard still uses RiderWise-generated sample-buffer frames; it does not mirror Lalamove or create an overlay. Startup now waits for successful frame enqueue and AVKit's `isPictureInPicturePossible` state before calling `startPictureInPicture()`. The sample-buffer display layer is hosted in a 320×180 view instead of a 1×1 view. PiP size and gestures remain iOS-controlled.

## Required device validation
1. Tap Start authorized screen scan; approve Entire Display; verify status changes to active.
2. Cancel the picker and verify the app remains stopped and can be started again.
3. Switch to Lalamove and verify new OCR lines appear at the configured cadence.
4. Tap Start PiP dashboard; wait for PiP to become possible; verify the RiderWise dashboard appears.
5. Switch to Lalamove and verify PiP remains visible and updates when OCR/recommendations change.
6. Stop both features and repeat after app background/foreground transitions.

No physical iPhone test is claimed by this source package.
