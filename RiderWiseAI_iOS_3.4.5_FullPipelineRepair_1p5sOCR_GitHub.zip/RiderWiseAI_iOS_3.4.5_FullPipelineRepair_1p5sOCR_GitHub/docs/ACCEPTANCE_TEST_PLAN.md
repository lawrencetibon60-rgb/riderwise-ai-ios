# Physical-device acceptance plan — iPhone 13 Pro Max / iOS 27.2.1

## A. Screen capture

1. Install a signed build and open RiderWise AI.
2. Tap Start authorized screen scan.
3. In Apple's system sharing picker, explicitly choose the full display.
4. Switch to Lalamove Driver. Confirm the system indicates screen sharing.
5. Leave a booking list visible for at least 15 seconds; compare scan timestamps to the configured 1.5-second cadence.
6. Scroll slowly through 30 offers; verify unique cards accumulate across frames.
7. Scroll rapidly; verify the app reports observed cards only and does not claim exhaustive scanning.
8. Stop capture in RiderWise; verify the stream stops.
9. Test app switching, screen lock, phone call, Wi-Fi loss, low-power mode, and memory pressure.

## B. OCR and booking state

1. Two complete cards plus a partial third card.
2. A collapsed card with unlabeled pickup/drop-off.
3. A card with same short pickup/drop-off municipality labels but different actual addresses.
4. Expanded details matching a collapsed record.
5. Accepted booking screen with booking number and payment method.
6. New card inserted at the top.
7. Old card resurfaces after scrolling away; first-seen must remain and seen count increments.
8. Two similar cards with same fare and route but no unique code; do not over-merge.
9. Verify pickup distance `~N km` is never used as delivery distance.

## C. Accepted reference

1. With no reference, capture one accepted booking screen; first accepted booking becomes reference.
2. Capture a second accepted booking; original reference remains unchanged.
3. Mark first reference delivered; verify it is retained as history and active reference clears.
4. Capture a later accepted booking; it becomes the new reference.
5. Manually verify full pickup and drop-off addresses; confirm the UI shows driver-verified state.

## D. Recommendations

1. Enable Ride Mode.
2. Test reference-based recommendation with one candidate.
3. Test multi-booking combination up to six candidates.
4. Verify known vehicle mismatch blocks a combination.
5. Test reference-free similar route pairs.
6. Confirm ambiguous short locality names are marked for verification.
7. Confirm approximate centroid labels never claim road routing, traffic or ETA.
8. Scroll a candidate off-screen; it remains in the saved queue with last-seen status.
9. Reintroduce a candidate; it becomes seen-again without losing first-seen.
10. Dismiss a suggestion and verify it is not silently reactivated.

## E. Offline AI

1. Use Wi-Fi and at least 5 GB free storage.
2. Download Gemma 4 E2B from the in-app action.
3. Verify SHA-256 before model load.
4. Load GPU backend; record startup time and memory.
5. If GPU fails, verify CPU fallback.
6. Disconnect internet and rank existing recommendations; no network request should be required.
7. Confirm AI can only reorder supplied IDs and cannot edit fare, location, route, or verification state.
8. Measure battery, heat, memory pressure and inference latency over a realistic shift.

## F. App lifecycle and UI

1. Toggle Ride Mode off/on and verify persistence/gating.
2. Toggle dark mode.
3. Switch compact/comfortable dashboard layout.
4. Verify Lock Screen Live Activity on iPhone 13 Pro Max (no Dynamic Island on this model).
5. Verify profit calculations with user-entered delivery route distance, time, fuel price and efficiency.
6. Verify 7-day / 1,500-record history cap and app restart persistence.
7. Verify diagnostics contain no customer names, phone numbers, full addresses or booking IDs.
8. Verify no automated taps, scrolling, accept or reject actions occur in Lalamove.
