> Historical implementation note: this document describes an earlier release. For the active 3.4.5 implementation and current 1.5-second cadence, see `IOS_3.4.5_FULL_PIPELINE_REPAIR.md`.

# RiderWise AI iOS 3.3.4 — ScreenCaptureKit implementation

The active iOS app target now uses the iOS 27 ScreenCaptureKit flow. The user starts capture through Apple's shared `SCContentSharingPicker`; the app receives the selected `SCContentFilter`, starts an `SCStream`, and performs local Vision OCR from screen sample buffers.

The ReplayKit broadcast extension is removed from the active target and the App Group queue is no longer part of the capture pipeline. OCR output continues through the existing `OCRLine` model and booking ingestion entry point. The configured interval is enforced with a 2.5-second minimum.

The PiP dashboard remains RiderWise-rendered and system-sized. Its sample-buffer renderer now uses the renderer receiver attached to an `AVSampleBufferRenderSynchronizer` and asynchronous enqueue rather than deprecated readiness/status/enqueue/flush calls.

## Validation status
- Portable Swift tests: 39 passed on Swift 6.2.1 Linux.
- Swift parser checks: passed for project Swift source.
- Xcode 27 simulator build: pending GitHub Actions.
- iOS device archive: pending GitHub Actions.
- Physical iPhone 13 Pro Max system picker, background capture and OCR: pending device test.
