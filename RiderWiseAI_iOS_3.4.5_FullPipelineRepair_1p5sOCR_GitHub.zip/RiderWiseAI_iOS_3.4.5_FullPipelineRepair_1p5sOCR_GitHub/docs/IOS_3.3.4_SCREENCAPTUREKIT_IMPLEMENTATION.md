> Historical implementation note: this document describes an earlier release. For the active 3.4.5 implementation and current 1.5-second cadence, see `IOS_3.4.5_FULL_PIPELINE_REPAIR.md`.

# RiderWise AI iOS 3.3.4 — ScreenCaptureKit migration

- Full-display capture is initiated only by the user through Apple's `SCContentSharingPicker`.
- The active app target receives `SCStream` frames directly; no ReplayKit broadcast extension, App Group queue, or ReplayKit API is linked into the app.
- Vision OCR runs locally on captured pixel buffers. OCR dispatch is throttled to the configured interval with a 2.5-second minimum.
- Existing `OCRLine` and `RiderWiseStore.ingestOCRLines` integration is retained.
- `screen-capture` background mode and `NSScreenCaptureUsageDescription` are declared for full-display capture while RiderWise is backgrounded.
- The user can stop the stream from RiderWise; iOS also owns the system screen-sharing consent and controls.

Physical iPhone validation is still required for the system picker, background capture continuation, OCR cadence, and PiP handoff.
