#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test
for f in iOSApp/*.swift BroadcastExtension/*.swift LiveActivityWidget/*.swift Sources/RiderWiseCore/*.swift; do
  swiftc -frontend -parse "$f" >/dev/null
done
python3 - <<'PY'
import gzip, json, pathlib, plistlib, collections
root=pathlib.Path('.')
plistlib.loads((root/'iOSApp/Info.plist').read_bytes())
plistlib.loads((root/'BroadcastExtension/Info.plist').read_bytes())
app_entitlements = plistlib.loads((root/'iOSApp/RiderWiseAI.entitlements').read_bytes())
ext_entitlements = plistlib.loads((root/'BroadcastExtension/RiderWiseBroadcast.entitlements').read_bytes())
app_groups = app_entitlements.get('com.apple.security.application-groups', [])
ext_groups = ext_entitlements.get('com.apple.security.application-groups', [])
assert app_groups and app_groups == ext_groups, 'App Group entitlements must match between host app and broadcast extension'
assert 'ph.riderwise.ai.broadcast' in (root/'project.yml').read_text()
print('Info.plists and App Group entitlements: PASS')
with gzip.open(root/'Sources/RiderWiseCore/luzon_psgc_3q_2026.json.gz','rt',encoding='utf-8') as f:
    data=json.load(f)
records=data['records']
codes={r['psgc'] for r in records}
counts=collections.Counter(r['level'] for r in records)
assert len(records)==21330 and len(codes)==len(records)
assert dict(counts)=={'Reg':8,'Prov':38,'City':77,'Mun':694,'SubMun':14,'Bgy':20499}
assert all(not r.get('parentPsgc') or r['parentPsgc'] in codes for r in records)
print('Info.plist: PASS')
print('PSGC dataset: PASS (21,330 records, unique codes, valid parent links)')
PY
