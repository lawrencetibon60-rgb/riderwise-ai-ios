# iOS user-authorized live screen scanning

RiderWise uses Apple's ReplayKit Broadcast Upload Extension instead of ScreenCaptureKit. The user must explicitly start the broadcast from the iOS system broadcast picker and can stop it from the system broadcast controls. The extension receives shared video frames only; audio is ignored. Vision OCR runs on-device every configured 2.5–10 seconds and only OCR text/coordinates are queued in the App Group container. Raw video frames are not archived.

The containing app reads the OCR queue when it is active and feeds each frame into the existing Lalamove parser, booking store, accepted-reference logic and recommendation engine. iOS may suspend the containing app while Lalamove is foreground, so the dashboard cannot float over Lalamove and recommendations may refresh when the user returns to RiderWise. The broadcast extension can continue receiving shared frames while the user-approved broadcast is active, subject to iOS system controls, interruption and resource limits. This is not silent or guaranteed always-on monitoring.

## Required signing setup

Both the app and broadcast extension use the App Group `group.ph.riderwise.ai`. Enable this exact App Group capability for both bundle IDs in the Apple Developer account and include it in provisioning profiles before signed installation/distribution. Unsigned CI builds do not prove that App Group entitlements are provisioned or that broadcast works on a physical iPhone.

## Device acceptance tests

1. Install a signed build with the App Group entitlement on the target iPhone.
2. Tap Start authorized screen scan and choose RiderWise in the iOS Broadcast UI.
3. Confirm iOS displays its active broadcast indicator.
4. Switch to Lalamove; test list, expanded and accepted booking screens.
5. Return to RiderWise and verify queued OCR observations are processed in order without duplicate bookings.
6. Change scan interval and confirm the extension follows it.
7. Stop from iOS broadcast controls; confirm capture stops and no more frames are queued.
8. Test incoming calls, app termination, low memory, orientation changes and battery/thermal behavior.
