# RiderWise AI 3.1.0 — iOS Feature Matrix

Status meanings:
- **Implemented (core):** source exists and portable tests cover it.
- **Implemented (iOS source, unverified):** native source exists but still requires Xcode/device validation.
- **Adapted:** Android behavior cannot be reproduced as-is on iOS; an iOS alternative is provided.
- **Pending:** not implemented or not yet proven.

| Android feature / requirement | iOS implementation | Status | Acceptance evidence still required |
|---|---|---|---|
| Multi-card booking OCR | Vision OCR + card segmentation/parser | Implemented (core); Vision source unverified | Xcode build and real-device screen stream |
| 2.5-second scan interval | Configurable ReplayKit broadcast OCR sampler | Implemented (iOS source, unverified) | Verify actual 2.5s cadence, orientation and interruptions |
| Partial booking recognition | Incomplete cards remain `.partial` | Implemented (core) | Additional Lalamove layouts |
| Pickup/drop-off without labels | Ordered endpoint inference + full-address grouping | Implemented (core) | More screenshots and layout variants |
| Fare and fare components | PHP total, base fare and additional fare | Implemented (core) | OCR accuracy against live offers |
| Pickup distance vs delivery distance | Separate `pickupDistanceKm` and `deliveryDistanceKm` fields | Implemented (core) | Confirm all Lalamove layouts use same semantics |
| Vehicle and booking type | Vehicle/service/priority extraction | Implemented (core) | More vehicle and booking types |
| Customer notes | List-card note extraction | Implemented (core) | More note examples |
| Booking number | Accepted-screen booking code extraction | Implemented (core) | More booking ID formats |
| Duplicate prevention | Code-first, otherwise conservative unique matching | Implemented (core) | Repeated identical-looking offer test on device |
| First accepted reference | Accepted screen detector and first-reference protection | Implemented (iOS source, unverified) | Confirm on live Lalamove accepted workflow |
| Later accepted booking protection | Existing reference is not silently replaced | Implemented (iOS source, unverified) | Multi-accepted workflow test |
| Clear/replace reference after delivery | Mark delivered, clear, then choose next reference | Implemented (iOS source, unverified) | Real workflow test |
| Seven-day booking history / 1,500 cap | Local persisted history pruning | Implemented (iOS source, unverified) | Restart and retention tests on iPhone |
| First-seen and resurfacing count | Preserved `firstSeen`, updated `lastSeen` and `seenCount` | Implemented (iOS source, unverified) | Repeat screen capture test |
| Persistent recommendation queue | Queue persistence, not-visible, seen-again, terminal states | Implemented (core) | App lifecycle/restart test |
| Multi-booking combinations (up to six) | Bounded deterministic pickup/drop-off route-order search | Implemented (core) | Validate route behavior with real driver examples |
| Vehicle compatibility | Known vehicle mismatch blocks combination | Implemented (core) | Additional vehicle rules |
| Reference-free route pairs | Pickup-gap/drop-off-gap similarity, ambiguity warning | Implemented (core) | Compare against Android test cases |
| Geographic intelligence | Luzon PSGC hierarchy and contextual address resolution | Implemented (core) | Verify all real addresses and province ambiguity |
| Legacy coordinate dataset | Ported approximate centroid records | Implemented (core) with explicit warning | Replace with verified geocoding/road provider if needed |
| Road distance, traffic and ETA | No road-routing provider included | Pending | Select and integrate a lawful routing provider |
| Driver address verification | Editable full pickup/drop-off and explicit driver confirmation | Implemented (iOS source, unverified) | Live booking address test |
| Local pickup heatmap | Excluded by product scope; Lalamove already provides this | Not included |
| Profit calculator | Fare components, entered route distance/time/fuel inputs | Implemented (core) | Validate against real fuel and route inputs |
| Offline AI | Optional Gemma 4 E2B download, SHA-256 verification, LiteRT-LM rank-only adapter | Implemented (iOS source, unverified) | Package resolution, model load, RAM/thermal/battery test on iPhone 13 Pro Max |
| Offline deterministic fallback | Core recommendation engine remains usable without model | Implemented (core) | App-level failure-path test |
| Ride Mode | Gates route recommendations, retains history | Implemented (iOS source, unverified) | Toggle and persistence test |
| Dark mode | SwiftUI color-scheme support | Implemented (iOS source, unverified) | Visual test |
| Adjustable floating dashboard | Android overlay is not available; compact/comfortable native layout | Adapted | UX review on iPhone |
| Floating dashboard over Lalamove | Not available to ordinary iOS apps | Adapted | Live Activity is the supported glanceable alternative |
| Lock Screen Live Activity | Active accepted reference summary | Implemented (iOS source, unverified) | Xcode extension build and real-device permission test |
| Dynamic Island | Widget supports it on eligible models | Implemented (iOS source, unverified) | Not available on iPhone 13 Pro Max; test on supported model only |
| Automatic cross-app monitoring | User-approved ReplayKit Broadcast Upload Extension | Implemented (iOS source, unverified) | Background, stop/restart, phone-call and memory-pressure tests |
| Auto-accept / auto-reject | Intentionally not implemented | Excluded for safety | Driver always makes final decision in Lalamove |
| Diagnostics | Bounded local diagnostics without customer details | Implemented (core) | App UI/log rotation test |
| Native iOS build | XcodeGen project and diagnostic CI workflow (both Apple builds attempted; xcresult/log artifacts retained) | Pending cloud build | Xcode 27 CI result |
| Signed IPA | Apple signing not configured | Pending | Apple signing + TestFlight or device provisioning |
