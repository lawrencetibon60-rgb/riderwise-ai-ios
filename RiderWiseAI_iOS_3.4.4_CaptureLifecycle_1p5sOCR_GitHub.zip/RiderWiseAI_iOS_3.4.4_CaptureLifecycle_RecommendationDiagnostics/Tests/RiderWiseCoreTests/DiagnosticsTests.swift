import XCTest
@testable import RiderWiseCore
final class DiagnosticsTests:XCTestCase {
    func testDiagnosticsPersistAndRemainBounded() async throws {
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let log=DiagnosticsLog(fileURL:directory.appendingPathComponent("diagnostics.json"))
        for index in 0..<220 {
            try await log.append(DiagnosticEvent(level:.info,code:"TEST_\(index)",message:"OCR frame processed"))
        }
        let events=await log.recent()
        XCTAssertEqual(events.count,200)
        XCTAssertEqual(events.first?.code,"TEST_219")
        try? FileManager.default.removeItem(at:directory)
    }
}
