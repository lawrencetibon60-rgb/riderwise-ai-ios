import XCTest
@testable import RiderWiseCore
final class QueueTests:XCTestCase {
    func testQueuePreservesFirstSeenAndStalesMissing() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let q=RecommendationQueue(fileURL:dir.appendingPathComponent("queue.json"))
        let t=Date(timeIntervalSince1970:1000)
        try await q.refresh([SavedRecommendation(id:"x",description:"San Mateo → Commonwealth",state:.recommended,firstSeen:t,lastSeen:t,score:0.8,availability:"SEEN")],at:t)
        try await q.refresh([],at:t.addingTimeInterval(60))
        let items=await q.all()
        XCTAssertEqual(items.first?.firstSeen,t); XCTAssertEqual(items.first?.state,.notVisibleLastScan)
        try? FileManager.default.removeItem(at:dir)
    }
    func testQueueMarksReappearingCandidateSeenAgainAndPreservesFirstSeen() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let q=RecommendationQueue(fileURL:dir.appendingPathComponent("queue.json"))
        let t=Date(timeIntervalSince1970:2000)
        let item=SavedRecommendation(id:"pair",description:"A → B",state:.recommended,firstSeen:t,lastSeen:t,score:0.7,availability:"SEEN")
        try await q.refresh([item],at:t)
        try await q.refresh([],at:t.addingTimeInterval(30))
        try await q.refresh([item],at:t.addingTimeInterval(60))
        let restored=await q.all().first
        XCTAssertEqual(restored?.firstSeen,t)
        XCTAssertEqual(restored?.state,.seenAgain)
        XCTAssertTrue(restored?.availability.contains("LIVE_AVAILABILITY_UNVERIFIED") == true)
        try? FileManager.default.removeItem(at:dir)
    }

    func testAcceptedQueueItemIsNotReactivatedByLaterScan() async throws {
        let dir=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let q=RecommendationQueue(fileURL:dir.appendingPathComponent("queue.json"))
        let t=Date(timeIntervalSince1970:3000)
        let item=SavedRecommendation(id:"pair",description:"A → B",state:.recommended,firstSeen:t,lastSeen:t,score:0.7,availability:"SEEN")
        try await q.refresh([item],at:t)
        try await q.mark("pair",state:.accepted)
        try await q.refresh([item],at:t.addingTimeInterval(60))
        let finalItems=await q.all()
        XCTAssertEqual(finalItems.first?.state,.accepted)
        try? FileManager.default.removeItem(at:dir)
    }

}
