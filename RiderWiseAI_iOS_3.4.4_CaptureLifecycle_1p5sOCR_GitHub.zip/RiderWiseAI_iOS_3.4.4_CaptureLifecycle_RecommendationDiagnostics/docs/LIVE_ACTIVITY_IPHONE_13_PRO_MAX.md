# RiderWise Live Activity — iPhone 13 Pro Max

## Device presentation

The iPhone 13 Pro Max does not have Dynamic Island hardware. RiderWise therefore uses the iOS Lock Screen Live Activity presentation on this device. The Dynamic Island regions remain available to compatible newer iPhone models but are not shown on iPhone 13 Pro Max.

## Displayed information

- Accepted reference pickup and drop-off
- Accepted reference fare
- Best current compatible-offer label
- Combined/recommended fare estimate from the recommendation model
- Recommendation score and address-verification status
- Broadcast status and recommendation count

## Lifecycle

The app requests a Live Activity when the user starts the authorized broadcast flow. The main app updates its Live Activity when its in-memory booking/reference/recommendation state changes. The user can disable Live Activities in iOS Settings or stop the screen broadcast through Apple's system controls.

## Background refresh limitation

A Live Activity is a presentation surface, not a background execution entitlement. During a ReplayKit broadcast of another app, iOS may suspend RiderWise's main app. In that state, this implementation cannot promise that each broadcast frame will immediately update the Lock Screen Live Activity. Reliable server-driven updates while the app is suspended require an ActivityKit push-update service and APNs token handling. This package does not claim to include that backend. On-device OCR and recommendation processing in the broadcast extension must be validated separately on a physical device.

## Validation status

The portable RiderWiseCore test suite passes 34/34 tests on Linux. This is not an Xcode build, Live Activity runtime test, ReplayKit test, or signed iPhone installation. Those require the configured macOS Xcode workflow and physical-device testing.
