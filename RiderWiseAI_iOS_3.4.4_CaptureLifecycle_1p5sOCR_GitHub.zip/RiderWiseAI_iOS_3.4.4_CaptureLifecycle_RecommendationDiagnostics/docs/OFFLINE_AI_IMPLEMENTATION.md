# RiderWise AI 3.0 — Advanced Offline AI

## Architecture

1. **OCR and extraction:** ML Kit OCR plus `BookingExtractor` identify booking fields.
2. **Deterministic validation:** `BookingValidator`, accepted-booking logic, fare arithmetic, duplicate handling, PSGC/location verification, vehicle constraints and route feasibility remain authoritative.
3. **Deterministic candidate generation:** `RecommendationEngine` creates combinations that pass existing hard checks and calculates the factual score.
4. **Active local AI ranking:** `LiteRtLocalAnalyzer.rankRecommendations` receives only the best eight validated combinations. It evaluates route fit, straight-line detour estimate, OCR confidence, vehicle/booking type and advisory driver preferences, then returns an ordering of supplied candidate IDs.
5. **Validation boundary:** the service accepts only IDs that map to supplied options. The model cannot add bookings, change OCR fields, edit fare/distance, invent coordinates/ETA, or bypass location verification and vehicle constraints. Deterministic options remain visible if the model is missing, unavailable or returns invalid output.
6. **Dashboard:** recommendation combinations are displayed in AI-ranked order once local inference completes. Before that, deterministic ranking is shown.

## Offline runtime and model lifecycle

- Runtime: Google LiteRT-LM Android `0.18.0`, CPU backend, one serialized worker.
- Model currently configured: `Gemma 4 E2B IT` LiteRT-LM artifact, downloaded into app-private `files/models/` only after the rider taps Download. Model weights are not packaged in the APK.
- First download requires internet and substantial storage (the currently configured artifact is approximately 2.6 GB). After the model is present, AI inference does not call a cloud API and can run offline.
- The main activity and screen-capture service share one process-wide local analyzer instance to avoid loading two copies of the model.
- LLM ranking is triggered when the validated recommendation set changes, not on every 2.5-second OCR scan.
- If the model is absent or inference fails, OCR and deterministic recommendations continue.

## Device limitations

The target phone has 8 GB RAM, but this does not guarantee that the configured model will load quickly or run smoothly. Model file size is not the same as runtime memory use. Actual load time, peak memory, inference latency, thermal throttling and battery use must be tested on the Oppo Reno 5 before claiming device compatibility. If performance is poor, use a smaller LiteRT-LM-compatible model artifact and update model metadata and download URL together.

## Privacy and network

- No Gemini client, online AI endpoint, API-key storage, online-consent switch or cloud fallback is included.
- Android internet permission remains only because the optional one-time model download uses HTTPS. Network-state access is used to warn about large mobile-data downloads.
- Booking OCR and model inference remain on-device.

## Important limitations

- AI ranks combinations already created by deterministic route/location rules; it does not replace the deterministic engine or guarantee that a booking is profitable.
- The supplied geographic index is administrative data with approximate locality coordinates; straight-line distances are not road distances or ETAs.
- A model response is advisory. The implementation whitelists candidate IDs and ignores unknown IDs.
- The actual LiteRT-LM artifact URL, model/runtime compatibility, build, model download, inference and physical-device performance still require verification.
