# RiderWise AI 3.4.4 — Capture Lifecycle & Ride Mode State

## Changes
- Persist a marker while a user-approved ScreenCaptureKit stream is active.
- On a later launch, detect that the previous process ended while capture had been active and explain that a fresh user approval is required.
- On foreground return, refresh capture lifecycle status and the PiP dashboard frame.
- When iOS stops the stream or startup fails, mark capture as requiring a new user-approved session.
- Keep Start authorized screen scan as the explicit route back to Apple's sharing picker.
- Mirror Ride Mode into UserDefaults as well as app state, restore it on launch, and expose a direct Ride Mode toggle in the dashboard header.
- Keep OCR interval at 1,500 ms (1.5 seconds).
- Preserve the geographic recommendation fallback and address-verification safeguards from 3.4.3.

## Platform limitation
iOS does not allow RiderWise to silently recreate a user-authorized full-display capture stream after the app process is terminated. The rider must return to RiderWise and approve a fresh ScreenCaptureKit sharing session. This build detects and explains that state; it does not bypass Apple's consent picker.

## Validation boundary
Portable Swift tests and source checks validate core package logic and source structure. A physical iPhone test is still required to confirm ScreenCaptureKit lifecycle, PiP behavior, and OCR cadence on the target iOS release.
