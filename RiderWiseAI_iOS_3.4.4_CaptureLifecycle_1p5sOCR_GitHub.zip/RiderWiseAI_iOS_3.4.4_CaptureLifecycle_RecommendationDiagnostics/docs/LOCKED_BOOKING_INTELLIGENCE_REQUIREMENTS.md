# RiderWise AI 3.0 — Locked Booking Intelligence Requirements

Status: **Approved product requirements / implementation specification**
Version: 3.0.0
Scope: Lalamove Driver Philippines booking recognition, history, recommendations, and driver-controlled interaction.

This document records mandatory behavior agreed with the app owner. It is a specification, not evidence that every feature is already implemented or device-tested.

## 1. Non-negotiable operating principles

1. Preserve existing working functionality; modify incrementally.
2. Core OCR, booking identity, geographic verification, route/fare calculations, and state transitions remain deterministic and auditable.
3. Local AI may interpret context, identify missing information, explain results, and rank only candidates that pass deterministic safety gates.
4. Never invent missing booking fields, addresses, coordinates, road distance, ETA, traffic, or availability.
5. The driver retains control. RiderWise must not automatically scroll, tap a Lalamove card, start a booking, accept, reject, or otherwise interact with Lalamove on the driver's behalf.
6. The 2.5-second scan interval is the default and remains configurable.

## 2. Lalamove screen and card recognition

The parser must support the actual Lalamove UI behavior shown in the supplied reference screenshots:

- Collapsed booking cards can show two endpoint names without explicit PICKUP / DROPOFF labels.
- In the collapsed card, the first endpoint is pickup and the second endpoint is drop-off, provided the layout and parser confidence support that interpretation.
- The orange header's `~N km` value is distance from the rider to pickup. It is not the delivery route distance and must never be used as the delivery-distance denominator for fare/km.
- Fare, vehicle type, booking type, and visible endpoint names must be parsed independently per card.
- A card can be partially visible at the bottom of the screen. Partial cards may be counted/tracked as fragments but must not be promoted to complete bookings until required fields are verified.
- Opening a card manually can reveal full pickup/drop-off addresses. Expanded-screen OCR must enrich the matching collapsed-card record, not create a second unrelated booking.
- Match expanded and collapsed records only with sufficient evidence (booking code if available; otherwise a conservative combination of endpoints, fare, vehicle/type, and other stable fields). If multiple records could match, request verification instead of merging.
- Support both list and expanded detail screen states.
- Card segmentation must use visual layout/header bands and OCR bounding boxes together; do not rely on OCR text alone.

## 3. Newest-first list movement and resurfacing old bookings

Lalamove can reorder the visible list as new offers arrive. It can also move an older offer from deep in the available list back to the top, making it look new.

Required behavior:

- Treat screen position as a temporary observation, not booking identity.
- Record first-seen time, last-seen time, seen count, last-known screen position, and identity evidence.
- A booking moving from bottom to top must match its existing record when identity evidence is strong; do not create a duplicate or reset its first-seen time.
- A genuinely new booking inserted at the top must create a new record.
- Preserve the original first-seen timestamp and history when an existing booking is observed again.
- Keep a bounded, persistent local history so resurfacing bookings can be recognized across scrolling and app screen changes.
- If two bookings have similar pickup/drop-off/fare values and there is no unique identifier, do not over-merge. Keep them as separate/uncertain records until more evidence is available.
- Do not assume an item is expired merely because it left the visible viewport.

## 4. Continuous manual-scroll scanning

- Continue OCR/capture analysis while the driver manually scrolls through the available list.
- Accumulate unique bookings across frames and scroll positions; do not limit analysis to the first two full cards and one partial card.
- Debounce identical frames and avoid unnecessary repeated OCR/LLM work.
- Use stable booking identity to deduplicate across overlapping frames and list reordering.
- A card that scrolls away remains in local history.
- Scanning is observational only. No automated scroll gestures or taps.
- If a card moves off-screen before any frame captures enough information, RiderWise must report that it was not fully observed; never claim exhaustive coverage of all offers.
- The UI should show counts for unique detected, partial/incomplete, saved candidates, and currently visible cards where those counts are known.

## 5. Active reference booking recommendations

When a verified accepted booking is set as the active reference:

- Keep that reference stable until the driver changes/clears it or an authorized completion workflow changes it.
- Compare each eligible detected booking against the active reference.
- Evaluate every candidate captured while scrolling, not only currently visible candidates.
- Store compatible recommendations in a persistent recommendation queue.
- If a recommended booking becomes buried by newer offers, keep it in the RiderWise dashboard queue.
- Store recommendation reason, compatibility classification, verification requirements, first/last observed times, and evidence freshness.
- Recompute recommendations when a candidate's verified address changes or the reference changes.
- Never claim that a buried candidate is currently available merely because it was seen earlier.

## 6. Reference-free recommendations

When no accepted reference booking exists:

- Do not disable recommendations.
- Compare eligible, sufficiently complete bookings against other detected bookings as potential route pairs/sets.
- Identify and rank possible compatible pairs, including a later-scanned booking that may fit an earlier-scanned booking.
- Explain which booking is the comparison anchor and which is the suggested candidate.
- Clearly label the result as a **potential booking combination**, not a confirmed accepted-reference recommendation.
- Do not automatically promote an available booking to accepted/reference status.
- Exclude ambiguous or insufficiently verified location combinations from high-confidence classifications; retain them as "Needs verification" where useful.

## 7. Persistent recommendation queue and evidence freshness

Each queued candidate must have a lifecycle state, at minimum:

- `NEWLY_DETECTED`
- `PARTIAL`
- `NEEDS_ADDRESS_VERIFICATION`
- `VERIFIED_CANDIDATE`
- `RECOMMENDED`
- `NOT_VISIBLE_LAST_SCAN`
- `SEEN_AGAIN`
- `ACCEPTED`
- `REJECTED_BY_DRIVER`
- `EXPIRED_CONFIRMED`
- `STALE_UNVERIFIED`

Rules:

- Not visible does not mean unavailable.
- Previously detected does not mean currently available.
- A reappearing candidate refreshes last-seen evidence but preserves identity and first-seen history.
- Only positive evidence may mark a candidate accepted or confirmed expired/unavailable.
- A candidate whose availability has not been refreshed must display "last seen" or "availability unverified".
- Driver rejection is distinct from Lalamove expiry.
- Queue entries must persist across dashboard redraws, screen changes, and app process restarts.
- Provide controls to review, dismiss/reject, and manually locate a saved candidate without automating Lalamove interaction.
- The queue should prioritize high compatibility and high data confidence, while keeping verification-needed items visibly separate.

## 8. Geographic and route authority

- Use PSGC hierarchy and authorized offline geographic assets for administrative place resolution.
- A short place name with multiple possible matches is ambiguous until full address, hierarchy, or driver confirmation resolves it.
- Store verified facts separately from hypotheses and driver preferences.
- Distinguish rider-to-pickup proximity, pickup-to-drop-off route distance, road distance, straight-line distance, detour, and travel-time estimate.
- If only centroids are available, label the result as an approximate straight-line estimate, not road routing.
- Never claim actual road-network routing until a real, tested road graph/router is integrated.
- AI cannot override verified coordinates, route calculations, fare arithmetic, or hard vehicle/booking constraints.

## 9. Dashboard requirements

Provide a persistent **Saved Compatible Bookings** section showing:

- Pickup and drop-off.
- Fare, vehicle, and booking type when known.
- Compatibility classification and concise reason.
- Geographic/OCR verification status.
- Last-seen time and availability freshness.
- Whether the candidate is currently visible, previously seen/buried, or stale/unverified.
- Whether it was evaluated against an accepted reference or as a reference-free potential pair.

The dashboard must not imply a saved recommendation is still available without fresh evidence.

## 10. Required acceptance tests

A release cannot claim this feature set is complete until these scenarios pass:

1. Two full cards plus a partial third card: parse full cards independently; retain the third as partial only.
2. Unlabeled collapsed card: infer endpoint order from validated UI layout and mark uncertainty if layout is not reliable.
3. Expanded address: enrich the matching collapsed booking without duplicating it.
4. New offer inserted at top: create one new booking; preserve older records.
5. Old offer resurfaces from deep in the list: match existing identity; preserve original first-seen and increment seen count.
6. Similar offers with same fare/locations but no unique identifier: avoid unsafe merge.
7. Thirty-offer manual scroll: accumulate every sufficiently observed unique booking across captured frames; report partial/missed observations honestly.
8. Reference active, candidate later buried: recommendation remains in queue with last-seen freshness.
9. Candidate reappears: refresh last-seen evidence without duplicating the queue item.
10. Candidate no longer visible: mark not visible / availability unverified, not expired.
11. Candidate positively accepted: mark accepted and remove it from available-candidate recommendations while preserving history.
12. No reference: recommend compatible pairs among scanned bookings and explain the anchor/candidate roles.
13. Ambiguous barangay: request full address/driver verification; do not fabricate city.
14. Pickup proximity value: never treat Lalamove's orange-header km as delivery route distance or fare/km denominator.
15. App restart: restore booking history, reference, and recommendation queue.
16. AI unavailable: deterministic scanning, validation, and recommendations continue.
17. Driver control: verify no automated scroll, tap, start, accept, or reject action is performed.

## 11. Release evidence

For each build, report separately:

- Source changes completed.
- Unit tests run and results.
- Gradle build result.
- APK artifact produced or not.
- Model load/inference result.
- Actual-device tests and device model.
- Lalamove UI test scenarios passed/failed.
- Known limitations.

Never describe a feature as implemented, working, or tested solely because it appears in this requirements document.


## iOS update — local booking history and first accepted reference

- Local history retention is seven rolling days, with a maximum of 1,500 queried/retained booking records.
- First accepted reference is established only after the accepted-screen detector sees multiple independent post-acceptance markers, including a pickup-time marker and a post-acceptance action/instruction marker, plus a complete booking and valid fare.
- The booking code on the accepted screen is the strongest link to the earlier available card. If no code exists, a unique composite match is attempted using fare, endpoints, and vehicle type; ambiguous matches require driver verification.
- The first accepted reference is protected. A later accepted booking cannot silently replace it; replacement or clearing requires an explicit driver action.
