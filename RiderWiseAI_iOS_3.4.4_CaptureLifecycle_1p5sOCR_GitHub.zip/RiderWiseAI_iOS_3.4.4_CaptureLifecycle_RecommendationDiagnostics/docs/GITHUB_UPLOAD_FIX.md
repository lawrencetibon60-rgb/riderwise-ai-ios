# GitHub upload fix

## Why run #11 failed

The Actions log says:

`unzip: cannot find or open RiderWiseAI_iOS_3.1.0_Complete.zip`

This happens before Xcode starts. The workflow's working directory does not contain the archive under the exact expected filename.

## First upload with the repository's currently installed workflow

The previous workflow runs its extraction step from the `ios/` directory (the build log paths show `ios/RiderWiseAI_iOS_3.1.0_Complete`). Upload and commit this archive at:

`ios/RiderWiseAI_iOS_3.1.0_Complete.zip`

Do not upload it as `RiderWiseAI_iOS_3.1.0_Complete 4.zip`, and do not put it in a different folder for that old workflow.

## Updated workflow in this source package

The updated `.github/workflows/ios-build.yml` no longer assumes a fixed working directory. It:
1. Searches the repository checkout for `RiderWiseAI_iOS_3.1.0_Complete.zip`.
2. If no archive exists, uses a project already extracted at repository root.
3. Otherwise searches nested directories for `project.yml`.
4. Stops with a clear message and repository file listing if no source project can be found.

After this package is extracted/committed into the repository, subsequent runs can use either the archive or extracted project structure.

## Validation boundary

The portable Swift tests, syntax parsing, plist/entitlement checks and geographic resource checks can run on Linux. Only the macOS Xcode job can confirm Apple SDK type-checking/linking. A successful unsigned device build is still not a signed IPA.
