# RiderWise AI 3.0 Developer Configuration

`app/src/main/assets/riderwise_upgrade_config.json` is the runtime feature-flag source.

- `scan.interval_ms`: 2500 ms target cadence (clamped to 2500–10000 ms).
- `features.continuous_scanning`: repeated screen scans during an authorized MediaProjection session.
- `features.multi_booking_extraction`: independent card extraction.
- `features.partial_booking_diagnostics`: count incomplete candidates without saving them as complete bookings.
- `features.ride_mode_gate`: require Ride Mode ON before ride-based recommendations are generated.
- `features.geographic_intelligence`: local booking-area analytics.
- `features.road_routing_provider`: false until a provider is selected and licensed/configured.
- `ai.architecture`: `ADVANCED_OFFLINE`; all LLM inference runs on-device after model download.
- `ai.local_llm` and `ai.ai_recommendation_ranking`: local model may rank only deterministic, pre-validated recommendation combinations.
- `ai.online_ai`: false; no online AI provider or API-key flow is included. Internet access is retained only for user-initiated model download.

Safety flags remain read-only. Automatic booking acceptance and rejection remain disabled.
