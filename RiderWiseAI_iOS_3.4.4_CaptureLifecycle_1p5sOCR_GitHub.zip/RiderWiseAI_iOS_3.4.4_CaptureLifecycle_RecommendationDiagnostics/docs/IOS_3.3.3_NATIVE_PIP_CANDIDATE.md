# RiderWise AI 3.3.3 — Native PiP candidate

## User-selected behavior
YouTube-style native iOS Picture in Picture. The system owns PiP window placement and resizing. RiderWise renders its own dashboard; it does not draw an unrestricted overlay over Lalamove and does not mirror Lalamove inside the PiP window.

## Preserved features
The existing booking parser, multi-card extraction, partial-booking handling, duplicate matching, accepted-booking reference workflow, recommendation engine, offline AI ranking, 2.5-second configured OCR interval, geographic resources, diagnostics, and read-only/manual-confirmation safeguards are retained from 3.3.2.

## PiP changes in this candidate
- Enables AVKit automatic PiP-from-inline capability.
- Keeps AVPictureInPictureController with AVSampleBufferDisplayLayer as the dashboard renderer.
- Keeps system-controlled PiP resizing and positioning; no custom freeform handles are added.
- Avoids flushing the display layer merely because it is temporarily back-pressured.

## Important unresolved iOS 27 capture gate
The 3.3.2 source uses ReplayKit RPBroadcastSampleHandler / RPSampleBufferType for user-authorized screen capture. The uploaded Xcode 27 archive log reports these APIs deprecated / no longer supported in iOS 27. This candidate intentionally preserves that code rather than guessing at an unverified ScreenCaptureKit replacement. Therefore, **screen capture and OCR on iOS 27 are not certified by this source-only update**.

Before release, the capture path must be migrated using the exact ScreenCaptureKit APIs available in the selected Xcode 27 SDK, then built on macOS/Xcode and tested on the user's iPhone. Do not treat the existing ReplayKit broadcast path as proven working on iOS 27.

## Validation status
- Portable Swift tests: not rerun in this environment.
- Xcode simulator build: not run in this environment.
- iOS device archive: not run in this environment.
- Native PiP behavior: not device-tested.
- Signed IPA / installation: not provided by this candidate.

## Version
Marketing version: 3.3.3
Build number: 333
