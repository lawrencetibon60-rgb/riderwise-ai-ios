# RiderWise AI 3.1.0 — Release candidate

## Main objective
Make the floating dashboard the normal daily workflow and remove unnecessary trips back to the main app.

## Changes
- Automatic recommendation refresh remains driven by the screen-capture OCR pipeline. Deterministic recommendations are produced first; local AI re-ranking is requested only when the validated recommendation signature changes and the model is ready.
- Manual ranking action is no longer shown in the normal main-app interface. The underlying ranking capability is preserved.
- Added a floating-dashboard `Verify destination` action. It lists candidates requiring verification and saves a locality only after the driver confirms the full address from Lalamove.
- Removed routine refresh controls for detected bookings and booking-area insights.
- Preserved read-only behavior: no automatic scrolling, tapping, accepting or rejecting.
- Bumped Android version to 3.1.0 (versionCode 20) and config version to 5.

## Known limitations / not verified
- Gradle could not download its configured Gradle 8.9 distribution in the build environment. Therefore this source package is not a verified APK.
- No physical-device validation has been completed.
- AI ranking requires the optional local model to be downloaded and loaded; deterministic recommendations remain active without it.
- Only visible booking cards captured by OCR can be recognized.
