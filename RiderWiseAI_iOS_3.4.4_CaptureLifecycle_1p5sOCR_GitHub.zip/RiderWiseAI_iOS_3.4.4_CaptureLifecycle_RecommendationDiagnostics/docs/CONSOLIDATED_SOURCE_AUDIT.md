# RiderWise AI iOS 3.1.1 — Consolidated Source Audit

## Scope inspected
- XcodeGen project definition, app/extension targets, package dependencies, Info.plists and App Group entitlements.
- Main SwiftUI app/store, ReplayKit host manager, Broadcast Upload Extension, Vision OCR parser/core, recommendation engine, offline LiteRT-LM manager, Live Activity and PiP renderer.
- GitHub Actions workflow and portable validation script.

## Repairs included in this audit package
1. Added the missing `RiderWiseCore` import to `OfflineAIManager.swift` (the Xcode diagnostic showed unresolved `Recommendation` references).
2. Corrected the AVKit sample-buffer PiP delegate witness names/signatures and live time range to match Apple's current protocol documentation.
3. Attached the PiP sample-buffer display layer to a UIKit view in the SwiftUI hierarchy; the renderer now waits for the layer/controller to be ready before enabling Start PiP.
4. Configured a host-clock timebase for live sample-buffer presentation, retained the most recent dashboard image until the PiP layer is attached, and wired PiP pause/resume requests to the timebase.
5. Consolidated duplicate recommendation/reference change observers; removed the incorrectly escaped interpolation that prevented PiP recommendation frames from refreshing.
6. Fixed ReplayKit OCR queue replay: the host now de-duplicates payload IDs instead of reprocessing the whole persisted queue every polling cycle.
7. Added payload timestamps and skips stale queued frames after app relaunch so old offers are not treated as current.
8. Starts App Group polling when the dashboard appears, including when RiderWise is reopened during an already-active system broadcast; hides the system picker after the extension reports that broadcast is active.
9. Clarified that iOS owns ReplayKit broadcast termination and added an in-app instruction alert rather than implying the app can stop a system broadcast directly.
10. Tightened accepted-screen classification so a lone phrase such as “Call Customer” cannot promote a normal offer to an accepted reference; added a regression test.

## Automated validation completed in this environment
- `bash scripts/verify-portable.sh`: PASS.
- RiderWiseCore tests: 34 passed, 0 failures.
- Swift parser pass across app, extension, widget and core Swift sources.
- Info.plist parse: PASS.
- Luzon PSGC resource integrity: PASS (21,330 records; unique codes and valid parent links).
- ZIP archive integrity: PASS.

## Not verifiable in this environment
This runtime is Linux and does not contain Xcode, the iOS 27 SDK, Apple AVKit/ReplayKit/Vision frameworks, or an iPhone simulator. Therefore it cannot truthfully certify:
- Xcode type-check/link of the app and extensions.
- PiP start/stop behavior on an iPhone.
- ReplayKit broadcast extension activation and App Group provisioning.
- End-to-end OCR frame delivery while Lalamove is foregrounded.
- Device signing, App Group entitlement provisioning, battery, memory or thermal performance.

The GitHub Actions workflow remains the required Apple-SDK build gate. This package is a consolidated source repair candidate, not a claim that an Xcode/device build has already passed.


## Uploaded source package review — 2026-11-21

- Opened the owner's uploaded `RiderWiseAI_iOS_3.1.0_Complete 4.zip`; archive integrity check passed and it contains 75 entries.
- Reproduced the portable validation script in this environment: 34 core tests passed; all 32 Swift source files passed parser checks; Info.plists and matching App Group entitlements passed; the Luzon PSGC compressed resource contains 21,330 records with unique codes and valid parent links.
- The immediate GitHub failure shown by the owner is before compilation: `unzip` cannot find `RiderWiseAI_iOS_3.1.0_Complete.zip` in the workflow's current directory. This is an archive-location/repository-commit issue, not an Xcode compiler diagnostic.
- Updated `.github/workflows/ios-build.yml` to locate the named ZIP anywhere in the checkout, or use an extracted project at root or nested location by discovering `project.yml`. It emits a clear diagnostic and file listing if neither is present.
- The updated workflow still runs on GitHub-hosted macOS/Xcode for Apple framework type-checking and linking. This Linux validation does not replace that build.


## Follow-up compiler repair (2026-11-21)
- `SavedRecommendation` now exposes an explicit public memberwise initializer so the iOS app target can construct queue entries across the `RiderWiseCore` module boundary. The synthesized `Codable` decoder remains available.
- `OfflineAIManager.rank` now builds its prompt using ordinary Swift string concatenation; the previous `buildString` / `append` closure referenced helpers that did not exist in this target.
- Validation after these changes: 28 Swift files pass `swiftc -frontend -parse`; `swift test` passes all 34 RiderWiseCore tests on Linux Swift 6.2.1.
- Limitation: this environment does not include Apple's Xcode/iOS SDK, so the iOS application target and AVKit/ReplayKit integration still require GitHub Actions/Xcode validation.


## GitHub Actions run 15 follow-up (2026-11-21)
The actual Actions job log was retrieved for run 15. ZIP extraction, Xcode verification, Swift package tests, XcodeGen installation and project generation passed. The Simulator compile reported:
- `OfflineAIManager.swift:97`: actor-isolated `Engine.createConversation(with:)` called without awaiting the actor hop. Fixed by awaiting `engine.createConversation()`.
- `PiPVideoRenderer.swift:113`: immutable `let timing` passed to an inout parameter. Fixed by making it `var`.
- The AVKit conformance diagnostic also noted the background-audio prohibition witness must be nonisolated. Marked that pure, state-free witness `nonisolated`.
Validation in this environment: 28 Swift files pass parser checks and all 34 RiderWiseCore tests pass. Xcode/iOS SDK compilation remains to be confirmed by GitHub Actions.


## GitHub Actions run 17 follow-up (2026-11-21)
The actual run 17 log exposed three source issues after the prior repair:
- `BookingStatus.delivered` was referenced by the accepted-booking reference lifecycle but absent from the shared enum. Added `delivered` to the canonical `BookingStatus` enum.
- Three SwiftUI `LabeledContent` calls in `RiderWiseApp.swift` omitted the `value:` argument label. Added the explicit label.
- AVKit PiP delegate conformances inherited the renderer's main-actor isolation but were not explicitly actor-isolated. Marked both delegate conformance extensions `@MainActor`; the pure prohibition callback remains `nonisolated`.


## 3.3.4 migration work

ReplayKit Broadcast Upload Extension removed from the active target. Added iOS 27 ScreenCaptureKit picker/stream/output path and migrated PiP frame enqueue to `AVSampleBufferVideoRenderer` via `sampleBufferRenderer`. This is source-level work only; Xcode 27 build and iPhone validation remain mandatory.
