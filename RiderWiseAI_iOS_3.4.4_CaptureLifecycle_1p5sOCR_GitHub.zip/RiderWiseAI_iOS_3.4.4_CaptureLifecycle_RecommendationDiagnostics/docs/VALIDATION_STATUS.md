# Validation status — current workspace

## Executed checks

- `swift test` on Linux / Swift 6.2: **34 tests passed, 0 failed**.
- `swiftc -frontend -parse` on all iOS app, Broadcast Extension, Live Activity and core Swift files: **syntax parse passed**.
- Original Android source ZIP opened and reviewed.
- Three supplied Lalamove iPhone screenshots used as OCR parser reference fixtures.
- App icon asset and XcodeGen project configuration created.

## Not executed

- XcodeGen project generation.
- `xcodebuild` simulator compilation.
- `xcodebuild` generic iOS device compilation.
- iPhone installation, permission prompt and ReplayKit broadcast stream.
- Live Activity extension runtime.
- LiteRT-LM package resolution and model load.
- Gemma model download from the app and on-device SHA verification.
- iPhone 13 Pro Max memory, thermal, battery and scan-cadence measurements.
- Signed IPA export, TestFlight upload or physical installation.

## Why this distinction matters

The Linux Swift test target compiles only `Sources/RiderWiseCore`. The iOS app and extension depend on Apple's iOS SDK, ScreenCaptureKit, Vision, ActivityKit, WidgetKit and LiteRT-LM. They must be compiled by Xcode on macOS. Syntax parsing is not an iOS build.

## Current result

The portable core is tested. The native iOS application is a prepared source/build project, not yet a verified installable iOS release.


## Consolidated audit update (2026-11-21)
See `CONSOLIDATED_SOURCE_AUDIT.md`. Portable verification passed with 34 tests, Swift parser checks, plist validation and Luzon PSGC resource integrity. Apple Xcode build and physical iPhone PiP/ReplayKit validation remain pending.


## Uploaded source package verification — 2026-11-21

- Source ZIP: opened and integrity verified (75 entries).
- `bash scripts/verify-portable.sh`: PASS.
- RiderWiseCore unit tests: 34 passed, 0 failed.
- Swift parser: 32 Swift files passed.
- App and Broadcast Extension Info.plists: valid.
- App Group entitlement identifiers: match (`group.ph.riderwise.ai`).
- Luzon PSGC compressed data: 21,330 records, unique codes, valid parent links.
- GitHub workflow: updated to discover source ZIP or extracted project rather than assuming a single current directory.
- Still pending: GitHub macOS/Xcode 27 build, simulator/device target compilation, ReplayKit/PiP physical-device validation, signing and IPA export.


## 3.3.4 migration work

ReplayKit Broadcast Upload Extension removed from the active target. Added iOS 27 ScreenCaptureKit picker/stream/output path and migrated PiP frame enqueue to `AVSampleBufferVideoRenderer` via `sampleBufferRenderer`. This is source-level work only; Xcode 27 build and iPhone validation remain mandatory.
