# RiderWise AI 3.4.2 — Live PiP State Fix

## Changes
- PiP frame updates are no longer blocked when AVKit reports a paused playback state.
- The sample-buffer playback delegate keeps this status dashboard live and re-enqueues the latest frame.
- When no recommendation exists, PiP shows the most recently detected booking summary instead of a generic waiting message.
- App version/build updated to 3.4.2 / 342.

## Important behavior
- Lalamove offers are not automatically treated as accepted reference bookings.
- An accepted reference still requires an accepted-screen OCR result or explicit driver confirmation in RiderWise.
- Ride Mode OFF continues to suppress ride-based recommendations.
- Physical-device verification is still required; portable checks do not prove PiP behavior on iOS.
