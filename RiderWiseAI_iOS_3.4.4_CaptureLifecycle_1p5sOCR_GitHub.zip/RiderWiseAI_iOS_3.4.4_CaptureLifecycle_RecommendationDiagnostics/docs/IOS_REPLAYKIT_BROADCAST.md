# iOS screen capture: ReplayKit Broadcast Upload Extension (3.3.4 repair)

The active implementation uses Apple's user-approved ReplayKit Broadcast Upload Extension. The rider starts sharing through the iOS system broadcast picker; RiderWise does not silently capture another app. The extension performs on-device Vision OCR at a minimum 2.5-second interval and passes recognized text through the shared App Group container.

`ScreenCaptureKit` is not imported by the iOS app target: the 3.3.4 candidate failed to compile because the iOS SDK target could not resolve that module. ReplayKit APIs are deprecated in the current SDK, so this repair restores the previously used extension path as a compatibility candidate; it still requires a successful Xcode 27.1 build and real-device test.

The broadcast extension and app share `group.ph.riderwise.ai`. The app polls the bounded OCR queue and de-duplicates payload IDs. Audio capture is not enabled.
