# Third-party components and model notices

- **Apple Vision, ScreenCaptureKit, ActivityKit, WidgetKit, SwiftUI:** Apple platform frameworks; use subject to Apple's SDK and platform terms.
- **LiteRT-LM:** Google AI Edge LiteRT-LM Swift package, pinned from version 0.18.0 in `project.yml`. Review the upstream license and notices at https://github.com/google-ai-edge/LiteRT-LM before redistribution.
- **Gemma 4 E2B IT:** Model weights are downloaded by the user after explicit action; they are not bundled in this source archive. Review the model license/terms and attribution at https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm before distribution.
- **PSGC data:** Retained from the user-supplied Android source archive. Preserve the original source attribution and check the source data's current reuse terms before public redistribution.
- **Legacy geographic centroid data:** Ported from the user-supplied Android `GeographicDataset.java`. The source does not provide verifiable coordinate provenance; all such points are marked approximate and must not be presented as authoritative geocoding.

The app does not bundle model weights or an external road-routing database.

The in-app Gemma download is pinned to model repository revision `6b78abd019e61a1ca4cbe3b212d2c9ce8ff38a94` and expected SHA-256 `181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c`. The application refuses to load a file that does not match this digest.
