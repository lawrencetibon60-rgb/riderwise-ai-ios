// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "RiderWiseCore",
    platforms: [.iOS(.v17), .macOS(.v14)],
    products: [.library(name: "RiderWiseCore", targets: ["RiderWiseCore"])],
    targets: [
        .target(name: "RiderWiseCore", resources: [.process("luzon_psgc_3q_2026.json.gz"), .process("luzon_psgc_3q_2026.json"), .process("riderwise_upgrade_config.json"), .process("geographic_centroids_legacy.json")]),
        .testTarget(name: "RiderWiseCoreTests", dependencies: ["RiderWiseCore"])
    ]
)
