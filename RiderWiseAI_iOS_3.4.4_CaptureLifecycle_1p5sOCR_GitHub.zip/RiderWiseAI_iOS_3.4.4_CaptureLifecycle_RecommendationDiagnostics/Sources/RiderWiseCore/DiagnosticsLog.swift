import Foundation

public enum DiagnosticLevel:String,Codable,Sendable { case info,warning,error }
public struct DiagnosticEvent:Codable,Identifiable,Sendable {
    public var id:String
    public var timestamp:Date
    public var level:DiagnosticLevel
    public var code:String
    public var message:String
    public init(timestamp:Date = .now,level:DiagnosticLevel,code:String,message:String) {
        id=UUID().uuidString; self.timestamp=timestamp; self.level=level; self.code=code; self.message=message
    }
}
/// Local bounded diagnostics. Callers must not put customer names, phone numbers, addresses,
/// booking IDs, or raw OCR text into diagnostic messages.
public actor DiagnosticsLog {
    private let fileURL:URL
    private var events:[DiagnosticEvent]=[]
    private let limit=200
    public init(fileURL:URL) {
        self.fileURL=fileURL
        if let data=try? Data(contentsOf:fileURL),let saved=try? JSONDecoder().decode([DiagnosticEvent].self,from:data) { events=saved }
    }
    public func append(_ event:DiagnosticEvent)throws {
        events.append(event)
        if events.count>limit { events=Array(events.suffix(limit)) }
        try FileManager.default.createDirectory(at:fileURL.deletingLastPathComponent(),withIntermediateDirectories:true)
        try JSONEncoder().encode(events).write(to:fileURL,options:.atomic)
    }
    public func recent()->[DiagnosticEvent] { Array(events.reversed()) }
    public func clear()throws { events=[]; try JSONEncoder().encode(events).write(to:fileURL,options:.atomic) }
}
