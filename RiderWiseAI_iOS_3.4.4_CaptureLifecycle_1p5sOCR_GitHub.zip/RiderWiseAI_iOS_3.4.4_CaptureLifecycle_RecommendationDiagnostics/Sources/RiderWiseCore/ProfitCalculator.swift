import Foundation

public struct ProfitResult:Sendable {
    public let grossFare:Double?
    public let baseFare:Double?
    public let additionalFare:Double?
    public let fuelCost:Double?
    public let netAfterFuel:Double?
    public let earningsPerDeliveryKm:Double?
    public let earningsPerHour:Double?
    public let deliveryDistanceKm:Double?
    public let durationHours:Double?
    public let detourKm:Double?
    public var available:Bool { grossFare != nil }
}
public enum ProfitCalculator {
    /// Uses only user/provider-supplied delivery route distance, duration and fuel inputs.
    /// Booking pickup-distance (`~N km`) is never used as delivery distance.
    public static func calculate(bookings:[Booking],deliveryDistanceKm:Double?,durationHours:Double?,
                                 fuelPricePerLiter:Double?,kmPerLiter:Double?,detourKm:Double?=nil)->ProfitResult {
        let valid=bookings.filter{$0.isComplete && ($0.fare ?? 0)>0}
        guard !valid.isEmpty else {
            return ProfitResult(grossFare:nil,baseFare:nil,additionalFare:nil,fuelCost:nil,netAfterFuel:nil,
                earningsPerDeliveryKm:nil,earningsPerHour:nil,deliveryDistanceKm:deliveryDistanceKm,
                durationHours:durationHours,detourKm:detourKm)
        }
        let gross=valid.compactMap{$0.fare}.reduce(0,+)
        let base=valid.compactMap{$0.baseFare}.reduce(0,+)
        let additional=valid.compactMap{$0.additionalFare}.reduce(0,+)
        let fuel=estimatedFuelCost(distanceKm:deliveryDistanceKm,fuelPricePerLiter:fuelPricePerLiter,kmPerLiter:kmPerLiter)
        return ProfitResult(grossFare:gross,baseFare:base,additionalFare:additional,fuelCost:fuel,
            netAfterFuel:fuel.map{gross-$0},earningsPerDeliveryKm:earningsPerKm(gross,distanceKm:deliveryDistanceKm),
            earningsPerHour:earningsPerHour(gross,durationHours:durationHours),deliveryDistanceKm:deliveryDistanceKm,
            durationHours:durationHours,detourKm:detourKm.flatMap{$0.isFinite && $0>=0 ? $0:nil})
    }
    public static func estimatedFuelCost(distanceKm:Double?,fuelPricePerLiter:Double?,kmPerLiter:Double?)->Double? {
        guard let d=distanceKm,let p=fuelPricePerLiter,let e=kmPerLiter,
              d.isFinite,p.isFinite,e.isFinite,d>0,p>0,e>0 else{return nil}
        return d/e*p
    }
    private static func earningsPerKm(_ fare:Double,distanceKm:Double?)->Double? {
        guard let d=distanceKm,d.isFinite,d>0 else{return nil};return fare/d
    }
    private static func earningsPerHour(_ fare:Double,durationHours:Double?)->Double? {
        guard let h=durationHours,h.isFinite,h>0 else{return nil};return fare/h
    }
}
