import Foundation

public enum BookingHistoryPolicy {
    public static let retentionDays=7
    public static let maximumRecords=1500
    /// Rolling local history. Keeps the most recently observed records, without resetting
    /// a booking's firstSeen/seenCount when it resurfaces.
    public static func prune(_ bookings:[Booking],now:Date = .now)->[Booking] {
        let cutoff=now.addingTimeInterval(-Double(retentionDays)*24*60*60)
        let retained=bookings.filter{$0.lastSeen >= cutoff}.sorted { lhs,rhs in
            if lhs.lastSeen == rhs.lastSeen { return lhs.firstSeen > rhs.firstSeen }
            return lhs.lastSeen > rhs.lastSeen
        }
        return Array(retained.prefix(maximumRecords))
    }
}
