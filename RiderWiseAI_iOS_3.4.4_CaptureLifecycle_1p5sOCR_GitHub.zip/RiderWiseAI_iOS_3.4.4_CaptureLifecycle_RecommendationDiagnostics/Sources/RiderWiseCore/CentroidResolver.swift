import Foundation

public struct LegacyCentroid: Codable, Sendable, Hashable {
    public let name:String
    public let province:String
    public let region:String
    public let type:String
    public let latitude:Double?
    public let longitude:Double?
    public let confidence:Double
    public let aliases:[String]
    public let coordinateStatus:String
    public let coordinateSource:String
    public var point:GeoPoint? {
        guard let latitude,let longitude,latitude.isFinite,longitude.isFinite,
              (-90...90).contains(latitude),(-180...180).contains(longitude) else{return nil}
        return GeoPoint(latitude:latitude,longitude:longitude)
    }
}
private struct CentroidFile:Codable { let source:String; let warning:String; let records:[LegacyCentroid] }
public enum CentroidResolution:Sendable {
    case unique(LegacyCentroid)
    case ambiguous([LegacyCentroid])
    case notFound
}

/// Port of the original Android's embedded area/city centroid table. Numeric coordinates
/// retain their original unverified provenance and are only coarse straight-line estimates.
public final class CentroidResolver: @unchecked Sendable {
    private let records:[LegacyCentroid]
    private let index:[String:[LegacyCentroid]]
    public let warning:String
    public init(data:Data) throws {
        let file=try JSONDecoder().decode(CentroidFile.self,from:data)
        records=file.records; warning=file.warning
        var map:[String:[LegacyCentroid]]=[:]
        for record in file.records {
            for key in [record.name]+record.aliases { map[TextNormalization.normalize(key),default:[]].append(record) }
        }
        index=map
    }
    public convenience init(bundle:Bundle = .main) throws {
        guard let url=GeographicResources.url(forResource:"geographic_centroids_legacy",withExtension:"json",bundle:bundle) else {
            throw NSError(domain:"CentroidResolver",code:1,userInfo:[NSLocalizedDescriptionKey:"Legacy centroid data asset missing from app/framework bundles"])
        }
        try self.init(data:Data(contentsOf:url))
    }
    public func resolve(_ name:String)->CentroidResolution {
        let key=TextNormalization.normalize(name)
        guard !key.isEmpty,let hits=index[key],!hits.isEmpty else{return .notFound}
        let unique=Dictionary(grouping:hits,by:{$0.name}).compactMap{$0.value.first}
        if unique.count==1,let record=unique.first{return .unique(record)}
        return .ambiguous(unique)
    }
    public var recordCount:Int { records.count }
}
