import Foundation

public enum RecommendationFeedbackOutcome: String, Codable, Sendable {
    case accepted
    case rejectedAsUnsuitable
}

public struct RecommendationFeedback: Codable, Identifiable, Sendable {
    public var id: String
    public var patternKey: String
    public var outcome: RecommendationFeedbackOutcome
    public var recordedAt: Date

    public init(id: String = UUID().uuidString, patternKey: String,
                outcome: RecommendationFeedbackOutcome, recordedAt: Date = .now) {
        self.id = id
        self.patternKey = patternKey
        self.outcome = outcome
        self.recordedAt = recordedAt
    }
}

/// Small, explainable on-device preference adjustment. It learns only from explicit
/// driver feedback and never treats screen disappearance as rejection or unavailability.
public enum RecommendationLearning {
    public static func patternKey(for booking: Booking) -> String {
        let pickup = TextNormalization.normalize(booking.effectivePickup ?? "")
        let dropoff = TextNormalization.normalize(booking.effectiveDropoff ?? "")
        let vehicle = TextNormalization.normalize(booking.vehicleType ?? "unknown")
        let service = TextNormalization.normalize(booking.bookingType ?? "unknown")
        return [pickup, dropoff, vehicle, service].joined(separator: "|")
    }

    /// Bayesian-smoothed preference adjustment, bounded to +/- 0.12.
    /// A handful of decisions therefore cannot overwhelm geographic compatibility.
    public static func adjustment(for patternKey: String, feedback: [RecommendationFeedback],
                                  now: Date = .now) -> Double {
        let cutoff = now.addingTimeInterval(-180 * 24 * 60 * 60)
        let relevant = feedback.filter { $0.patternKey == patternKey && $0.recordedAt >= cutoff }
        guard !relevant.isEmpty else { return 0 }
        let accepted = Double(relevant.filter { $0.outcome == .accepted }.count)
        let rejected = Double(relevant.filter { $0.outcome == .rejectedAsUnsuitable }.count)
        let total = accepted + rejected
        // Prior = neutral 50%; shrink small samples toward zero.
        let observed = (accepted + 1) / (total + 2)
        let confidence = min(1, total / 8)
        return max(-0.12, min(0.12, (observed - 0.5) * 0.24 * confidence))
    }

    public static func adjustedScore(_ baseScore: Double, patternKeys: [String],
                                     feedback: [RecommendationFeedback]) -> Double {
        guard !patternKeys.isEmpty else { return min(1, max(0, baseScore)) }
        let meanAdjustment = patternKeys.map { self.adjustment(for: $0, feedback: feedback) }.reduce(0, +)
            / Double(patternKeys.count)
        return min(1, max(0, baseScore + meanAdjustment))
    }
}
