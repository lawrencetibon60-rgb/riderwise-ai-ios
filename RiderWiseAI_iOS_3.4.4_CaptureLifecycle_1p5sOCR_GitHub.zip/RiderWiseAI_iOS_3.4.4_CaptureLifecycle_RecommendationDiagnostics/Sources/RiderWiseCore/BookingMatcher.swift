import Foundation
public enum BookingMatcher {
    /// Merge only a unique identity match. A booking code is strongest; otherwise require
    /// fare, endpoint containment, and vehicle agreement when both sides contain a vehicle.
    public static func uniqueMatch(for incoming:Booking, among existing:[Booking])->Int? {
        if let code=incoming.bookingCode, !code.isEmpty {
            let hits=existing.indices.filter{existing[$0].bookingCode?.caseInsensitiveCompare(code) == .orderedSame}
            if hits.count == 1 { return hits[0] }
            if !hits.isEmpty { return nil }
        }
        guard incoming.isComplete,let fare=incoming.fare,let p=incoming.pickup,let d=incoming.dropoff else{return nil}
        let hits=existing.indices.filter { i in
            let old=existing[i]
            guard old.isComplete,let of=old.fare,let op=old.pickup,let od=old.dropoff,
                  abs(of-fare)<0.011, endpointMatch(p,op), endpointMatch(d,od) else{return false}
            if let a=incoming.vehicleType,let b=old.vehicleType,
               TextNormalization.normalize(a) != TextNormalization.normalize(b) { return false }
            return true
        }
        return hits.count == 1 ? hits[0] : nil
    }
    private static func endpointMatch(_ a:String,_ b:String)->Bool {
        let x=TextNormalization.normalize(a),y=TextNormalization.normalize(b)
        guard !x.isEmpty && !y.isEmpty else{return false}
        return x==y || x.contains(y) || y.contains(x)
    }
}
