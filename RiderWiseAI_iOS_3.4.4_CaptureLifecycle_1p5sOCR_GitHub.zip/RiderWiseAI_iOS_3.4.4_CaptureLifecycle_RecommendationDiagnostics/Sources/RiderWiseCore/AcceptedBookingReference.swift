import Foundation

/// Evidence from the post-acceptance Lalamove screen. A swipe gesture alone is never
/// treated as acceptance; the detector requires explicit post-acceptance UI markers.
public struct AcceptedBookingDetection: Sendable {
    public let booking: Booking
    public let bookingCode: String?
    public let matchedPreAcceptanceBookingID: String?
    public let confidence: Double
    public let evidence: [String]
}

public enum AcceptedBookingDetector {
    private static let codePattern = #"(?:#\s*|booking\s*(?:id|no\.?|number)\s*[:#-]?\s*)([A-Z0-9-]{8,})"#
    private static let moneyPattern = #"(?:₱|PHP|P)\s*([0-9,]+(?:\.[0-9]{1,2})?)"#

    /// `lines` should be OCR output from one complete screen frame, in screen coordinates.
    /// Acceptance markers visible in the supplied iPhone example include "Pick Up At",
    /// "Proof of delivery required at dropoff", "Call Customer", and a numbered order.
    public static func detect(lines: [OCRLine], previouslyDetected: [Booking] = [], now: Date = .now) -> AcceptedBookingDetection? {
        guard !lines.isEmpty else { return nil }
        let blob = lines.map(\.text).joined(separator: "\n")
        let normalized = TextNormalization.normalize(blob)
        var evidence: [String] = []
        if normalized.contains("pick up at") { evidence.append("POST_ACCEPTANCE_PICKUP_TIME") }
        if normalized.contains("proof of delivery required") { evidence.append("POST_ACCEPTANCE_PROOF_OF_DELIVERY") }
        if normalized.contains("call customer") { evidence.append("POST_ACCEPTANCE_CALL_CUSTOMER") }
        if normalized.contains("client") { evidence.append("POST_ACCEPTANCE_CLIENT_PANEL") }
        if normalized.contains("collect cash") || normalized.contains("settle with customer") { evidence.append("POST_ACCEPTANCE_PAYMENT_PANEL") }
        if normalized.contains("today") { evidence.append("POST_ACCEPTANCE_SCHEDULE_PANEL") }

        // Require multiple independent accepted-screen markers. A normal available card
        // containing a fare and two addresses cannot satisfy this gate.
        guard evidence.count >= 3,
              evidence.contains("POST_ACCEPTANCE_PICKUP_TIME"),
              evidence.contains("POST_ACCEPTANCE_CALL_CUSTOMER") || evidence.contains("POST_ACCEPTANCE_PROOF_OF_DELIVERY") else { return nil }

        let code = firstCapture(codePattern, in: blob)
        let parsed = LalamoveOCRParser.parse(lines, now: now)
        guard let extracted = parsed.bookings.first(where: { $0.isComplete }) else { return nil }
        guard let fare = extracted.fare, fare > 0, fare < 100_000 else { return nil }

        var accepted = extracted
        accepted.status = .accepted
        accepted.screenKind = .accepted
        accepted.bookingCode = code ?? extracted.bookingCode
        if let code = accepted.bookingCode, !code.isEmpty { accepted.id = "code:" + TextNormalization.normalize(code) }
        accepted.confidence = min(0.99, max(extracted.confidence, 0.85) + (code == nil ? 0 : 0.08))
        accepted.sourceEvidence = Array(Set(extracted.sourceEvidence + evidence + (code.map { ["BOOKING_CODE:" + $0] } ?? []))).sorted()

        let matchedIndex = BookingMatcher.uniqueMatch(for: accepted, among: previouslyDetected)
        let matchedID = matchedIndex.map { previouslyDetected[$0].id }
        return AcceptedBookingDetection(booking: accepted, bookingCode: accepted.bookingCode,
                                        matchedPreAcceptanceBookingID: matchedID,
                                        confidence: accepted.confidence, evidence: evidence)
    }

    private static func firstCapture(_ pattern: String, in text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              match.numberOfRanges > 1, let range = Range(match.range(at: 1), in: text) else { return nil }
        return String(text[range])
    }
}

/// Persists the first accepted booking as the reference and protects it from being
/// overwritten by later acceptances. Replacement/clearing are explicit driver actions.
public actor AcceptedBookingReferenceStore {
    private let fileURL: URL
    private var reference: Booking?

    public init(fileURL: URL) {
        self.fileURL = fileURL
        if let data = try? Data(contentsOf: fileURL),
           let saved = try? JSONDecoder().decode(Booking.self, from: data) { reference = saved }
    }

    public func current() -> Booking? { reference }

    @discardableResult
    public func recordFirstAccepted(_ detection: AcceptedBookingDetection) throws -> Bool {
        guard reference == nil else { return false }
        reference = detection.booking
        try persist()
        return true
    }

    public func replace(with booking: Booking) throws {
        var accepted = booking
        accepted.status = .accepted
        accepted.screenKind = .accepted
        reference = accepted
        try persist()
    }

    public func clear() throws {
        reference = nil
        if FileManager.default.fileExists(atPath: fileURL.path) {
            try FileManager.default.removeItem(at: fileURL)
        }
    }

    private func persist() throws {
        try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        if let reference {
            try JSONEncoder().encode(reference).write(to: fileURL, options: .atomic)
        }
    }
}
