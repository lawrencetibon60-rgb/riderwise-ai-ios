import Foundation

public enum LocationVerificationState:String,Sendable { case verified, needsUserVerification, unresolved, notApplicable }
public struct LocationVerificationResult:Sendable {
    public let state:LocationVerificationState
    public let destinationName:String
    public let proposedLocality:String?
    public let message:String
    public let requiresUserVerification:Bool
    public init(state:LocationVerificationState,destinationName:String,proposedLocality:String?,message:String) {
        self.state=state;self.destinationName=destinationName;self.proposedLocality=proposedLocality
        self.message=message;self.requiresUserVerification=state == .needsUserVerification || state == .unresolved
    }
}
public enum LocationVerificationManager {
    public static func evaluate(reference:Booking,candidate:Booking,psgc:PSGCResolver?,centroids:CentroidResolver?)->LocationVerificationResult {
        guard reference.isComplete,candidate.isComplete,let dropoff=candidate.effectiveDropoff else {
            return LocationVerificationResult(state:.notApplicable,destinationName:"",proposedLocality:nil,message:"Booking details are incomplete.")
        }
        if let psgc {
            switch psgc.resolve(dropoff) {
            case .unique(let record):
                let locality=psgc.hierarchy(record).first(where:{$0.level == "City" || $0.level == "Mun"})?.name
                return LocationVerificationResult(state:.verified,destinationName:record.name,proposedLocality:locality,message:"Exact administrative locality found in the offline PSGC index.")
            case .ambiguous(let matches):
                let hint=referenceLocality(reference:reference,psgc:psgc,centroids:centroids)
                if let hint,case .unique(let contextual)=psgc.resolve(dropoff,parentHint:hint) {
                    let locality=psgc.hierarchy(contextual).first(where:{$0.level == "City" || $0.level == "Mun"})?.name
                    return LocationVerificationResult(state:.needsUserVerification,destinationName:contextual.name,proposedLocality:locality,
                        message:"Potential locality match: \(locality ?? contextual.name). This is an inference from the reference route, not confirmation. Open the Lalamove card and verify the full address.")
                }
                return LocationVerificationResult(state:.needsUserVerification,destinationName:dropoff,proposedLocality:nil,
                    message:"Destination matches multiple PSGC places (\(matches.count)). Open the Lalamove card and verify the full destination address.")
            case .notFound:
                if dropoff.contains(","),case .unique(let addressRecord)=psgc.resolveFromAddress(dropoff) {
                    let locality=psgc.hierarchy(addressRecord).first(where:{$0.level == "City" || $0.level == "Mun"})?.name
                    return LocationVerificationResult(state:.verified,destinationName:addressRecord.name,proposedLocality:locality,message:"Full-address context uniquely resolves in the offline PSGC index.")
                }
            }
        }
        if let centroids,case .unique(let area)=centroids.resolve(dropoff),area.point != nil {
            return LocationVerificationResult(state:.verified,destinationName:area.name,proposedLocality:area.province,
                message:"Known legacy geographic index entry. Coordinate is approximate and not a road route.")
        }
        return LocationVerificationResult(state:.unresolved,destinationName:dropoff,proposedLocality:nil,
            message:"Destination could not be resolved confidently. Open the Lalamove card and verify the full address.")
    }

    public static func isAmbiguousBarePlace(_ raw:String,psgc:PSGCResolver?)->Bool {
        guard let psgc else{return false}
        let value=raw.trimmingCharacters(in:.whitespacesAndNewlines)
        if value.contains(",") { return false }
        if case .ambiguous=psgc.resolve(value) { return true }
        return false
    }

    private static func referenceLocality(reference:Booking,psgc:PSGCResolver,centroids:CentroidResolver?)->String? {
        if let drop=reference.effectiveDropoff {
            switch psgc.resolve(drop) {
            case .unique(let record): return psgc.hierarchy(record).first(where:{$0.level == "City" || $0.level == "Mun"})?.name
            case .ambiguous: return nil
            case .notFound:
                if drop.contains(","),case .unique(let record)=psgc.resolveFromAddress(drop) {
                    return psgc.hierarchy(record).first(where:{$0.level == "City" || $0.level == "Mun"})?.name
                }
            }
            if let centroids,case .unique(let area)=centroids.resolve(drop) { return area.province }
        }
        return nil
    }
}
