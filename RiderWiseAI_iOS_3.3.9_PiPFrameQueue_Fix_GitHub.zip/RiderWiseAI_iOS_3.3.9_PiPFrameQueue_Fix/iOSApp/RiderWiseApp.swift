import SwiftUI
import Vision
import UIKit
import RiderWiseCore

@main
struct RiderWiseApp: App {
    @StateObject private var store = RiderWiseStore()
    @StateObject private var capture = ScreenCaptureManager()
    @StateObject private var offlineAI = OfflineAIManager()
    @StateObject private var alerts = RecommendationAlertManager()
    @StateObject private var pipRenderer = PiPVideoRenderer()
    var body: some Scene { WindowGroup { DashboardView().environmentObject(store).environmentObject(capture).environmentObject(offlineAI).environmentObject(alerts).environmentObject(pipRenderer).preferredColorScheme(store.darkMode ? .dark : nil) } }
}

@MainActor final class RiderWiseStore: ObservableObject {
    @Published var bookings:[Booking]=[]
    @Published var selectedReferenceID:String?
    @Published var statusMessage="Ready. Start an authorized Lalamove screen broadcast to begin."
    @Published var scanInterval=2.5
    @Published var darkMode=false
    @Published var rideMode=false
    @Published var fuelPrice=0.0
    @Published var kmPerLiter=0.0
    @Published var recommendations:[Recommendation]=[]
    @Published var savedQueue:[SavedRecommendation]=[]
    @Published var diagnostics:[DiagnosticEvent]=[]
    @Published var recommendationFeedback:[RecommendationFeedback]=[]
    private let diagnosticsLog:DiagnosticsLog
    private let fileURL:URL
    private let queue:RecommendationQueue
    private let centroids:CentroidResolver?
    private let psgc:PSGCResolver?
    private var isProcessingFrame=false
    init() {
        let dir=FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0]
        try? FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        fileURL=dir.appendingPathComponent("riderwise-state.json")
        queue=RecommendationQueue(fileURL:dir.appendingPathComponent("recommendation-queue.json"))
        diagnosticsLog=DiagnosticsLog(fileURL:dir.appendingPathComponent("diagnostics.json"))
        let coreBundle=Bundle(for:RiderWiseBundleToken.self)
        centroids=try? GeographicResources.loadCentroids(bundle:coreBundle)
        psgc=try? GeographicResources.loadPSGC(bundle:coreBundle)
        if let d=try? Data(contentsOf:fileURL),let s=try? JSONDecoder().decode(PersistedState.self,from:d) {
            bookings=s.bookings; selectedReferenceID=s.referenceID
            rideMode=s.rideMode ?? false; darkMode=s.darkMode ?? false
            scanInterval=s.scanInterval ?? 2.5; fuelPrice=s.fuelPrice ?? 0; kmPerLiter=s.kmPerLiter ?? 0
            recommendationFeedback=s.recommendationFeedback ?? []
        }
        Task { savedQueue = await queue.all(); diagnostics = await diagnosticsLog.recent() }
        refreshRecommendations()
    }
    var reference:Booking? { bookings.first{$0.id==selectedReferenceID} }
    var completeCount:Int { bookings.filter{$0.isComplete}.count }
    var partialCount:Int { bookings.filter{!$0.isComplete}.count }
    func ingestOCRLines(_ lines:[OCRLine]) async {
        guard !isProcessingFrame else { return }
        isProcessingFrame = true
        defer { isProcessingFrame = false }
        let result = LalamoveOCRParser.parse(lines)
        var observedIDs = Set<String>()
        var acceptedIDs: [String] = []
        var added = 0
        if result.screenKind != .unknown {
            recordDiagnostic(.info, code: "BROADCAST_OCR_PARSED", message: "User-authorized broadcast frame parsed; card observations: \(result.bookings.count).")
        } else {
            recordDiagnostic(.warning, code: "BROADCAST_OCR_NO_LALAMOVE", message: "Broadcast frame did not contain recognized Lalamove booking markers.")
        }
        for incoming in result.bookings {
            let savedID = upsert(incoming)
            observedIDs.insert(savedID); added += 1
            if incoming.screenKind == .accepted && incoming.isComplete { acceptedIDs.append(savedID) }
        }
        for i in bookings.indices where result.screenKind != .unknown && !observedIDs.contains(bookings[i].id) && bookings[i].status != .accepted && bookings[i].status != .delivered && bookings[i].status != .dismissed {
            bookings[i].status = .notVisible
        }
        if selectedReferenceID == nil, let firstAccepted = acceptedIDs.first,
           let accepted = bookings.first(where: { $0.id == firstAccepted }), accepted.status != .delivered {
            setReference(firstAccepted)
            recordDiagnostic(.info, code: "FIRST_ACCEPTED_REFERENCE_SAVED", message: "First accepted booking was saved as the active reference.")
        } else if let current = selectedReferenceID, acceptedIDs.contains(where: { $0 != current }) {
            recordDiagnostic(.info, code: "ADDITIONAL_ACCEPTED_BOOKING", message: "Another accepted booking was detected; the existing reference was protected.")
        }
        pruneHistory(); refreshRecommendations(); persist()
        statusMessage = "Live broadcast OCR processed. \(added) card observation(s); \(completeCount) complete and \(partialCount) partial records."
    }

    func ingest(_ images:[UIImage]) async {
        guard !isProcessingFrame else { return }
        isProcessingFrame=true
        defer { isProcessingFrame=false }
        statusMessage="Analyzing \(images.count) image frame(s)…"
        var added=0
        var observedIDs=Set<String>()
        var acceptedIDs:[String]=[]
        var sawLalamoveScreen=false
        for image in images {
            do {
                let lines=try await VisionText.recognize(image)
                let result=LalamoveOCRParser.parse(lines)
                if result.screenKind != .unknown { sawLalamoveScreen=true }
                if result.diagnostics.isEmpty { recordDiagnostic(.info,code:"OCR_FRAME_PARSED",message:"OCR frame parsed; card observations: \(result.bookings.count).") }
                else { recordDiagnostic(.warning,code:"OCR_FRAME_INCOMPLETE",message:result.diagnostics.joined(separator:"; ")) }
                for incoming in result.bookings {
                    let savedID=upsert(incoming)
                    observedIDs.insert(savedID); added += 1
                    if incoming.screenKind == .accepted && incoming.isComplete { acceptedIDs.append(savedID) }
                }
            } catch { statusMessage="OCR error: \(error.localizedDescription)"; recordDiagnostic(.error,code:"OCR_FAILURE",message:error.localizedDescription) }
        }
        for i in bookings.indices where sawLalamoveScreen && !observedIDs.contains(bookings[i].id) && bookings[i].status != .accepted && bookings[i].status != .delivered && bookings[i].status != .dismissed {
            bookings[i].status = .notVisible
        }
        if selectedReferenceID == nil,let firstAccepted=acceptedIDs.first,
           let accepted=bookings.first(where:{$0.id==firstAccepted}),accepted.status != .delivered {
            setReference(firstAccepted)
            recordDiagnostic(.info,code:"FIRST_ACCEPTED_REFERENCE_SAVED",message:"First accepted booking was saved as the active reference.")
        } else if let current=selectedReferenceID,acceptedIDs.contains(where:{$0 != current}) {
            recordDiagnostic(.info,code:"ADDITIONAL_ACCEPTED_BOOKING",message:"Another accepted booking was detected; the existing reference was protected.")
        }
        pruneHistory()
        refreshRecommendations(); persist()
        statusMessage="Processed \(images.count) image(s). \(added) card observation(s); \(completeCount) complete and \(partialCount) partial records. Only submitted image frames were analyzed."
    }
    @discardableResult func upsert(_ incoming:Booking) -> String {
        if let i=bookings.firstIndex(where:{$0.id==incoming.id}) ?? BookingMatcher.uniqueMatch(for:incoming,among:bookings) {
            var old=bookings[i]; old.lastSeen = .now; old.seenCount += 1
            old.lastKnownPosition=incoming.lastKnownPosition
            if let newPickup=incoming.pickupFullAddress,let oldPickup=old.pickupFullAddress,newPickup != oldPickup { old.verifiedPickup=false }
            if let newDropoff=incoming.dropoffFullAddress,let oldDropoff=old.dropoffFullAddress,newDropoff != oldDropoff { old.verifiedDropoff=false }
            old.bookingCode = incoming.bookingCode ?? old.bookingCode
            old.pickupFullAddress = incoming.pickupFullAddress ?? old.pickupFullAddress
            old.dropoffFullAddress = incoming.dropoffFullAddress ?? old.dropoffFullAddress
            if incoming.confidence >= old.confidence {
                old.pickup=incoming.pickup ?? old.pickup; old.dropoff=incoming.dropoff ?? old.dropoff
                old.baseFare=incoming.baseFare ?? old.baseFare; old.additionalFare=incoming.additionalFare ?? old.additionalFare
                old.fare=incoming.fare ?? old.fare; old.pickupDistanceKm=incoming.pickupDistanceKm ?? old.pickupDistanceKm
                old.vehicleType=incoming.vehicleType ?? old.vehicleType; old.bookingType=incoming.bookingType ?? old.bookingType
                old.notes=incoming.notes ?? old.notes; old.paymentMethod=incoming.paymentMethod ?? old.paymentMethod
                old.sourceEvidence=incoming.sourceEvidence.isEmpty ? old.sourceEvidence : incoming.sourceEvidence
                old.confidence=max(old.confidence,incoming.confidence)
            }
            if old.isComplete && old.status == .partial {old.status = .detected}
            if incoming.screenKind == .accepted && old.status != .delivered { old.status = .accepted }
            if incoming.screenKind == .expanded || incoming.screenKind == .accepted {
                old.screenKind=incoming.screenKind
                if incoming.screenKind != .accepted && old.pickupFullAddress != nil && old.dropoffFullAddress != nil && old.status != .delivered && old.status != .accepted {
                    old.status = old.verifiedPickup && old.verifiedDropoff ? .verified : .needsVerification
                }
            }
            bookings[i]=old
            return old.id
        } else { bookings.insert(incoming,at:0); return incoming.id }
    }
    private func pruneHistory(now:Date = .now) {
        bookings=BookingHistoryPolicy.prune(bookings,now:now)
    }
    func setReference(_ id:String?) {
        let previous=selectedReferenceID
        selectedReferenceID=id
        for i in bookings.indices {
            if bookings[i].id==id { bookings[i].status = .accepted }
            else if bookings[i].id==previous && bookings[i].status == .accepted { bookings[i].status = .detected }
        }
        refreshRecommendations(); persist()
    }
    func markReferenceDelivered() {
        guard let id=selectedReferenceID,let index=bookings.firstIndex(where:{$0.id==id}) else{return}
        bookings[index].status = .delivered
        selectedReferenceID=nil
        recordDiagnostic(.info,code:"REFERENCE_MARKED_DELIVERED",message:"Driver marked the active reference as delivered; next accepted booking can become the new reference.")
        refreshRecommendations(); persist()
    }
    func setRideMode(_ enabled:Bool) { rideMode=enabled; refreshRecommendations(); persist() }
    func clearHistory() { bookings=[]; selectedReferenceID=nil; recommendations=[]; savedQueue=[]; Task { try? await queue.clear() }; persist() }
    func confirmAddresses(id:String,pickup:String,dropoff:String) {
        guard let index=bookings.firstIndex(where:{$0.id==id}),!pickup.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty,!dropoff.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else{return}
        bookings[index].pickupFullAddress=pickup.trimmingCharacters(in:.whitespacesAndNewlines)
        bookings[index].dropoffFullAddress=dropoff.trimmingCharacters(in:.whitespacesAndNewlines)
        bookings[index].verifiedPickup=true; bookings[index].verifiedDropoff=true
        if bookings[index].status != .accepted { bookings[index].status = .verified }
        recordDiagnostic(.info,code:"ADDRESS_CONFIRMED_BY_DRIVER",message:"Driver confirmed full pickup and drop-off address fields locally.")
        refreshRecommendations(); persist()
    }
    func recordDiagnostic(_ level:DiagnosticLevel,code:String,message:String) {
        let event=DiagnosticEvent(level:level,code:code,message:message)
        Task { try? await diagnosticsLog.append(event); diagnostics=await diagnosticsLog.recent() }
    }
    func markRecommendation(_ id:String,state:RecommendationState) { Task { try? await queue.mark(id,state:state); savedQueue=await queue.all() } }
    func recordRecommendationFeedback(_ recommendation: Recommendation, outcome: RecommendationFeedbackOutcome) {
        let candidates = bookings.filter { recommendation.candidateBookingIDs.contains($0.id) }
        guard !candidates.isEmpty else { return }
        for booking in candidates {
            let key = RecommendationLearning.patternKey(for: booking)
            recommendationFeedback.append(RecommendationFeedback(patternKey: key, outcome: outcome))
        }
        if recommendationFeedback.count > 500 {
            recommendationFeedback = Array(recommendationFeedback.sorted { $0.recordedAt > $1.recordedAt }.prefix(500))
        }
        recordDiagnostic(.info, code: "RECOMMENDATION_FEEDBACK_SAVED",
                         message: outcome == .accepted ? "Driver marked a suggested booking as accepted." : "Driver marked a suggested booking as unsuitable.")
        refreshRecommendations()
        persist()
    }
    func applyAIRanking(_ ranked:[Recommendation]) {
        let currentIDs=Set(recommendations.map(\.id)); let rankedIDs=Set(ranked.map(\.id))
        guard currentIDs==rankedIDs && ranked.count==recommendations.count else{return}
        recommendations=ranked
    }
    func refreshRecommendations() {
        guard rideMode else { recommendations=[]; return }
        if let ref=reference { recommendations=RecommendationEngine.referenceBased(reference:ref,candidates:bookings.filter{$0.id != ref.id && $0.status != .accepted && $0.status != .delivered && $0.status != .dismissed},centroids:centroids,psgc:psgc,history:bookings) }
        else { recommendations=RecommendationEngine.referenceFree(bookings:bookings.filter{$0.isComplete && $0.status != .accepted && $0.status != .delivered && $0.status != .dismissed},centroids:centroids,psgc:psgc) }
        recommendations = recommendations.map { recommendation in
            var adjusted = recommendation
            let candidates = bookings.filter { recommendation.candidateBookingIDs.contains($0.id) }
            let keys = candidates.map { RecommendationLearning.patternKey(for: $0) }
            adjusted.score = RecommendationLearning.adjustedScore(recommendation.score, patternKeys: keys, feedback: recommendationFeedback)
            return adjusted
        }.sorted { $0.score > $1.score }
        let saved=recommendations.map { r in SavedRecommendation(id:r.id,description:r.reason,state:r.requiresVerification ? .needsAddressVerification:.recommended,firstSeen:r.lastSeen,lastSeen:r.lastSeen,score:r.score,availability:r.availability) }
        Task { try? await queue.refresh(saved); savedQueue=await queue.all() }
    }
    func persist() {
        let state=PersistedState(bookings:bookings,referenceID:selectedReferenceID,rideMode:rideMode,darkMode:darkMode,scanInterval:scanInterval,fuelPrice:fuelPrice,kmPerLiter:kmPerLiter,recommendationFeedback:recommendationFeedback)
        if let d=try? JSONEncoder().encode(state){try? d.write(to:fileURL,options:.atomic)}
    }
}
private struct PersistedState:Codable {var bookings:[Booking];var referenceID:String?;var rideMode:Bool?;var darkMode:Bool?;var scanInterval:Double?;var fuelPrice:Double?;var kmPerLiter:Double?;var recommendationFeedback:[RecommendationFeedback]?}

enum VisionText {
    static func recognize(_ image:UIImage) async throws -> [RiderWiseCore.OCRLine] {
        guard let cg=image.cgImage else {throw NSError(domain:"RiderWiseOCR",code:1,userInfo:[NSLocalizedDescriptionKey:"Image could not be decoded"])}
        return try await Task.detached(priority:.userInitiated) {
            let request=VNRecognizeTextRequest()
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection=true
            request.recognitionLanguages=["en-US"]
            try VNImageRequestHandler(cgImage:cg).perform([request])
            return (request.results ?? []).compactMap { observation -> RiderWiseCore.OCRLine? in
                guard let text=observation.topCandidates(1).first else{return nil}
                let b=observation.boundingBox
                return RiderWiseCore.OCRLine(text:text.string,confidence:Double(text.confidence),x:b.minX,y:b.minY,width:b.width,height:b.height)
            }
        }.value
    }
}

struct DashboardView:View {
    @EnvironmentObject private var store:RiderWiseStore
    @EnvironmentObject private var capture:ScreenCaptureManager
    @EnvironmentObject private var offlineAI:OfflineAIManager
    @EnvironmentObject private var alerts:RecommendationAlertManager
    @EnvironmentObject private var pipRenderer:PiPVideoRenderer
    @State private var showSettings=false
    @State private var showConfirmClear=false
    @State private var bookingToVerify:Booking?
    @State private var bookingToSetReference:Booking?
    @AppStorage("riderwise.dashboardDensity") private var dashboardDensity="comfortable"
    var body:some View {
        NavigationStack {
            ScrollView {
                VStack(spacing:16) {
                    header
                    HStack(spacing:10) {
                        metric("Complete",value:store.completeCount,icon:"checkmark.circle.fill")
                        metric("Partial",value:store.partialCount,icon:"exclamationmark.circle.fill")
                        metric("Saved",value:store.recommendations.count,icon:"bookmark.fill")
                    }
                    referenceCard
                    ProfitEstimateCard(reference:store.reference,recommendations:store.recommendations,bookings:store.bookings)
                    VStack(alignment:.leading,spacing:10) {
                        HStack {Text("Detected bookings").font(.headline);Spacer();Text("Newest first").font(.caption).foregroundStyle(.secondary)}
                        if store.bookings.isEmpty {ContentUnavailableView("No bookings yet",systemImage:"doc.text.viewfinder",description:Text("Start user-approved full-display screen capture, then switch to Lalamove to analyze visible booking cards."))}
                        ForEach(store.bookings) { booking in BookingRow(booking:booking,isReference:store.selectedReferenceID==booking.id,onReference:{
                            if store.selectedReferenceID==booking.id { store.setReference(nil) } else { bookingToSetReference=booking }
                        },onVerify:{ bookingToVerify=booking }) }
                    }
                    recommendationsCard
                    savedQueueCard
                    DiagnosticsCard(events:store.diagnostics)
                    privacyNote
                }.padding(dashboardDensity == "compact" ? 8 : 16)
            }
            .navigationTitle("RiderWise AI")
            .toolbar {
                ToolbarItem(placement:.topBarTrailing) {Button {showSettings=true} label:{Image(systemName:"gearshape")}}
            }
            .sheet(isPresented:$showSettings) {SettingsView().environmentObject(store).environmentObject(offlineAI).environmentObject(alerts)}
            .sheet(item:$bookingToVerify) { booking in AddressVerificationView(booking:booking) { pickup,dropoff in store.confirmAddresses(id:booking.id,pickup:pickup,dropoff:dropoff); bookingToVerify=nil } }
            .confirmationDialog("Clear local booking history?",isPresented:$showConfirmClear,titleVisibility:.visible) {
                Button("Clear history",role:.destructive){store.clearHistory()}
            }
            .confirmationDialog("Confirm this booking was accepted in Lalamove?",isPresented:Binding(get:{bookingToSetReference != nil},set:{if !$0 {bookingToSetReference=nil}}),titleVisibility:.visible) {
                Button("Set accepted reference") { if let bookingToSetReference { store.setReference(bookingToSetReference.id) }; bookingToSetReference=nil }
                Button("Cancel",role:.cancel) { bookingToSetReference=nil }
            } message: { Text("Only choose this if you have already accepted this exact booking in Lalamove. Available offers must not be used as an accepted reference.") }
        }
        .onAppear {
            capture.scanInterval=store.scanInterval
            alerts.prime(store.recommendations)
            capture.onOCRLines = { lines in await store.ingestOCRLines(lines) }
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:store.selectedReferenceID) { _,_ in
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:store.recommendations.map { "\($0.id):\($0.score):\($0.label):\($0.totalFare)" }.joined(separator:"|")) { _,_ in
            alerts.announceNewRecommendations(store.recommendations)
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:store.reference.map { "\($0.id):\($0.pickup ?? ""):\($0.dropoff ?? ""):\($0.fare ?? 0)" } ?? "none") { _,_ in
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:capture.isCapturing) { _,active in
            pipRenderer.update(image: currentPiPFrame())
        }
        .task(id:store.recommendations.map{"\($0.id):\($0.score):\($0.label)"}.joined(separator:"|")) { if offlineAI.isReady { store.applyAIRanking(await offlineAI.rank(store.recommendations)) } }
        .onChange(of:offlineAI.isReady) { _,ready in if ready { Task { store.applyAIRanking(await offlineAI.rank(store.recommendations)) } } }
        .onChange(of:store.scanInterval) { _,value in capture.scanInterval=value; store.persist() }
    }
    private func currentPiPFrame() -> UIImage {
        let referenceText: String
        if let ref = store.reference {
            referenceText = "\(ref.pickup ?? "Unknown") → \(ref.dropoff ?? "Unknown")"
        } else {
            referenceText = "No accepted booking selected"
        }
        let top = store.recommendations.first
        let title = top?.label ?? ""
        let detail = top?.reason ?? (store.rideMode ? "Waiting for compatible bookings." : "Turn Ride Mode on to enable recommendations.")
        return PiPVideoRenderer.makeDashboardFrame(
            reference: referenceText,
            topRecommendation: title,
            detail: detail,
            count: store.recommendations.count,
            scanning: capture.isCapturing
        )
    }

    private var header:some View {
        VStack(alignment:.leading,spacing:12) {
            HStack {
                VStack(alignment:.leading,spacing:3) {Text("Lalamove booking intelligence").font(.headline);Text("iPhone-native companion").font(.caption).foregroundStyle(.secondary)}
                Spacer()
                Label(store.rideMode ? "Ride Mode ON":"Ride Mode OFF",systemImage:"car.side.fill")
                    .font(.caption.weight(.semibold)).padding(8).background(.orange.opacity(0.12),in:Capsule())
            }
            Button {
                if capture.isCapturing {
                    capture.stop()
                } else {
                    capture.presentSystemPicker()
                }
            } label: {
                Label(capture.isCapturing ? "How to stop screen scan" : "Start authorized screen scan", systemImage: capture.isCapturing ? "stop.circle.fill" : "record.circle")
                    .font(.headline).frame(maxWidth:.infinity).padding()
                    .background(capture.isCapturing ? Color.red.opacity(0.12):Color.blue.opacity(0.12),in:RoundedRectangle(cornerRadius:14))
            }
            Text(capture.status).font(.caption).foregroundStyle(.secondary)
            Button {
                let frame = currentPiPFrame()
                if pipRenderer.isActive { pipRenderer.stop() }
                else { pipRenderer.start(image: frame) }
            } label: {
                Label(pipRenderer.isActive ? "Close PiP dashboard" : "Start PiP dashboard",
                      systemImage: pipRenderer.isActive ? "pip.exit" : "pip.enter")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity).padding(.vertical, 11)
                    .background(.blue.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
            }
            .disabled(!pipRenderer.isReady)
            Text(pipRenderer.status).font(.caption).foregroundStyle(.secondary)
            Text(store.statusMessage).font(.caption).foregroundStyle(.secondary)
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:18))
            .overlay(alignment: .bottomTrailing) {
                PiPDisplayLayerHost(renderer: pipRenderer)
                    .frame(width: 320, height: 180)
                    .opacity(0.001)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
    }
    private var referenceCard:some View {
        VStack(alignment:.leading,spacing:8) {
            HStack {Text("Active reference booking").font(.headline);Spacer();Button("Clear"){store.setReference(nil)}.font(.caption)}
            if let ref=store.reference {
                Text("\(ref.pickup ?? "Unknown") → \(ref.dropoff ?? "Unknown")").font(.subheadline.weight(.semibold))
                Text("₱\(ref.fare ?? 0, specifier:"%.2f") · \(ref.vehicleType ?? "Vehicle unknown")").font(.caption).foregroundStyle(.secondary)
                Text("First accepted booking is protected as the reference until you mark it delivered or replace it.").font(.caption2).foregroundStyle(.secondary)
                Button("Mark delivered · clear reference") { store.markReferenceDelivered() }.font(.caption.weight(.semibold))
            } else {Text("No accepted reference set. You can select a booking below, or use reference-free potential-pair comparisons.").font(.caption).foregroundStyle(.secondary)}
            if !store.rideMode { Text("Ride Mode is OFF. Ride-based recommendations are paused; captured booking history is retained.").font(.caption).foregroundStyle(.orange) }
        }.frame(maxWidth:.infinity,alignment:.leading).padding().background(.orange.opacity(0.09),in:RoundedRectangle(cornerRadius:16))
    }
    private var recommendationsCard:some View {
        VStack(alignment:.leading,spacing:10) {
            Text(store.reference == nil ? "Potential booking combinations":"Saved compatible bookings").font(.headline)
            if store.recommendations.isEmpty {Text("No eligible combinations yet. Complete booking details are needed.").font(.caption).foregroundStyle(.secondary)}
            ForEach(store.recommendations,id:\.id) { r in
                VStack(alignment:.leading,spacing:4) {
                    HStack {Text(r.label).font(.subheadline.weight(.semibold));Spacer();Text("Rank \(Int(r.score*100))").font(.caption.monospacedDigit())}
                    Text(r.reason).font(.caption).foregroundStyle(.secondary)
                    if r.requiresVerification {
                        Label("Open the Lalamove booking card and confirm its full addresses before treating this as compatible.",
                              systemImage:"exclamationmark.magnifyingglass")
                            .font(.caption2.weight(.semibold)).foregroundStyle(.orange)
                    }
                    Text(r.availability.replacingOccurrences(of:"_",with:" ")).font(.caption2).foregroundStyle(.orange)
                    HStack {
                        Button("I accepted this") { store.recordRecommendationFeedback(r, outcome: .accepted) }.font(.caption2)
                        Spacer()
                        Button("Not suitable") { store.recordRecommendationFeedback(r, outcome: .rejectedAsUnsuitable) }.font(.caption2)
                    }
                }.padding(10).background(.secondary.opacity(0.08),in:RoundedRectangle(cornerRadius:10))
            }
        }.frame(maxWidth:.infinity,alignment:.leading).padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
    }
    private var savedQueueCard:some View {
        VStack(alignment:.leading,spacing:8) {
            HStack { Text("Saved recommendation history").font(.headline); Spacer(); Text("\(store.savedQueue.count)").font(.caption.monospacedDigit()).foregroundStyle(.secondary) }
            if store.savedQueue.isEmpty { Text("No saved recommendation history yet.").font(.caption).foregroundStyle(.secondary) }
            ForEach(store.savedQueue) { item in
                VStack(alignment:.leading,spacing:5) {
                    HStack { Text(item.state.rawValue).font(.caption.bold()); Spacer(); Text(item.availability).font(.caption2).foregroundStyle(.secondary) }
                    Text(item.description).font(.caption)
                    HStack { Text("Score \(Int(item.score*100))% · Last seen \(item.lastSeen.formatted(date:.omitted,time:.shortened))").font(.caption2).foregroundStyle(.secondary); Spacer(); if item.state != .rejectedByDriver && item.state != .dismissed && item.state != .accepted && item.state != .expiredConfirmed { Button("Dismiss") { store.markRecommendation(item.id,state:.dismissed) }.font(.caption2); Button("Accepted externally") { store.markRecommendation(item.id,state:.accepted) }.font(.caption2) } }
                }.padding(10).background(.secondary.opacity(0.08),in:RoundedRectangle(cornerRadius:10))
            }
        }.frame(maxWidth:.infinity,alignment:.leading).padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
    }
    private var privacyNote:some View {
        Label("Read-only companion. Screen video is analyzed on-device only after you start and approve the iOS broadcast. No automatic Lalamove taps, scrolling, acceptance or rejection.",systemImage:"hand.raised.fill")
            .font(.caption2).foregroundStyle(.secondary).frame(maxWidth:.infinity,alignment:.leading)
    }
    private func metric(_ title:String,value:Int,icon:String)->some View {
        VStack(alignment:.leading,spacing:5) {Label(title,systemImage:icon).font(.caption2).foregroundStyle(.secondary);Text("\(value)").font(.title2.bold().monospacedDigit())}
            .frame(maxWidth:.infinity,alignment:.leading).padding(12).background(.thinMaterial,in:RoundedRectangle(cornerRadius:13))
    }
}
struct BookingRow:View {
    let booking:Booking
    let isReference:Bool
    let onReference:()->Void
    let onVerify:()->Void
    var body:some View {
        VStack(alignment:.leading,spacing:8) {
            HStack {Text(booking.status.rawValue.uppercased()).font(.caption2.bold()).foregroundStyle(booking.isComplete ? .green:.orange);Spacer();if isReference{Label("REFERENCE",systemImage:"bookmark.fill").font(.caption2.bold()).foregroundStyle(.orange)}}
            Text("\(booking.pickup ?? "Pickup incomplete") → \(booking.dropoff ?? "Drop-off incomplete")").font(.subheadline.weight(.semibold))
            HStack {if let f=booking.fare{Text("₱\(f,specifier:"%.2f")")};if let v=booking.vehicleType{Text(v)};if let t=booking.bookingType{Text(t)}}
                .font(.caption).foregroundStyle(.secondary)
            if let km=booking.pickupDistanceKm {Text(String(format:"~%.1f km rider-to-pickup (not delivery distance)",km)).font(.caption2).foregroundStyle(.secondary)}
            if let note=booking.notes {Text(note).font(.caption).lineLimit(2)}
            if booking.screenKind == .expanded || booking.screenKind == .accepted {
                Text("\(booking.paymentMethod ?? "Payment method unknown") · \(booking.verifiedPickup && booking.verifiedDropoff ? "Driver verified addresses":"Address verification needed")").font(.caption2).foregroundStyle(.secondary)
            }
            HStack {Text("Seen \(booking.seenCount) time(s)").font(.caption2).foregroundStyle(.secondary);Spacer();Button("Verify addresses",action:onVerify).font(.caption2);Button(isReference ? "Clear reference":"Confirm accepted",action:onReference).font(.caption.weight(.semibold)).disabled(!booking.isComplete)}
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:14))
    }
}
struct AddressVerificationView:View {
    let booking:Booking
    let onSave:(String,String)->Void
    @Environment(\.dismiss) private var dismiss
    @State private var pickup:String
    @State private var dropoff:String
    init(booking:Booking,onSave:@escaping (String,String)->Void) {
        self.booking=booking; self.onSave=onSave
        _pickup=State(initialValue:booking.pickupFullAddress ?? booking.pickup ?? "")
        _dropoff=State(initialValue:booking.dropoffFullAddress ?? booking.dropoff ?? "")
    }
    var body:some View {
        NavigationStack { Form {
            Section("Pickup full address") { TextField("Check the Lalamove pickup address",text:$pickup,axis:.vertical).lineLimit(2...4) }
            Section("Drop-off full address") { TextField("Check the Lalamove destination address",text:$dropoff,axis:.vertical).lineLimit(2...4) }
            Section { Text("Open the offer in Lalamove first. Copy or check the complete pickup and drop-off addresses shown on the expanded card. Do not confirm using only a barangay or city name. This checks administrative locality identity; it does not create road coordinates or a road route.").font(.caption).foregroundStyle(.secondary) }
        }.navigationTitle("Verify booking addresses").navigationBarTitleDisplayMode(.inline).toolbar {
            ToolbarItem(placement:.cancellationAction){Button("Cancel"){dismiss()}}
            ToolbarItem(placement:.confirmationAction){Button("Confirm") { onSave(pickup,dropoff); dismiss() }.disabled(pickup.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || dropoff.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)}
        }}
    }
}
struct ProfitEstimateCard:View {
    let reference:Booking?
    let recommendations:[Recommendation]
    let bookings:[Booking]
    @AppStorage("riderwise.profit.deliveryKm") private var deliveryKm=""
    @AppStorage("riderwise.profit.hours") private var hours=""
    @AppStorage("riderwise.profit.fuelPrice") private var fuelPrice=""
    @AppStorage("riderwise.profit.kmPerLiter") private var efficiency=""
    @State private var selectedScenarioID="reference"
    private var selectedRecommendation:Recommendation? { recommendations.first{$0.id==selectedScenarioID} }
    private var includedBookings:[Booking] {
        if let selectedRecommendation { let ids=Set(selectedRecommendation.bookingIDs); return bookings.filter{ids.contains($0.id)} }
        if let reference { return [reference] }
        return []
    }
    var body:some View {
        VStack(alignment:.leading,spacing:9) {
            Text("Profit estimate").font(.headline)
            Text("Uses only your entered delivery-route distance and time. The orange Lalamove pickup km is never used as delivery distance.").font(.caption2).foregroundStyle(.secondary)
            if reference != nil || !recommendations.isEmpty {
                Picker("Booking scenario",selection:$selectedScenarioID) {
                    if reference != nil { Text("Accepted reference only").tag("reference") }
                    ForEach(recommendations) { rec in Text(rec.label).tag(rec.id) }
                }.pickerStyle(.menu)
            }
            HStack {TextField("Delivery km",text:$deliveryKm).keyboardType(.decimalPad);TextField("Hours",text:$hours).keyboardType(.decimalPad)}
            HStack {TextField("Fuel ₱/L",text:$fuelPrice).keyboardType(.decimalPad);TextField("Km/L",text:$efficiency).keyboardType(.decimalPad)}
            let result=ProfitCalculator.calculate(bookings:includedBookings,deliveryDistanceKm:Double(deliveryKm),durationHours:Double(hours),fuelPricePerLiter:Double(fuelPrice),kmPerLiter:Double(efficiency),detourKm:selectedRecommendation?.detourKm)
            HStack {Text("Bookings included");Spacer();Text("\(includedBookings.count)").monospacedDigit()}
            HStack {Text("Base fare");Spacer();Text(result.baseFare.map{String(format:"₱%.2f",$0)} ?? "Unknown")}
            HStack {Text("Additional fare");Spacer();Text(result.additionalFare.map{String(format:"₱%.2f",$0)} ?? "Unknown")}
            HStack {Text("Combined fare");Spacer();Text(result.grossFare.map{String(format:"₱%.2f",$0)} ?? "Unknown").bold()}
            HStack {Text("Estimated fuel cost");Spacer();Text(result.fuelCost.map{String(format:"₱%.2f",$0)} ?? "Enter distance, fuel price and km/L")}
            HStack {Text("Net after fuel");Spacer();Text(result.netAfterFuel.map{String(format:"₱%.2f",$0)} ?? "Unavailable").bold()}
            if let perHour=result.earningsPerHour { Text(String(format:"Gross per hour: ₱%.2f",perHour)).font(.caption).foregroundStyle(.secondary) }
            if let detour=result.detourKm { Text(String(format:"Route-search detour (straight-line estimate): %.1f km",detour)).font(.caption2).foregroundStyle(.secondary) }
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
        .onAppear { if reference == nil,let first=recommendations.first { selectedScenarioID=first.id } }
        .onChange(of:recommendations.map(\.id)) { _,ids in
            if selectedScenarioID != "reference" && !ids.contains(selectedScenarioID) { selectedScenarioID=ids.first ?? "reference" }
            if reference == nil && selectedScenarioID == "reference",let first=ids.first { selectedScenarioID=first }
        }
    }
}
struct DiagnosticsCard:View {
    let events:[DiagnosticEvent]
    var body:some View {
        VStack(alignment:.leading,spacing:7) {
            Text("Diagnostics").font(.headline)
            if events.isEmpty {Text("No diagnostics recorded.").font(.caption).foregroundStyle(.secondary)}
            ForEach(events.prefix(5)) { event in
                HStack(alignment:.top) { Text(event.level.rawValue.uppercased()).font(.caption2.bold()).foregroundStyle(event.level == .error ? .red : (event.level == .warning ? .orange:.secondary)); VStack(alignment:.leading){Text(event.code).font(.caption.bold());Text(event.message).font(.caption2).foregroundStyle(.secondary)};Spacer();Text(event.timestamp.formatted(date:.omitted,time:.shortened)).font(.caption2).foregroundStyle(.secondary) }
            }
            Text("Local diagnostics only. Do not add customer addresses, phone numbers or raw booking identifiers.").font(.caption2).foregroundStyle(.secondary)
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
    }
}
struct SettingsView:View {
    @EnvironmentObject private var store:RiderWiseStore
    @EnvironmentObject private var offlineAI:OfflineAIManager
    @EnvironmentObject private var alerts:RecommendationAlertManager
    @AppStorage("riderwise.dashboardDensity") private var dashboardDensity="comfortable"
    var body:some View {
        NavigationStack {Form {
            Section("Scanning") {
                LabeledContent("Default scan interval",value:String(format:"%.1f seconds",store.scanInterval))
                Slider(value:$store.scanInterval,in:2.5...10,step:0.5)
                Text("Live scanning uses Apple ScreenCaptureKit after you approve the iOS screen-sharing picker. On-device OCR samples at the configured interval; fast scrolling may still cause missed offers.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Preferences") {
                Toggle("Ride Mode",isOn:$store.rideMode).onChange(of:store.rideMode) { _,value in store.setRideMode(value) }
                Toggle("Dark mode",isOn:$store.darkMode).onChange(of:store.darkMode) { _,_ in store.persist() }
                Picker("Dashboard layout",selection:$dashboardDensity) {
                    Text("Comfortable").tag("comfortable")
                    Text("Compact").tag("compact")
                }
            }
            Section("Recommendation alerts") {
                Toggle("Play sound for new recommendations", isOn: $alerts.isEnabled)
                Button("Test notification sound") { alerts.playTestSound() }
                Text("A short iOS notification sound plays when a newly detected recommendation is added. Existing recommendations do not repeatedly trigger alerts. Sound behavior may depend on iPhone mute, Focus and notification/audio settings.").font(.caption2).foregroundStyle(.secondary)
            }
            Section("Advanced Offline AI") {
                Text(offlineAI.status).font(.caption).foregroundStyle(.secondary)
                if offlineAI.isDownloading { ProgressView() }
                Button("Download Gemma 4 E2B (~2.59 GB)") { Task { await offlineAI.downloadModel() } }.disabled(offlineAI.isDownloading || offlineAI.isReady)
                Button("Load Offline AI") { Task { await offlineAI.loadModel() } }.disabled(offlineAI.isDownloading || offlineAI.isReady)
                Text("The model is optional and downloaded only after your approval. Use Wi-Fi and allow at least 5 GB free storage. If it cannot load, OCR and deterministic recommendations continue without AI.")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            Section("Safety") {
                Text("The app never accepts or rejects bookings, scrolls Lalamove, or claims that previously seen offers remain available.")
                Text("Screen broadcast is user-started and user-stopped through iOS controls. Only shared video frames are analyzed; rapid scrolling can cause missed offers.")
            }
            Section("Build status") {
                LabeledContent("Offline AI", value: offlineAI.isReady ? "Loaded on-device" : "Optional model / not loaded")
                LabeledContent("Live screen capture", value: "Requires iPhone verification")
                LabeledContent("Along-the-way matching", value: "Geographic estimate; address confirmation required")
            }
        }.navigationTitle("Settings").navigationBarTitleDisplayMode(.inline)}
    }
}
