#if targetEnvironment(simulator)
import Foundation
import Combine
import SwiftUI
import RiderWiseCore

/// Simulator-safe stand-in. Full-display capture is validated on physical iOS 27 devices.
@MainActor
final class ScreenCaptureManager: ObservableObject {
    @Published private(set) var isCapturing = false
    @Published private(set) var status = "Screen capture is available on a physical iOS 27 device."
    @Published var scanInterval: TimeInterval = 2.5
    var onOCRLines: (([OCRLine]) async -> Void)?

    func beginMonitoring() {}
    func presentSystemPicker() {
        status = "ScreenCaptureKit full-display capture requires a physical iOS 27 device."
    }
    func stop() {
        isCapturing = false
        status = "Screen capture is unavailable in the iOS Simulator."
    }
}
#else
import Foundation
import Combine
import SwiftUI
import UIKit
import ScreenCaptureKit
import Vision
import AVFoundation
import CoreMedia
import CoreVideo
import RiderWiseCore

/// User-authorized iOS 27 full-display capture. No extension or App Group queue is used.
@MainActor
final class ScreenCaptureManager: NSObject, ObservableObject {
    @Published private(set) var isCapturing = false
    @Published private(set) var status = "Screen capture is off. Tap Start and choose the full display in Apple's sharing picker."
    @Published var scanInterval: TimeInterval = 2.5 {
        didSet {
            currentScanInterval = max(2.5, scanInterval)
            if isCapturing {
                status = String(format: "ScreenCaptureKit active · offline Vision OCR every %.1f seconds", currentScanInterval)
            }
        }
    }

    nonisolated(unsafe) private var currentScanInterval: TimeInterval = 2.5
    nonisolated(unsafe) private var lastOCRUptime: TimeInterval = 0

    var onOCRLines: (([OCRLine]) async -> Void)?

    private let picker = SCContentSharingPicker.shared
    private var stream: SCStream?
    private let frameQueue = DispatchQueue(label: "ph.riderwise.screencapture.frames", qos: .userInitiated)
    private var isStarting = false
    private var isPickerObserverRegistered = false
    private var isPickerRequestPending = false

    override init() {
        super.init()
    }

    func beginMonitoring() {
        // ScreenCaptureKit is controlled by the in-app system picker; no background polling is needed.
    }

    func presentSystemPicker() {
        guard UIApplication.shared.applicationState == .active else {
            status = "RiderWise must be in the foreground before opening Apple's screen-sharing picker. Return to RiderWise and tap Start again."
            return
        }
        guard SCContentSharingPicker.shared.isAvailable else {
            status = "Apple's ScreenCaptureKit picker reports unavailable on this device or OS version. iOS 27 or later is required."
            print("[RiderWise.ScreenCapture] picker unavailable; OS=\(ProcessInfo.processInfo.operatingSystemVersionString)")
            return
        }
        guard !isCapturing, !isStarting, !isPickerRequestPending else {
            status = isCapturing ? "Screen scan is already active." : "The screen-sharing picker is already opening."
            return
        }
        var pickerConfiguration = SCContentSharingPickerConfiguration()
        pickerConfiguration.showsMicrophoneControl = false
        picker.defaultConfiguration = pickerConfiguration
        // Register exactly once before presenting. Apple delivers the selected
        // SCContentFilter through this observer after the rider confirms sharing.
        if !isPickerObserverRegistered {
            picker.add(self)
            isPickerObserverRegistered = true
        }
        // Critical activation step: registering the observer alone does not
        // activate the system picker. Apple's iOS 27 sample activates it before
        // presentation; without this, present() can silently show nothing.
        picker.isActive = true
        isPickerRequestPending = true
        status = "Opening Apple's full-display sharing picker…"

        // Full-display capture uses present() after activation and observer setup.
        print("[RiderWise.ScreenCapture] picker activated; presenting full-display picker; appState=active; iOS=\(ProcessInfo.processInfo.operatingSystemVersionString)")
        picker.present()

        // isActive is the picker's activation state, not a presentation
        // completion callback. Let the observer's update/cancel/failure methods
        // report the actual result instead of using a short polling timeout.
    }

    func stop() {
        guard let stream else {
            isCapturing = false
            status = "Screen capture is already stopped."
            return
        }
        Task { [weak self] in
            do {
                try await stream.stopCapture()
                await MainActor.run {
                    self?.stream = nil
                    self?.isCapturing = false
                    self?.isStarting = false
                    self?.picker.isActive = false
                    self?.status = "Screen scan stopped."
                }
            } catch {
                await MainActor.run {
                    self?.status = "Could not stop screen capture: \(error.localizedDescription)"
                }
            }
        }
    }

    private func startCapture(using filter: SCContentFilter) {
        guard !isStarting else { return }
        isPickerRequestPending = false
        isStarting = true
        status = "Starting the screen stream you approved…"

        Task { [weak self] in
            guard let self else { return }
            do {
                if let oldStream = self.stream {
                    try? await oldStream.stopCapture()
                }
                let configuration = SCStreamConfiguration()
                configuration.width = 1170
                configuration.height = 2532
                configuration.capturesAudio = false

                let newStream = SCStream(filter: filter, configuration: configuration, delegate: self)
                try newStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: self.frameQueue)
                try await newStream.startCapture()
                self.stream = newStream
                self.lastOCRUptime = 0
                self.isCapturing = true
                self.status = String(format: "Screen scan active · on-device Vision OCR every %.1f seconds", max(2.5, self.scanInterval))
            } catch {
                self.stream = nil
                self.isCapturing = false
                self.status = "Screen scan could not start. Check iOS screen-sharing permission and try again: \(error.localizedDescription)"
            }
            self.isStarting = false
        }
    }

    nonisolated private func recognizeText(in pixelBuffer: CVPixelBuffer) -> [OCRLine] {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        request.recognitionLanguages = ["en-US"]
        do {
            try VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
            return (request.results ?? []).compactMap { observation in
                guard let candidate = observation.topCandidates(1).first else { return nil }
                let box = observation.boundingBox
                return OCRLine(
                    text: candidate.string,
                    confidence: Double(candidate.confidence),
                    x: box.minX, y: box.minY, width: box.width, height: box.height
                )
            }
        } catch {
            return []
        }
    }
}

extension ScreenCaptureManager: SCContentSharingPickerObserver {
    nonisolated func contentSharingPicker(
        _ picker: SCContentSharingPicker,
        didUpdateWith filter: SCContentFilter,
        for stream: SCStream?
    ) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            self.isPickerRequestPending = false
            self.startCapture(using: filter)
        }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didCancelFor stream: SCStream?) {
        Task { @MainActor [weak self] in
            guard let self, !self.isCapturing else { return }
            self.isPickerRequestPending = false
            self.isStarting = false
            picker.isActive = false
            self.status = "Screen sharing was cancelled. No screen content was captured. Tap Start authorized screen scan to try again."
        }
    }

    nonisolated func contentSharingPickerStartDidFailWithError(_ error: Error) {
        Task { @MainActor [weak self] in
            self?.isPickerRequestPending = false
            self?.isStarting = false
            self?.status = "Apple's screen-sharing picker failed: \(error.localizedDescription). Try again from RiderWise."
        }
    }
}

extension ScreenCaptureManager: SCStreamOutput {
    nonisolated func stream(
        _ stream: SCStream,
        didOutputSampleBuffer sampleBuffer: CMSampleBuffer,
        of type: SCStreamOutputType
    ) {
        guard type == .screen, sampleBuffer.isValid,
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let now = ProcessInfo.processInfo.systemUptime
        let interval = currentScanInterval
        guard now - lastOCRUptime >= interval else { return }
        lastOCRUptime = now
        let lines = recognizeText(in: pixelBuffer)
        guard !lines.isEmpty else { return }
        Task { @MainActor [weak self] in
            guard let self, self.isCapturing else { return }
            await self.onOCRLines?(lines)
        }
    }
}

extension ScreenCaptureManager: SCStreamDelegate {
    nonisolated func stream(_ stream: SCStream, didStopWithError error: Error) {
        Task { @MainActor [weak self] in
            self?.stream = nil
            self?.isCapturing = false
            self?.isStarting = false
            self?.status = "Screen scan stopped by iOS: \(error.localizedDescription)"
        }
    }
}

#endif
