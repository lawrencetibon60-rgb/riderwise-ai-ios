import Foundation
import Combine
import SwiftUI
import ScreenCaptureKit
import Vision
import CoreMedia
import RiderWiseCore

/// iOS 27+ ScreenCaptureKit capture. The user explicitly selects the display
/// through Apple's system picker; capture is never started silently.
@MainActor
final class ScreenCaptureManager: NSObject, ObservableObject {
    @Published private(set) var isCapturing = false
    @Published private(set) var status = "Screen scan is off. Tap Start and approve Apple's screen-sharing picker."
    @Published var scanInterval: TimeInterval = 2.5
    @Published var showBroadcastPicker = false
    @Published var showStopInstructions = false
    var onOCRLines: (([OCRLine]) async -> Void)?

    private let picker = SCContentSharingPicker.shared
    private let sampleQueue = DispatchQueue(label: "ph.riderwise.screencapture.samples", qos: .userInitiated)
    private var stream: SCStream?
    private var lastOCRTime: TimeInterval = 0
    private var ocrInProgress = false
    private var sequence: UInt64 = 0

    override init() {
        super.init()
        picker.add(self)
    }

    func presentSystemPicker() {
        guard picker.isAvailable else {
            status = "ScreenCaptureKit picker is unavailable on this device or OS."
            return
        }
        var configuration = SCContentSharingPickerConfiguration()
        configuration.allowedPickerModes = [.singleDisplay]
        configuration.showsMicrophoneControl = false
        picker.defaultConfiguration = configuration
        showBroadcastPicker = true
        status = "Choose Entire Screen in Apple's picker, approve sharing, then switch to Lalamove."
        picker.present()
    }

    func beginMonitoring() { }
    func pickerPresented() { }

    func stop() {
        guard let stream else {
            status = "No active screen scan."
            return
        }
        Task {
            do {
                try await stream.stopCapture()
                self.stream = nil
                self.isCapturing = false
                self.showStopInstructions = false
                self.status = "Screen scan stopped. No further screen frames are analyzed."
            } catch {
                self.status = "Could not stop screen scan: \(error.localizedDescription)"
            }
        }
    }

    private func startCapture(with filter: SCContentFilter) {
        Task {
            if let old = stream {
                try? await old.stopCapture()
                stream = nil
            }
            let configuration = SCStreamConfiguration()
            configuration.width = 1280
            configuration.height = 720
            configuration.minimumFrameInterval = CMTime(value: 1, timescale: 15)
            configuration.queueDepth = 3
            configuration.capturesAudio = false

            let newStream = SCStream(filter: filter, configuration: configuration, delegate: self)
            do {
                try newStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: sampleQueue)
                try await newStream.startCapture()
                self.stream = newStream
                self.isCapturing = true
                self.showBroadcastPicker = false
                self.status = "User-authorized ScreenCaptureKit active · on-device OCR every \(self.scanInterval) seconds"
            } catch {
                self.stream = nil
                self.isCapturing = false
                self.status = "Screen capture could not start: \(error.localizedDescription)"
            }
        }
    }

    private func recognize(_ sampleBuffer: CMSampleBuffer) {
        guard CMSampleBufferIsValid(sampleBuffer),
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastOCRTime >= max(2.5, min(10, scanInterval)), !ocrInProgress else { return }
        lastOCRTime = now
        ocrInProgress = true
        defer { ocrInProgress = false }

        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        request.recognitionLanguages = ["en-US"]
        do {
            try VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up).perform([request])
            let lines: [OCRLine] = (request.results ?? []).compactMap { observation in
                guard let candidate = observation.topCandidates(1).first else { return nil }
                let box = observation.boundingBox
                return OCRLine(text: candidate.string, confidence: Double(candidate.confidence),
                               x: box.minX, y: box.minY, width: box.width, height: box.height)
            }
            guard !lines.isEmpty else { return }
            sequence &+= 1
            Task { @MainActor [weak self] in
                guard let self else { return }
                await self.onOCRLines?(lines)
            }
        } catch {
            Task { @MainActor [weak self] in
                self?.status = "On-device OCR error: \(error.localizedDescription)"
            }
        }
    }
}

extension ScreenCaptureManager: SCContentSharingPickerObserver {
    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker,
                                          didUpdateWith filter: SCContentFilter,
                                          for stream: SCStream?) {
        Task { @MainActor [weak self] in self?.startCapture(with: filter) }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker,
                                          didCancelFor stream: SCStream?) {
        Task { @MainActor [weak self] in
            guard let self, self.stream == nil else { return }
            self.showBroadcastPicker = false
            self.status = "Screen sharing was cancelled. No capture is active."
        }
    }

    nonisolated func contentSharingPickerStartDidFailWithError(_ error: Error) {
        Task { @MainActor [weak self] in
            self?.status = "Apple's screen-sharing picker failed: \(error.localizedDescription)"
        }
    }
}

extension ScreenCaptureManager: SCStreamOutput {
    nonisolated func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer,
                            of outputType: SCStreamOutputType) {
        guard outputType == .screen else { return }
        // Keep OCR work on a dedicated serial queue; do not block ScreenCaptureKit callbacks.
        Task { @MainActor [weak self] in self?.recognize(sampleBuffer) }
    }
}

extension ScreenCaptureManager: SCStreamDelegate {
    nonisolated func stream(_ stream: SCStream, didStopWithError error: Error) {
        Task { @MainActor [weak self] in
            self?.isCapturing = false
            self?.stream = nil
            self?.status = "Screen capture stopped: \(error.localizedDescription)"
        }
    }
}
