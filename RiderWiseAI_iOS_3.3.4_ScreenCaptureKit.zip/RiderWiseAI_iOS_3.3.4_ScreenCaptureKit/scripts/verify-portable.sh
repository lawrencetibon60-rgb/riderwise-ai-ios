#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test
while IFS= read -r -d '' f; do
  swiftc -frontend -parse "$f" >/dev/null
done < <(find iOSApp Sources/RiderWiseCore -type f -name '*.swift' -print0)
python3 - <<'PY'
import gzip, json, pathlib, plistlib, collections
root=pathlib.Path('.')
plist=plistlib.loads((root/'iOSApp/Info.plist').read_bytes())
ent=plistlib.loads((root/'iOSApp/RiderWiseAI.entitlements').read_bytes())
assert plist.get('NSScreenCaptureUsageDescription')
assert 'screen-capture' in plist.get('UIBackgroundModes', [])
assert 'group.ph.riderwise.ai' in ent.get('com.apple.security.application-groups', [])
project=(root/'project.yml').read_text()
assert 'ScreenCaptureKit' not in project or 'RiderWiseBroadcast' not in project
assert 'RiderWiseBroadcast:' not in project
assert 'RiderWiseBroadcast' not in project
geo=root/'iOSApp/Resources/Geography'
for name in ['luzon_psgc_3q_2026.json','luzon_psgc_3q_2026.json.gz','geographic_centroids_legacy.json','riderwise_upgrade_config.json']:
    assert (geo/name).is_file(), f'Missing app geography resource: {name}'
with gzip.open(root/'Sources/RiderWiseCore/luzon_psgc_3q_2026.json.gz','rt',encoding='utf-8') as f:
    data=json.load(f)
records=data['records']
codes={r['psgc'] for r in records}
counts=collections.Counter(r['level'] for r in records)
assert len(records)==21330 and len(codes)==len(records)
assert dict(counts)=={'Reg':8,'Prov':38,'City':77,'Mun':694,'SubMun':14,'Bgy':20499}
assert all(not r.get('parentPsgc') or r['parentPsgc'] in codes for r in records)
config=json.loads((geo/'riderwise_upgrade_config.json').read_text())
assert config['scan']['interval_ms']==2500
assert config['safety']['auto_accept_bookings'] is False
assert config['safety']['auto_reject_bookings'] is False
assert config['ai']['large_local_model_autostart'] is False
print('Info.plist, capture permission/background mode, entitlements and safety config: PASS')
print('Geographic resources: PASS')
print('PSGC dataset: PASS (21,330 records, unique codes, valid parent links)')
PY
