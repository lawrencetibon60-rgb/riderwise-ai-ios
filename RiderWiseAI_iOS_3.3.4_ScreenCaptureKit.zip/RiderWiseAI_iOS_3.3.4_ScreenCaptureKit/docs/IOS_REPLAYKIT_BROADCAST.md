# Legacy capture design (superseded in 3.3.4)

This document describes the prior ReplayKit Broadcast Upload Extension approach. It is retained for historical audit only. The active iOS 27 capture implementation is ScreenCaptureKit in `iOSApp/ScreenCaptureManager.swift`; see `IOS_3.3.4_SCREENCAPTUREKIT_CANDIDATE.md`.
