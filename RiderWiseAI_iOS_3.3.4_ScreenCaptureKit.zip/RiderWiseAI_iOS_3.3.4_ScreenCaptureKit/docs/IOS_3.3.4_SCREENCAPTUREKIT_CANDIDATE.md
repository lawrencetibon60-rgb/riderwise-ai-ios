# RiderWise AI 3.3.4 — ScreenCaptureKit migration candidate

## Scope preserved
- YouTube-style native iOS Picture in Picture; iOS owns PiP position and size.
- PiP shows RiderWise's dashboard, not a mirror of Lalamove.
- Booking parsing, multi-card extraction, partial-booking handling, duplicate matching, accepted-booking reference, recommendation engine, offline AI, 2.5-second minimum OCR cadence, and Luzon geographic data remain in the source tree.
- User approval is required before full-display capture. No silent capture, auto-accept, or auto-reject.

## Capture migration
The iOS 27 capture implementation now uses ScreenCaptureKit (`SCContentSharingPicker`, `SCStream`, and `SCStreamOutput`) in the app process. The ReplayKit Broadcast Upload Extension is removed from the active Xcode target and retained only under `docs/legacy-replaykit/` for audit/history. The app requests the user to select the full display in Apple's picker and does not process audio.

Apple documents ScreenCaptureKit as the replacement for ReplayKit screen streaming, says a broadcast extension is no longer necessary, and provides an iOS 27+ full-display picker/stream workflow. See:
- https://developer.apple.com/documentation/ScreenCaptureKit
- https://developer.apple.com/documentation/ScreenCaptureKit/capturing-screen-content-on-ios
- https://developer.apple.com/documentation/replaykit/rpbroadcastsamplehandler

## PiP renderer
The PiP video frames are now enqueued through `AVSampleBufferDisplayLayer.sampleBufferRenderer` rather than deprecated layer enqueue/status/readiness APIs. The PiP interaction remains native and system-managed.

## Important verification boundary
This source migration is not yet a certified iOS build. The current execution environment has no Xcode 27 SDK or iPhone simulator. GitHub Actions on macOS/Xcode must compile the app, and the resulting build must be tested on the iPhone 13 Pro Max for:
1. picker approval and full-display capture while Lalamove is foregrounded;
2. OCR cadence, orientation, multiple booking cards, and partial booking states;
3. background continuity, interruptions, and stop/restart;
4. PiP start/stop, system size changes, and live dashboard refresh;
5. signing and installation.

The `NSScreenCaptureUsageDescription` and `screen-capture` background mode are included in the app Info.plist. Confirm entitlement/capability requirements in the generated Xcode project and signing configuration before release.

## Version
Marketing version: 3.3.4
Build number: 334
