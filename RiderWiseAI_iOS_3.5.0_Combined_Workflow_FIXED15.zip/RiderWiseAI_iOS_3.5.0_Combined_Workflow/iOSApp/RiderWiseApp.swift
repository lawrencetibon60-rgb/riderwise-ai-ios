import SwiftUI
import Vision
import UIKit
import RiderWiseCore

@main
struct RiderWiseApp: App {
    @StateObject private var store = RiderWiseStore()
    @StateObject private var capture = ScreenCaptureManager()
    @StateObject private var offlineAI = OfflineAIManager()
    @StateObject private var alerts = RecommendationAlertManager()
    @StateObject private var pipRenderer = PiPVideoRenderer()
    var body: some Scene { WindowGroup { DashboardView().environmentObject(store).environmentObject(capture).environmentObject(offlineAI).environmentObject(alerts).environmentObject(pipRenderer).preferredColorScheme(store.darkMode ? .dark : nil) } }
}

@MainActor final class RiderWiseStore: ObservableObject {
    /// Pushes an immediate PiP redraw whenever recommendation-relevant state changes.
    var onDashboardStateChanged: (() -> Void)?
    @Published var bookings:[Booking]=[]
    @Published var selectedReferenceID:String?
    @Published var recommendationStatus = "Waiting for recent, complete booking cards."
    @Published var statusMessage="Ready. Start an authorized Lalamove screen broadcast to begin."
    @Published var scanInterval=1.5
    @Published var darkMode=false
    @Published var rideMode=false
    @Published var fuelPrice=0.0
    @Published var kmPerLiter=0.0
    @Published var recommendations:[Recommendation]=[]
    @Published var savedQueue:[SavedRecommendation]=[]
    @Published var diagnostics:[DiagnosticEvent]=[]
    @Published var recommendationFeedback:[RecommendationFeedback]=[]
    private let diagnosticsLog:DiagnosticsLog
    private let fileURL:URL
    private let persistenceQueue=DispatchQueue(label:"ph.riderwise.state-persistence",qos:.utility)
    private let queue:RecommendationQueue
    private let centroids:CentroidResolver?
    private let psgc:PSGCResolver?
    private var isProcessingFrame=false
    private var referenceSnapshot: Booking?
    /// Prevents launch-time recovery from undoing a driver's explicit Clear action.
    private var referenceWasExplicitlyCleared = false
    /// Prevents a manually-cleared accepted order from immediately reselecting itself,
    /// while still allowing the next distinct accepted order to become the reference.
    private var explicitlyClearedReferenceID: String?
    init() {
        let dir=FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0]
        try? FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        fileURL=dir.appendingPathComponent("riderwise-state.json")
        queue=RecommendationQueue(fileURL:dir.appendingPathComponent("recommendation-queue.json"))
        diagnosticsLog=DiagnosticsLog(fileURL:dir.appendingPathComponent("diagnostics.json"))
        let coreBundle=Bundle(for:RiderWiseBundleToken.self)
        centroids=try? GeographicResources.loadCentroids(bundle:coreBundle)
        psgc=try? GeographicResources.loadPSGC(bundle:coreBundle)
        if let d=try? Data(contentsOf:fileURL),let s=try? JSONDecoder().decode(PersistedState.self,from:d) {
            // Sanitize legacy OCR endpoints such as "l Delivery" without deleting
            // records. Invalid endpoint text is cleared and the booking is downgraded
            // to partial/needs-verification before it can influence recommendations.
            bookings=s.bookings.map { BookingValidator.sanitizePersisted($0) }
            selectedReferenceID=s.referenceID
            referenceSnapshot=(s.referenceSnapshot ?? s.bookings.first(where:{$0.id==s.referenceID}))
                .map { BookingValidator.sanitizePersisted($0) }
            referenceWasExplicitlyCleared=s.referenceWasExplicitlyCleared ?? false
            explicitlyClearedReferenceID=s.explicitlyClearedReferenceID
            let protectedPersistedReferenceID = selectedReferenceID ??
                (referenceSnapshot?.bookingCode != nil ? referenceSnapshot?.id : nil)
            AcceptedBookingReferenceRecovery.demoteUnreferencedAcceptedWithoutBookingCode(
                &bookings, protectedReferenceID: protectedPersistedReferenceID
            )
            if selectedReferenceID == nil && referenceSnapshot?.bookingCode == nil {
                referenceSnapshot = nil
            }
            // Repair older saved states where accepted history exists but its
            // selected reference ID was not persisted. Respect an explicit Clear.
            let recoveredReference = AcceptedBookingReferenceRecovery.recover(
                bookings: bookings, selectedReferenceID: selectedReferenceID,
                referenceSnapshot: referenceSnapshot,
                explicitlyCleared: referenceWasExplicitlyCleared
            )
            selectedReferenceID = recoveredReference.referenceID
            referenceSnapshot = recoveredReference.snapshot
            rideMode=UserDefaults.standard.object(forKey:"riderwise.rideMode") as? Bool ?? (s.rideMode ?? false)
            darkMode=s.darkMode ?? false
            scanInterval = (s.scanIntervalRevision ?? 0) < 2 ? 1.5 : max(1.5, s.scanInterval ?? 1.5)
            fuelPrice=s.fuelPrice ?? 0; kmPerLiter=s.kmPerLiter ?? 0
            recommendationFeedback=s.recommendationFeedback ?? []
        }
        Task { savedQueue = await queue.all(); diagnostics = await diagnosticsLog.recent() }
        refreshRecommendations()
    }
    var reference:Booking? { bookings.first{$0.id==selectedReferenceID} ?? referenceSnapshot }
    var completeCount:Int { bookings.filter{$0.isComplete}.count }
    var partialCount:Int { bookings.filter{!$0.isComplete}.count }
    func ingestOCRLines(_ lines:[OCRLine]) async {
        guard !isProcessingFrame else { return }
        isProcessingFrame = true
        defer { isProcessingFrame = false }
        let cleanLines = LalamoveOCRParser.removeRiderWiseOverlay(from: lines)
        guard LalamoveOCRParser.hasLalamoveScreenEvidence(cleanLines) else {
            recordDiagnostic(.warning, code: "BROADCAST_OCR_NO_LALAMOVE",
                             message: "Frame rejected before parsing: no verified Lalamove screen evidence.")
            return
        }
        let result = LalamoveOCRParser.parse(cleanLines)
        var observedIDs = Set<String>()
        var acceptedIDs: [String] = []
        var added = 0
        if result.screenKind != .unknown {
            recordDiagnostic(.info, code: "BROADCAST_OCR_PARSED", message: "User-authorized broadcast frame parsed; card observations: \(result.bookings.count).")
        } else {
            recordDiagnostic(.warning, code: "BROADCAST_OCR_NO_LALAMOVE", message: "Broadcast frame did not contain recognized Lalamove booking markers.")
        }
        for incoming in result.bookings {
            let savedID = upsert(incoming)
            observedIDs.insert(savedID); added += 1
            if incoming.screenKind == .accepted && incoming.isComplete && incoming.bookingCode != nil { acceptedIDs.append(savedID) }
        }
        // The dedicated accepted-screen detector adds a second evidence gate. It is
        // deliberately separate from ordinary offer-card parsing so a visible offer
        // cannot become the protected reference from a single ambiguous phrase.
        if let accepted = AcceptedBookingDetector.detect(lines: cleanLines, previouslyDetected: bookings) {
            // The ordinary parser may already have upserted this same accepted card.
            // Promote that record in place instead of counting one frame twice.
            let matchIndex = accepted.matchedPreAcceptanceBookingID.flatMap { matchedID in
                bookings.firstIndex(where: { $0.id == matchedID })
            } ?? bookings.firstIndex(where:{$0.id==accepted.booking.id}) ??
                BookingMatcher.uniqueMatch(for:accepted.booking,among:bookings)
            let acceptedID: String
            if let matchIndex {
                var existing=bookings[matchIndex]
                if !observedIDs.contains(existing.id) {
                    existing.lastSeen = .now
                    existing.seenCount += 1
                }
                existing.status = .accepted
                existing.screenKind = .accepted
                existing.bookingCode = accepted.bookingCode ?? existing.bookingCode
                bookings[matchIndex]=existing
                if selectedReferenceID == existing.id { referenceSnapshot=existing }
                acceptedID=existing.id
            } else {
                acceptedID=upsert(accepted.booking)
            }
            observedIDs.insert(acceptedID)
            if !acceptedIDs.contains(acceptedID) { acceptedIDs.append(acceptedID) }
            recordDiagnostic(.info, code:"ACCEPTED_BOOKING_EVIDENCE",
                             message:"Accepted-screen evidence verified: \(accepted.evidence.joined(separator:", ")).")
        }
        for i in bookings.indices where result.screenKind != .unknown && !observedIDs.contains(bookings[i].id) && bookings[i].status != .accepted && bookings[i].status != .delivered && bookings[i].status != .dismissed {
            bookings[i].status = .notVisible
        }
        // A Clear action with no previous reference must not deadlock future
        // automatic selection. The helper excludes a previously cleared booking ID.
        let nextReferenceID = AcceptedBookingReferenceSelection.firstEligible(
            acceptedIDs: acceptedIDs, currentReferenceID: selectedReferenceID,
            explicitlyClearedID: explicitlyClearedReferenceID
        )
        if let nextReference = nextReferenceID,
           let accepted = bookings.first(where: { $0.id == nextReference }), accepted.status != .delivered {
            setReference(nextReference)
            recordDiagnostic(.info, code: "FIRST_ACCEPTED_REFERENCE_SAVED", message: "First eligible accepted booking was saved as the active reference.")
        } else if let current = selectedReferenceID, acceptedIDs.contains(where: { $0 != current }) {
            recordDiagnostic(.info, code: "ADDITIONAL_ACCEPTED_BOOKING", message: "Another accepted booking was detected; the existing reference was protected.")
        }
        pruneHistory(); refreshRecommendations(); persistAsync()
        statusMessage = "Live broadcast OCR processed. \(added) card observation(s); \(completeCount) complete and \(partialCount) partial records."
        onDashboardStateChanged?()
    }

    func ingest(_ images:[UIImage]) async {
        guard !isProcessingFrame else { return }
        isProcessingFrame=true
        defer { isProcessingFrame=false }
        statusMessage="Analyzing \(images.count) image frame(s)…"
        var added=0
        var observedIDs=Set<String>()
        var acceptedIDs:[String]=[]
        var sawLalamoveScreen=false
        for image in images {
            do {
                let lines=try await VisionText.recognize(image)
                guard LalamoveOCRParser.hasLalamoveScreenEvidence(lines) else {
                    recordDiagnostic(.warning,code:"OCR_FRAME_REJECTED",message:"Image frame rejected: no verified Lalamove screen evidence.")
                    continue
                }
                let result=LalamoveOCRParser.parse(lines)
                if result.screenKind != .unknown { sawLalamoveScreen=true }
                if result.diagnostics.isEmpty { recordDiagnostic(.info,code:"OCR_FRAME_PARSED",message:"OCR frame parsed; card observations: \(result.bookings.count).") }
                else { recordDiagnostic(.warning,code:"OCR_FRAME_INCOMPLETE",message:result.diagnostics.joined(separator:"; ")) }
                for incoming in result.bookings {
                    let savedID=upsert(incoming)
                    observedIDs.insert(savedID); added += 1
                    if incoming.screenKind == .accepted && incoming.isComplete && incoming.bookingCode != nil { acceptedIDs.append(savedID) }
                }
            } catch { statusMessage="OCR error: \(error.localizedDescription)"; recordDiagnostic(.error,code:"OCR_FAILURE",message:error.localizedDescription) }
        }
        for i in bookings.indices where sawLalamoveScreen && !observedIDs.contains(bookings[i].id) && bookings[i].status != .accepted && bookings[i].status != .delivered && bookings[i].status != .dismissed {
            bookings[i].status = .notVisible
        }
        // A Clear action with no previous reference must not deadlock future
        // automatic selection. The helper excludes a previously cleared booking ID.
        let nextReferenceID = AcceptedBookingReferenceSelection.firstEligible(
            acceptedIDs: acceptedIDs, currentReferenceID: selectedReferenceID,
            explicitlyClearedID: explicitlyClearedReferenceID
        )
        if let nextReference = nextReferenceID,
           let accepted=bookings.first(where:{$0.id==nextReference}),accepted.status != .delivered {
            setReference(nextReference)
            recordDiagnostic(.info,code:"FIRST_ACCEPTED_REFERENCE_SAVED",message:"First eligible accepted booking was saved as the active reference.")
        } else if let current=selectedReferenceID,acceptedIDs.contains(where:{$0 != current}) {
            recordDiagnostic(.info,code:"ADDITIONAL_ACCEPTED_BOOKING",message:"Another accepted booking was detected; the existing reference was protected.")
        }
        pruneHistory()
        refreshRecommendations(); persist()
        statusMessage="Processed \(images.count) image(s). \(added) card observation(s); \(completeCount) complete and \(partialCount) partial records. Only submitted image frames were analyzed."
    }
    @discardableResult func upsert(_ incoming:Booking) -> String {
        if let i=bookings.firstIndex(where:{$0.id==incoming.id}) ?? BookingMatcher.uniqueMatch(for:incoming,among:bookings) {
            var old=bookings[i]; old.lastSeen = .now; old.seenCount += 1
            old.lastKnownPosition=incoming.lastKnownPosition
            if let newPickup=incoming.pickupFullAddress,let oldPickup=old.pickupFullAddress,newPickup != oldPickup { old.verifiedPickup=false }
            if let newDropoff=incoming.dropoffFullAddress,let oldDropoff=old.dropoffFullAddress,newDropoff != oldDropoff { old.verifiedDropoff=false }
            old.bookingCode = incoming.bookingCode ?? old.bookingCode
            old.pickupFullAddress = incoming.pickupFullAddress ?? old.pickupFullAddress
            old.dropoffFullAddress = incoming.dropoffFullAddress ?? old.dropoffFullAddress
            if incoming.confidence >= old.confidence {
                old.pickup=incoming.pickup ?? old.pickup; old.dropoff=incoming.dropoff ?? old.dropoff
                old.baseFare=incoming.baseFare ?? old.baseFare; old.additionalFare=incoming.additionalFare ?? old.additionalFare
                old.fare=incoming.fare ?? old.fare; old.pickupDistanceKm=incoming.pickupDistanceKm ?? old.pickupDistanceKm
                old.vehicleType=incoming.vehicleType ?? old.vehicleType; old.bookingType=incoming.bookingType ?? old.bookingType
                old.notes=incoming.notes ?? old.notes; old.paymentMethod=incoming.paymentMethod ?? old.paymentMethod
                old.sourceEvidence=incoming.sourceEvidence.isEmpty ? old.sourceEvidence : incoming.sourceEvidence
                old.confidence=max(old.confidence,incoming.confidence)
            }
            if old.isComplete && (old.status == .partial || old.status == .notVisible || old.status == .stale) {
                old.status = incoming.status == .partial ? .detected : incoming.status
            }
            if incoming.screenKind == .accepted && old.status != .delivered { old.status = .accepted }
            if incoming.screenKind == .expanded || incoming.screenKind == .accepted {
                old.screenKind=incoming.screenKind
                if incoming.screenKind != .accepted && old.pickupFullAddress != nil && old.dropoffFullAddress != nil && old.status != .delivered && old.status != .accepted {
                    old.status = old.verifiedPickup && old.verifiedDropoff ? .verified : .needsVerification
                }
            }
            bookings.remove(at:i)
            bookings.insert(old,at:0)
            if selectedReferenceID == old.id { referenceSnapshot = old }
            return old.id
        } else { bookings.insert(incoming,at:0); return incoming.id }
    }
    private func pruneHistory(now:Date = .now) {
        bookings=BookingHistoryPolicy.prune(bookings,now:now)
    }
    func setReference(_ id:String?) {
        let previous=selectedReferenceID
        selectedReferenceID=id
        referenceWasExplicitlyCleared = (id == nil)
        explicitlyClearedReferenceID = id == nil ? previous : nil
        for i in bookings.indices {
            if bookings[i].id==id { bookings[i].status = .accepted }
            else if bookings[i].id==previous && bookings[i].status == .accepted { bookings[i].status = .detected }
        }
        referenceSnapshot = id.flatMap { target in bookings.first(where:{$0.id==target}) }
        refreshRecommendations(); persist()
    }
    func markReferenceDelivered() {
        guard let id=selectedReferenceID else{return}
        if let index=bookings.firstIndex(where:{$0.id==id}) { bookings[index].status = .delivered }
        if referenceSnapshot?.id == id { referenceSnapshot?.status = .delivered }
        referenceSnapshot=nil
        selectedReferenceID=nil
        referenceWasExplicitlyCleared=false
        explicitlyClearedReferenceID=nil
        recordDiagnostic(.info,code:"REFERENCE_MARKED_DELIVERED",message:"Driver marked the active reference as delivered; next accepted booking can become the new reference.")
        refreshRecommendations(); persist()
    }
    func setRideMode(_ enabled:Bool) {
        rideMode=enabled
        UserDefaults.standard.set(enabled, forKey:"riderwise.rideMode")
        refreshRecommendations()
        persist()
    }
    func clearHistory() {
        bookings=[]
        selectedReferenceID=nil
        referenceSnapshot=nil
        referenceWasExplicitlyCleared=false
        explicitlyClearedReferenceID=nil
        recommendations=[]
        recommendationStatus="Booking history cleared. Waiting for new visible offers."
        savedQueue=[]
        Task { try? await queue.clear() }
        persist()
        onDashboardStateChanged?()
    }
    func confirmAddresses(id:String,pickup:String,dropoff:String) {
        let fullPickup=pickup.trimmingCharacters(in:.whitespacesAndNewlines)
        let fullDropoff=dropoff.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !fullPickup.isEmpty,!fullDropoff.isEmpty else{return}
        if let index=bookings.firstIndex(where:{$0.id==id}) {
            bookings[index].pickupFullAddress=fullPickup
            bookings[index].dropoffFullAddress=fullDropoff
            bookings[index].verifiedPickup=true; bookings[index].verifiedDropoff=true
            if bookings[index].status != .accepted { bookings[index].status = .verified }
            if selectedReferenceID == id { referenceSnapshot=bookings[index] }
        } else if referenceSnapshot?.id == id {
            referenceSnapshot?.pickupFullAddress=fullPickup
            referenceSnapshot?.dropoffFullAddress=fullDropoff
            referenceSnapshot?.verifiedPickup=true; referenceSnapshot?.verifiedDropoff=true
        } else { return }
        recordDiagnostic(.info,code:"ADDRESS_CONFIRMED_BY_DRIVER",message:"Driver confirmed full pickup and drop-off address fields locally.")
        refreshRecommendations(); persist()
    }
    func recordDiagnostic(_ level:DiagnosticLevel,code:String,message:String) {
        let event=DiagnosticEvent(level:level,code:code,message:message)
        Task { try? await diagnosticsLog.append(event); diagnostics=await diagnosticsLog.recent() }
    }
    func markRecommendation(_ id:String,state:RecommendationState) { Task { try? await queue.mark(id,state:state); savedQueue=await queue.all() } }
    func recordRecommendationFeedback(_ recommendation: Recommendation, outcome: RecommendationFeedbackOutcome) {
        let candidates = bookings.filter { recommendation.candidateBookingIDs.contains($0.id) }
        guard !candidates.isEmpty else { return }
        for booking in candidates {
            let key = RecommendationLearning.patternKey(for: booking)
            recommendationFeedback.append(RecommendationFeedback(patternKey: key, outcome: outcome))
        }
        if recommendationFeedback.count > 500 {
            recommendationFeedback = Array(recommendationFeedback.sorted { $0.recordedAt > $1.recordedAt }.prefix(500))
        }
        recordDiagnostic(.info, code: "RECOMMENDATION_FEEDBACK_SAVED",
                         message: outcome == .accepted ? "Driver marked a suggested booking as accepted." : "Driver marked a suggested booking as unsuitable.")
        refreshRecommendations()
        persist()
    }
    func applyAIRanking(_ ranked:[Recommendation]) {
        let currentIDs=Set(recommendations.map(\.id)); let rankedIDs=Set(ranked.map(\.id))
        guard currentIDs==rankedIDs && ranked.count==recommendations.count else{return}
        recommendations=ranked
        onDashboardStateChanged?()
    }
    func refreshRecommendations() {
        defer { onDashboardStateChanged?() }
        guard centroids != nil && psgc != nil else {
            recommendations=[]
            recommendationStatus="Geographic index unavailable. Check that both Luzon PSGC and centroid JSON resources are packaged in RiderWiseCore."
            return
        }
        guard rideMode else {
            recommendations=[]
            recommendationStatus="Ride Mode is OFF. Turn it on to evaluate route compatibility."
            return
        }
        // Keep compatible candidates in the comparison pool after their cards scroll
        // off-screen. A card disappearing from the latest frame is not a cancellation.
        // Seven-day booking history is retained separately; recommendations use a
        // conservative 24-hour candidate window to avoid reviving old offers forever.
        let cutoff=Date.now.addingTimeInterval(-24*60*60)
        let currentCandidates=bookings.filter { booking in
            booking.id != selectedReferenceID && booking.isComplete && booking.lastSeen >= cutoff &&
            (booking.status == .detected || booking.status == .verified || booking.status == .needsVerification || booking.status == .notVisible)
        }
        let incompleteVisibleCandidates = bookings.filter { booking in
            booking.id != selectedReferenceID && !booking.isComplete && booking.lastSeen >= cutoff &&
            (booking.status == .partial || booking.status == .detected || booking.status == .needsVerification)
        }.count
        if let ref=reference {
            recommendations=RecommendationEngine.referenceBased(reference:ref,candidates:currentCandidates,centroids:centroids,psgc:psgc,history:bookings)
            if !recommendations.isEmpty {
                recommendationStatus = "\(recommendations.count) geographic candidate combination(s) found. Approximate locations require full-address verification."
            } else if currentCandidates.isEmpty && incompleteVisibleCandidates > 0 {
                recommendationStatus = "\(incompleteVisibleCandidates) recent booking card(s) are still partial. Recommendations require each candidate to have pickup, drop-off and fare; keep each full card visible or open it to reveal missing details."
            } else {
                recommendationStatus = RecommendationEngine.explainEmptyReferenceBased(reference:ref,candidates:currentCandidates,centroids:centroids,psgc:psgc)
            }
        } else {
            recommendations=RecommendationEngine.referenceFree(bookings:currentCandidates,centroids:centroids,psgc:psgc)
            recommendationStatus = recommendations.isEmpty
                ? (incompleteVisibleCandidates > 0
                    ? "\(incompleteVisibleCandidates) recent booking card(s) are partial. Reference-free comparisons need at least two complete bookings with pickup and drop-off locations."
                    : "No reference is selected. Need at least two recent, complete, visible bookings with resolvable pickup and drop-off locations.")
                : "\(recommendations.count) potential route-similarity pair(s) found. These are not confirmed combined orders."
        }
        recommendations = recommendations.map { recommendation in
            var adjusted = recommendation
            let candidates = bookings.filter { recommendation.candidateBookingIDs.contains($0.id) }
            let keys = candidates.map { RecommendationLearning.patternKey(for: $0) }
            let learned=RecommendationLearning.adjustedScore(recommendation.score, patternKeys: keys, feedback: recommendationFeedback)
            adjusted.score = recommendation.basis.contains("APPROXIMATE LEGACY CENTROID") ? min(0.59,learned) : learned
            return adjusted
        }.sorted { lhs,rhs in
            // Stable discovery order: older candidate offers stay at the top of PiP.
            let lhsFirstSeen = lhs.candidateBookingIDs.compactMap { id in bookings.first(where: { $0.id == id })?.firstSeen }.min() ?? lhs.lastSeen
            let rhsFirstSeen = rhs.candidateBookingIDs.compactMap { id in bookings.first(where: { $0.id == id })?.firstSeen }.min() ?? rhs.lastSeen
            // Put one-booking recommendations ahead of optional multi-booking
            // combinations so the PiP's first rows always expose each offer separately.
            if lhs.candidateBookingIDs.count != rhs.candidateBookingIDs.count {
                return lhs.candidateBookingIDs.count < rhs.candidateBookingIDs.count
            }
            if lhsFirstSeen != rhsFirstSeen { return lhsFirstSeen < rhsFirstSeen }
            return lhs.score > rhs.score
        }
        let saved=recommendations.map { r in SavedRecommendation(id:r.id,description:r.reason,state:r.requiresVerification ? .needsAddressVerification:.recommended,firstSeen:r.lastSeen,lastSeen:r.lastSeen,score:r.score,availability:r.availability) }
        Task { try? await queue.refresh(saved); savedQueue=await queue.all() }
    }
    private func persistedStateSnapshot() -> PersistedState {
        PersistedState(bookings:bookings,referenceID:selectedReferenceID,referenceSnapshot:reference,referenceWasExplicitlyCleared:referenceWasExplicitlyCleared,explicitlyClearedReferenceID:explicitlyClearedReferenceID,rideMode:rideMode,darkMode:darkMode,scanInterval:max(1.5,scanInterval),scanIntervalRevision:2,fuelPrice:fuelPrice,kmPerLiter:kmPerLiter,recommendationFeedback:recommendationFeedback)
    }

    func persist() {
        let state=persistedStateSnapshot()
        let destination=fileURL
        // Serialize critical synchronous writes with per-frame background writes so
        // an older queued snapshot can never overwrite a newer accepted reference.
        persistenceQueue.sync {
            if let data=try? JSONEncoder().encode(state) { try? data.write(to:destination,options:.atomic) }
        }
    }

    private func persistAsync() {
        let state=persistedStateSnapshot()
        let destination=fileURL
        persistenceQueue.async {
            if let data=try? JSONEncoder().encode(state) { try? data.write(to:destination,options:.atomic) }
        }
    }
}
private struct PersistedState:Codable,Sendable {var bookings:[Booking];var referenceID:String?;var referenceSnapshot:Booking?;var referenceWasExplicitlyCleared:Bool?;var explicitlyClearedReferenceID:String?;var rideMode:Bool?;var darkMode:Bool?;var scanInterval:Double?;var scanIntervalRevision:Int?;var fuelPrice:Double?;var kmPerLiter:Double?;var recommendationFeedback:[RecommendationFeedback]?}

enum VisionText {
    static func recognize(_ image:UIImage) async throws -> [RiderWiseCore.OCRLine] {
        guard let cg=image.cgImage else {throw NSError(domain:"RiderWiseOCR",code:1,userInfo:[NSLocalizedDescriptionKey:"Image could not be decoded"])}
        return try await Task.detached(priority:.userInitiated) {
            let request=VNRecognizeTextRequest()
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection=true
            request.recognitionLanguages=["en-US"]
            try VNImageRequestHandler(cgImage:cg).perform([request])
            return (request.results ?? []).compactMap { observation -> RiderWiseCore.OCRLine? in
                guard let text=observation.topCandidates(1).first else{return nil}
                let b=observation.boundingBox
                return RiderWiseCore.OCRLine(text:text.string,confidence:Double(text.confidence),x:b.minX,y:b.minY,width:b.width,height:b.height)
            }
        }.value
    }
}

struct DashboardView:View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var store:RiderWiseStore
    @EnvironmentObject private var capture:ScreenCaptureManager
    @EnvironmentObject private var offlineAI:OfflineAIManager
    @EnvironmentObject private var alerts:RecommendationAlertManager
    @EnvironmentObject private var pipRenderer:PiPVideoRenderer
    @State private var showSettings=false
    @State private var showConfirmClear=false
    @State private var bookingToVerify:Booking?
    @State private var bookingToSetReference:Booking?
    @AppStorage("riderwise.dashboardDensity") private var dashboardDensity="comfortable"

    private func handleReferenceTap(_ booking: Booking) {
        let isCurrentReference: Bool = store.selectedReferenceID == booking.id
        if isCurrentReference {
            store.setReference(nil)
        } else {
            bookingToSetReference = booking
        }
    }

    var body:some View {
        NavigationStack {
            ScrollView {
                VStack(spacing:16) {
                    header
                    HStack(spacing:10) {
                        metric("Complete",value:store.completeCount,icon:"checkmark.circle.fill")
                        metric("Partial",value:store.partialCount,icon:"exclamationmark.circle.fill")
                        metric("Recommended",value:store.recommendations.count,icon:"sparkles")
                    }
                    referenceCard
                    ProfitEstimateCard(reference:store.reference,recommendations:store.recommendations,bookings:store.bookings)
                    VStack(alignment:.leading,spacing:10) {
                        HStack {Text("Detected bookings").font(.headline);Spacer();Text("Newest first").font(.caption).foregroundStyle(.secondary)}
                        if store.bookings.isEmpty {ContentUnavailableView("No bookings yet",systemImage:"doc.text.viewfinder",description:Text("Start user-approved full-display screen capture, then switch to Lalamove to analyze visible booking cards."))}
                        ForEach(store.bookings) { booking in
                            BookingRow(
                                booking: booking,
                                isReference: store.selectedReferenceID == booking.id,
                                onReference: { handleReferenceTap(booking) },
                                onVerify: { bookingToVerify = booking }
                            )
                        }
                    }
                    recommendationsCard
                    savedQueueCard
                    DiagnosticsCard(events:store.diagnostics)
                    privacyNote
                }.padding(dashboardDensity == "compact" ? 8 : 16)
            }
            .navigationTitle("RiderWise AI")
            .toolbar {
                ToolbarItem(placement:.topBarTrailing) {Button {showSettings=true} label:{Image(systemName:"gearshape")}}
            }
            .sheet(isPresented:$showSettings) {SettingsView().environmentObject(store).environmentObject(offlineAI).environmentObject(alerts)}
            .sheet(item:$bookingToVerify) { booking in AddressVerificationView(booking:booking) { pickup,dropoff in store.confirmAddresses(id:booking.id,pickup:pickup,dropoff:dropoff); bookingToVerify=nil } }
            .confirmationDialog("Clear local booking history?",isPresented:$showConfirmClear,titleVisibility:.visible) {
                Button("Clear history",role:.destructive){store.clearHistory()}
            }
            .confirmationDialog("Confirm this booking was accepted in Lalamove?",isPresented:Binding(get:{bookingToSetReference != nil},set:{if !$0 {bookingToSetReference=nil}}),titleVisibility:.visible) {
                Button("Set accepted reference") { if let bookingToSetReference { store.setReference(bookingToSetReference.id) }; bookingToSetReference=nil }
                Button("Cancel",role:.cancel) { bookingToSetReference=nil }
            } message: { Text("Only choose this if you have already accepted this exact booking in Lalamove. Available offers must not be used as an accepted reference.") }
        }
        .onAppear {
            capture.scanInterval=store.scanInterval
            capture.beginMonitoring()
            alerts.prime(store.recommendations)
            capture.onOCRLines = { lines in await store.ingestOCRLines(lines) }
            store.onDashboardStateChanged = { [weak store, weak capture, weak pipRenderer] in
                guard let store, let capture, let pipRenderer else { return }
                pipRenderer.update(image: Self.makePiPFrame(store: store, capture: capture))
            }
            pipRenderer.update(image: currentPiPFrame())
        }
        // Keep PiP synchronized with every dashboard-relevant state change.
        // Booking status/address and Ride Mode changes must refresh the PiP frame too.
        .onChange(of: pipFrameRevision) { _, _ in
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active {
                capture.refreshAfterForeground()
                pipRenderer.update(image: currentPiPFrame())
                store.recordDiagnostic(.info, code:"APP_FOREGROUNDED",
                    message:capture.isCapturing ? "App returned to foreground; existing screen stream is still active." : "App returned to foreground without an active screen stream. A new user-approved screen-sharing session is required.")
            }
        }
        .onChange(of:store.recommendations.map { "\($0.id):\($0.score):\($0.label):\($0.totalFare)" }.joined(separator:"|")) { _,_ in
            alerts.announceNewRecommendations(store.recommendations)
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:store.reference.map { "\($0.id):\($0.pickup ?? ""):\($0.dropoff ?? ""):\($0.fare ?? 0)" } ?? "none") { _,_ in
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:capture.isCapturing) { _,_ in
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:capture.hasRecentFrames) { _,_ in
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:capture.isAppForeground) { _,_ in
            pipRenderer.update(image: currentPiPFrame())
        }
        .onChange(of:capture.status) { _,status in
            pipRenderer.update(image: currentPiPFrame())
            if status.contains("NO SCREEN FRAMES") || status.contains("NO FRAMES") || status.contains("could not start") || status.contains("stopped by iOS") {
                store.recordDiagnostic(.warning, code:"SCREEN_CAPTURE_HEALTH", message:status)
            }
        }
        .task(id:store.recommendations.map{"\($0.id):\($0.score):\($0.label)"}.joined(separator:"|")) { if offlineAI.isReady { store.applyAIRanking(await offlineAI.rank(store.recommendations)) } }
        .onChange(of:offlineAI.isReady) { _,ready in if ready { Task { store.applyAIRanking(await offlineAI.rank(store.recommendations)) } } }
        .onChange(of:store.scanInterval) { _,value in capture.scanInterval=value; store.persist() }
    }
    private var pipFrameRevision: String {
        let bookingState = store.bookings.map {
            "\($0.id):\($0.status.rawValue):\($0.pickup ?? ""):\($0.dropoff ?? ""):\($0.fare ?? 0)"
        }.joined(separator: "|")
        let recommendationState = store.recommendations.map {
            "\($0.id):\($0.score):\($0.label):\($0.totalFare)"
        }.joined(separator: "|")
        return [
            store.selectedReferenceID ?? "no-reference",
            store.rideMode ? "ride-on" : "ride-off",
            capture.isCapturing ? "stream-started" : "scan-paused",
            capture.hasRecentFrames ? "frames-live" : "no-recent-frames",
            capture.isAppForeground ? "riderwise-foreground" : "other-app-foreground",
            capture.status,
            store.recommendationStatus,
            bookingState,
            recommendationState
        ].joined(separator: "||")
    }

    private func currentPiPFrame() -> UIImage {
        Self.makePiPFrame(store: store, capture: capture)
    }

    private static func makePiPFrame(store: RiderWiseStore, capture: ScreenCaptureManager) -> UIImage {
        let referenceText: String
        if let ref = store.reference {
            referenceText = "\(ref.pickup ?? "Unknown") → \(ref.dropoff ?? "Unknown")"
        } else {
            referenceText = "No accepted booking selected"
        }
        let top = store.recommendations.first
        let title: String
        let detail: String
        if let top {
            title = top.label
            detail = top.requiresVerification
                ? "Approximate geographic match · verify full addresses · ₱\(String(format:"%.2f",top.totalFare)) combined fare"
                : "Potential route match · confirm every booking in Lalamove · ₱\(String(format:"%.2f",top.totalFare)) combined fare"
        } else {
            title = store.rideMode ? "No compatible booking yet" : "Ride Mode is OFF"
            detail = String(store.recommendationStatus.prefix(82))
        }
        let liveStateDetail: String
        if !capture.isCapturing {
            liveStateDetail = capture.requiresReauthorization
                ? "SCREEN SCAN NEEDS NEW iOS APPROVAL — return to RiderWise and tap Start authorized screen scan."
                : "SCREEN SCAN PAUSED — return to RiderWise and tap Start authorized screen scan."
        } else if capture.isAppForeground {
            liveStateDetail = "RIDERWISE IS OPEN — switch to Lalamove to scan live booking cards."
        } else if !store.rideMode {
            liveStateDetail = "RIDE MODE OFF — turn it on in RiderWise to enable recommendations."
        } else {
            liveStateDetail = detail
        }
        let scanStatus = !capture.isCapturing ? "SCAN PAUSED" :
            (!capture.hasRecentFrames ? "NO FRAMES" :
                (capture.isAppForeground ? "OPEN LALAMOVE" :
                    (capture.ocrPassCount == 0 ? "LIVE FRAMES" : "LIVE OCR")))
        return PiPVideoRenderer.makeDashboardFrame(
            reference: referenceText,
            topRecommendation: title,
            detail: liveStateDetail,
            count: store.recommendations.count,
            scanning: capture.isCapturing && capture.hasRecentFrames && !capture.isAppForeground,
            scanStatus: scanStatus,
            recommendationLines: store.recommendations.prefix(3).map { recommendation in
                let verification = recommendation.requiresVerification ? "VERIFY" : "POTENTIAL"
                return "\(verification) · \(recommendation.label) · ₱\(String(format: "%.0f", recommendation.totalFare))"
            },
            hasAcceptedReference: store.reference != nil
        )
    }

    private var header:some View {
        VStack(alignment:.leading,spacing:12) {
            HStack {
                VStack(alignment:.leading,spacing:3) {Text("Lalamove booking intelligence").font(.headline);Text("iPhone-native companion").font(.caption).foregroundStyle(.secondary)}
                Spacer()
                Button {
                    store.setRideMode(!store.rideMode)
                } label: {
                    Label(store.rideMode ? "Ride Mode ON":"Ride Mode OFF",systemImage:"car.side.fill")
                        .font(.caption.weight(.semibold)).padding(8)
                        .background((store.rideMode ? Color.green : Color.orange).opacity(0.14),in:Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityHint("Tap to turn ride-based booking recommendations on or off.")
            }
            Button {
                if capture.isCapturing {
                    capture.stop()
                } else {
                    capture.presentSystemPicker()
                }
            } label: {
                Label(capture.isCapturing ? "How to stop screen scan" : "Start authorized screen scan", systemImage: capture.isCapturing ? "stop.circle.fill" : "record.circle")
                    .font(.headline).frame(maxWidth:.infinity).padding()
                    .background(capture.isCapturing ? Color.red.opacity(0.12):Color.blue.opacity(0.12),in:RoundedRectangle(cornerRadius:14))
            }
            Text(capture.status).font(.caption).foregroundStyle(.secondary)
            Text("Frames: \(capture.hasRecentFrames ? "receiving" : "none") · OCR passes: \(capture.ocrPassCount) · Last OCR lines: \(capture.lastOCRLineCount)")
                .font(.caption2.monospaced()).foregroundStyle(.secondary)
            Button {
                let frame = currentPiPFrame()
                if pipRenderer.isActive { pipRenderer.stop() }
                else { pipRenderer.start(image: frame) }
            } label: {
                Label(pipRenderer.isActive ? "Close PiP dashboard" : "Start PiP dashboard",
                      systemImage: pipRenderer.isActive ? "pip.exit" : "pip.enter")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity).padding(.vertical, 11)
                    .background(.blue.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
            }
            .disabled(!pipRenderer.isReady)
            Text(pipRenderer.status).font(.caption).foregroundStyle(.secondary)
            Text(store.statusMessage).font(.caption).foregroundStyle(.secondary)
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:18))
            .overlay(alignment: .bottomTrailing) {
                PiPDisplayLayerHost(renderer: pipRenderer)
                    .frame(width: 320, height: 180)
                    .opacity(0.001)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
    }
    private var referenceCard:some View {
        VStack(alignment:.leading,spacing:8) {
            HStack {Text("Active reference booking").font(.headline);Spacer();Button("Clear"){store.setReference(nil)}.font(.caption)}
            if let ref=store.reference {
                Text("\(ref.pickup ?? "Unknown") → \(ref.dropoff ?? "Unknown")").font(.subheadline.weight(.semibold))
                Text("₱\(ref.fare ?? 0, specifier:"%.2f") · \(ref.vehicleType ?? "Vehicle unknown")").font(.caption).foregroundStyle(.secondary)
                Text("First accepted booking is protected as the reference until you mark it delivered or replace it.").font(.caption2).foregroundStyle(.secondary)
                Button("Mark delivered · clear reference") { store.markReferenceDelivered() }.font(.caption.weight(.semibold))
            } else {Text("No accepted reference set. You can select a booking below, or use reference-free potential-pair comparisons.").font(.caption).foregroundStyle(.secondary)}
            if !store.rideMode { Text("Ride Mode is OFF. Ride-based recommendations are paused; captured booking history is retained.").font(.caption).foregroundStyle(.orange) }
        }.frame(maxWidth:.infinity,alignment:.leading).padding().background(.orange.opacity(0.09),in:RoundedRectangle(cornerRadius:16))
    }
    private var recommendationsCard:some View {
        VStack(alignment:.leading,spacing:10) {
            Text(store.reference == nil ? "Potential booking combinations":"Saved compatible bookings").font(.headline)
            if store.recommendations.isEmpty {Text(store.recommendationStatus).font(.caption).foregroundStyle(.secondary)}
            ForEach(store.recommendations,id:\.id) { r in
                VStack(alignment:.leading,spacing:4) {
                    HStack {Text(r.label).font(.subheadline.weight(.semibold));Spacer();Text("Rank \(Int(r.score*100))").font(.caption.monospacedDigit())}
                    Text(r.reason).font(.caption).foregroundStyle(.secondary)
                    if r.requiresVerification {
                        Label("Open the Lalamove booking card and confirm its full addresses before treating this as compatible.",
                              systemImage:"exclamationmark.magnifyingglass")
                            .font(.caption2.weight(.semibold)).foregroundStyle(.orange)
                    }
                    Text(r.availability.replacingOccurrences(of:"_",with:" ")).font(.caption2).foregroundStyle(.orange)
                    HStack {
                        Button("I accepted this") { store.recordRecommendationFeedback(r, outcome: .accepted) }.font(.caption2)
                        Spacer()
                        Button("Not suitable") { store.recordRecommendationFeedback(r, outcome: .rejectedAsUnsuitable) }.font(.caption2)
                    }
                }.padding(10).background(.secondary.opacity(0.08),in:RoundedRectangle(cornerRadius:10))
            }
        }.frame(maxWidth:.infinity,alignment:.leading).padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
    }
    private var savedQueueCard:some View {
        VStack(alignment:.leading,spacing:8) {
            HStack { Text("Saved recommendation history").font(.headline); Spacer(); Text("\(store.savedQueue.count)").font(.caption.monospacedDigit()).foregroundStyle(.secondary) }
            if store.savedQueue.isEmpty { Text("No saved recommendation history yet.").font(.caption).foregroundStyle(.secondary) }
            ForEach(store.savedQueue) { item in
                VStack(alignment:.leading,spacing:5) {
                    HStack { Text(item.state.rawValue).font(.caption.bold()); Spacer(); Text(item.availability).font(.caption2).foregroundStyle(.secondary) }
                    Text(item.description).font(.caption)
                    HStack { Text("Score \(Int(item.score*100))% · Last seen \(item.lastSeen.formatted(date:.omitted,time:.shortened))").font(.caption2).foregroundStyle(.secondary); Spacer(); if item.state != .rejectedByDriver && item.state != .dismissed && item.state != .accepted && item.state != .expiredConfirmed { Button("Dismiss") { store.markRecommendation(item.id,state:.dismissed) }.font(.caption2); Button("Accepted externally") { store.markRecommendation(item.id,state:.accepted) }.font(.caption2) } }
                }.padding(10).background(.secondary.opacity(0.08),in:RoundedRectangle(cornerRadius:10))
            }
        }.frame(maxWidth:.infinity,alignment:.leading).padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
    }
    private var privacyNote:some View {
        Label("Read-only companion. Screen video is analyzed on-device only after you start and approve the iOS broadcast. No automatic Lalamove taps, scrolling, acceptance or rejection.",systemImage:"hand.raised.fill")
            .font(.caption2).foregroundStyle(.secondary).frame(maxWidth:.infinity,alignment:.leading)
    }
    private func metric(_ title:String,value:Int,icon:String)->some View {
        VStack(alignment:.leading,spacing:5) {Label(title,systemImage:icon).font(.caption2).foregroundStyle(.secondary);Text("\(value)").font(.title2.bold().monospacedDigit())}
            .frame(maxWidth:.infinity,alignment:.leading).padding(12).background(.thinMaterial,in:RoundedRectangle(cornerRadius:13))
    }
}
struct BookingRow:View {
    let booking:Booking
    let isReference:Bool
    let onReference:()->Void
    let onVerify:()->Void
    var body:some View {
        VStack(alignment:.leading,spacing:8) {
            HStack {Text(booking.status.rawValue.uppercased()).font(.caption2.bold()).foregroundStyle(booking.isComplete ? .green:.orange);Spacer();if isReference{Label("REFERENCE",systemImage:"bookmark.fill").font(.caption2.bold()).foregroundStyle(.orange)}}
            Text("\(booking.pickup ?? "Pickup incomplete") → \(booking.dropoff ?? "Drop-off incomplete")").font(.subheadline.weight(.semibold))
            HStack {if let f=booking.fare{Text("₱\(f,specifier:"%.2f")")};if let v=booking.vehicleType{Text(v)};if let t=booking.bookingType{Text(t)}}
                .font(.caption).foregroundStyle(.secondary)
            if let km=booking.pickupDistanceKm {Text(String(format:"~%.1f km rider-to-pickup (not delivery distance)",km)).font(.caption2).foregroundStyle(.secondary)}
            if let note=booking.notes {Text(note).font(.caption).lineLimit(2)}
            if booking.screenKind == .expanded || booking.screenKind == .accepted {
                Text("\(booking.paymentMethod ?? "Payment method unknown") · \(booking.verifiedPickup && booking.verifiedDropoff ? "Driver verified addresses":"Address verification needed")").font(.caption2).foregroundStyle(.secondary)
            }
            HStack {Text("Seen \(booking.seenCount) time(s)").font(.caption2).foregroundStyle(.secondary);Spacer();Button("Verify addresses",action:onVerify).font(.caption2);Button(isReference ? "Clear reference":"Confirm accepted",action:onReference).font(.caption.weight(.semibold)).disabled(!booking.isComplete)}
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:14))
    }
}
struct AddressVerificationView:View {
    let booking:Booking
    let onSave:(String,String)->Void
    @Environment(\.dismiss) private var dismiss
    @State private var pickup:String
    @State private var dropoff:String
    init(booking:Booking,onSave:@escaping (String,String)->Void) {
        self.booking=booking; self.onSave=onSave
        _pickup=State(initialValue:booking.pickupFullAddress ?? booking.pickup ?? "")
        _dropoff=State(initialValue:booking.dropoffFullAddress ?? booking.dropoff ?? "")
    }
    var body:some View {
        NavigationStack { Form {
            Section("Pickup full address") { TextField("Check the Lalamove pickup address",text:$pickup,axis:.vertical).lineLimit(2...4) }
            Section("Drop-off full address") { TextField("Check the Lalamove destination address",text:$dropoff,axis:.vertical).lineLimit(2...4) }
            Section { Text("Open the offer in Lalamove first. Copy or check the complete pickup and drop-off addresses shown on the expanded card. Do not confirm using only a barangay or city name. This checks administrative locality identity; it does not create road coordinates or a road route.").font(.caption).foregroundStyle(.secondary) }
        }.navigationTitle("Verify booking addresses").navigationBarTitleDisplayMode(.inline).toolbar {
            ToolbarItem(placement:.cancellationAction){Button("Cancel"){dismiss()}}
            ToolbarItem(placement:.confirmationAction){Button("Confirm") { onSave(pickup,dropoff); dismiss() }.disabled(pickup.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || dropoff.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)}
        }}
    }
}
struct ProfitEstimateCard:View {
    let reference:Booking?
    let recommendations:[Recommendation]
    let bookings:[Booking]
    @AppStorage("riderwise.profit.deliveryKm") private var deliveryKm=""
    @AppStorage("riderwise.profit.hours") private var hours=""
    @AppStorage("riderwise.profit.fuelPrice") private var fuelPrice=""
    @AppStorage("riderwise.profit.kmPerLiter") private var efficiency=""
    @State private var selectedScenarioID="reference"
    private var selectedRecommendation:Recommendation? { recommendations.first{$0.id==selectedScenarioID} }
    private var includedBookings:[Booking] {
        if let selectedRecommendation { let ids=Set(selectedRecommendation.bookingIDs); return bookings.filter{ids.contains($0.id)} }
        if let reference { return [reference] }
        return []
    }
    var body:some View {
        VStack(alignment:.leading,spacing:9) {
            Text("Profit estimate").font(.headline)
            Text("Uses only your entered delivery-route distance and time. The orange Lalamove pickup km is never used as delivery distance.").font(.caption2).foregroundStyle(.secondary)
            if reference != nil || !recommendations.isEmpty {
                Picker("Booking scenario",selection:$selectedScenarioID) {
                    if reference != nil { Text("Accepted reference only").tag("reference") }
                    ForEach(recommendations) { rec in Text(rec.label).tag(rec.id) }
                }.pickerStyle(.menu)
            }
            HStack {TextField("Delivery km",text:$deliveryKm).keyboardType(.decimalPad);TextField("Hours",text:$hours).keyboardType(.decimalPad)}
            HStack {TextField("Fuel ₱/L",text:$fuelPrice).keyboardType(.decimalPad);TextField("Km/L",text:$efficiency).keyboardType(.decimalPad)}
            let result=ProfitCalculator.calculate(bookings:includedBookings,deliveryDistanceKm:Double(deliveryKm),durationHours:Double(hours),fuelPricePerLiter:Double(fuelPrice),kmPerLiter:Double(efficiency),detourKm:selectedRecommendation?.detourKm)
            HStack {Text("Bookings included");Spacer();Text("\(includedBookings.count)").monospacedDigit()}
            HStack {Text("Base fare");Spacer();Text(result.baseFare.map{String(format:"₱%.2f",$0)} ?? "Unknown")}
            HStack {Text("Additional fare");Spacer();Text(result.additionalFare.map{String(format:"₱%.2f",$0)} ?? "Unknown")}
            HStack {Text("Combined fare");Spacer();Text(result.grossFare.map{String(format:"₱%.2f",$0)} ?? "Unknown").bold()}
            HStack {Text("Estimated fuel cost");Spacer();Text(result.fuelCost.map{String(format:"₱%.2f",$0)} ?? "Enter distance, fuel price and km/L")}
            HStack {Text("Net after fuel");Spacer();Text(result.netAfterFuel.map{String(format:"₱%.2f",$0)} ?? "Unavailable").bold()}
            if let perHour=result.earningsPerHour { Text(String(format:"Gross per hour: ₱%.2f",perHour)).font(.caption).foregroundStyle(.secondary) }
            if let detour=result.detourKm { Text(String(format:"Route-search detour (straight-line estimate): %.1f km",detour)).font(.caption2).foregroundStyle(.secondary) }
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
        .onAppear { if reference == nil,let first=recommendations.first { selectedScenarioID=first.id } }
        .onChange(of:recommendations.map(\.id)) { _,ids in
            if selectedScenarioID != "reference" && !ids.contains(selectedScenarioID) { selectedScenarioID=ids.first ?? "reference" }
            if reference == nil && selectedScenarioID == "reference",let first=ids.first { selectedScenarioID=first }
        }
    }
}
struct DiagnosticsCard:View {
    let events:[DiagnosticEvent]
    var body:some View {
        VStack(alignment:.leading,spacing:7) {
            Text("Diagnostics").font(.headline)
            if events.isEmpty {Text("No diagnostics recorded.").font(.caption).foregroundStyle(.secondary)}
            ForEach(events.prefix(5)) { event in
                HStack(alignment:.top) { Text(event.level.rawValue.uppercased()).font(.caption2.bold()).foregroundStyle(event.level == .error ? .red : (event.level == .warning ? .orange:.secondary)); VStack(alignment:.leading){Text(event.code).font(.caption.bold());Text(event.message).font(.caption2).foregroundStyle(.secondary)};Spacer();Text(event.timestamp.formatted(date:.omitted,time:.shortened)).font(.caption2).foregroundStyle(.secondary) }
            }
            Text("Local diagnostics only. Do not add customer addresses, phone numbers or raw booking identifiers.").font(.caption2).foregroundStyle(.secondary)
        }.padding().background(.thinMaterial,in:RoundedRectangle(cornerRadius:16))
    }
}
struct SettingsView:View {
    @EnvironmentObject private var store:RiderWiseStore
    @EnvironmentObject private var offlineAI:OfflineAIManager
    @EnvironmentObject private var alerts:RecommendationAlertManager
    @AppStorage("riderwise.dashboardDensity") private var dashboardDensity="comfortable"
    var body:some View {
        NavigationStack {Form {
            Section("Scanning") {
                LabeledContent("Default scan interval",value:String(format:"%.1f seconds",store.scanInterval))
                Slider(value:$store.scanInterval,in:1.5...10,step:0.5)
                Text("Live scanning uses Apple ScreenCaptureKit after you approve the iOS screen-sharing picker. On-device OCR samples at the configured interval; fast scrolling may still cause missed offers.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Preferences") {
                Toggle("Ride Mode",isOn:$store.rideMode).onChange(of:store.rideMode) { _,value in store.setRideMode(value) }
                Toggle("Dark mode",isOn:$store.darkMode).onChange(of:store.darkMode) { _,_ in store.persist() }
                Picker("Dashboard layout",selection:$dashboardDensity) {
                    Text("Comfortable").tag("comfortable")
                    Text("Compact").tag("compact")
                }
            }
            Section("Recommendation alerts") {
                Toggle("Play sound for new recommendations", isOn: $alerts.isEnabled)
                Button("Test notification sound") { alerts.playTestSound() }
                Text("A short iOS notification sound plays when a newly detected recommendation is added. Existing recommendations do not repeatedly trigger alerts. Sound behavior may depend on iPhone mute, Focus and notification/audio settings.").font(.caption2).foregroundStyle(.secondary)
            }
            Section("Advanced Offline AI") {
                Text(offlineAI.status).font(.caption).foregroundStyle(.secondary)
                if offlineAI.isDownloading { ProgressView() }
                Button("Download Gemma 4 E2B (~2.59 GB)") { Task { await offlineAI.downloadModel() } }.disabled(offlineAI.isDownloading || offlineAI.isReady)
                Button("Load Offline AI") { Task { await offlineAI.loadModel() } }.disabled(offlineAI.isDownloading || offlineAI.isReady)
                Text("The model is optional and downloaded only after your approval. Use Wi-Fi and allow at least 5 GB free storage. If it cannot load, OCR and deterministic recommendations continue without AI.")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            Section("Safety") {
                Text("The app never accepts or rejects bookings, scrolls Lalamove, or claims that previously seen offers remain available.")
                Text("Screen broadcast is user-started and user-stopped through iOS controls. Only shared video frames are analyzed; rapid scrolling can cause missed offers.")
            }
            Section("Build status") {
                LabeledContent("Offline AI", value: offlineAI.isReady ? "Loaded on-device" : "Optional model / not loaded")
                LabeledContent("Live screen capture", value: "Requires iPhone verification")
                LabeledContent("Along-the-way matching", value: "Geographic estimate; address confirmation required")
            }
        }.navigationTitle("Settings").navigationBarTitleDisplayMode(.inline)}
    }
}
