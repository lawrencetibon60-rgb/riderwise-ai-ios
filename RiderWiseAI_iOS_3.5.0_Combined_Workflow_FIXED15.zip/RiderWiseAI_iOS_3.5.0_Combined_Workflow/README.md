# RiderWise AI iOS 3.4.9 — Persistent Multi-Recommendation PiP

This revision builds on 3.4.8 and addresses disappearing compatible offers when Lalamove scrolls them off-screen.

## Release changes

- Compatible candidate bookings remain eligible for route comparison after their cards scroll off-screen. A card missing from the latest screenshot is not treated as cancellation.
- Reference-based and reference-free matching accept complete `.notVisible` history records while continuing to exclude accepted, dismissed, delivered, and stale records.
- The live recommendation candidate window is extended from 45 seconds to 24 hours; the separate booking-history policy still retains up to seven days.
- Recommendation ordering is stable by the earliest candidate booking's first-seen timestamp. A newly discovered compatible booking is appended after earlier discoveries rather than replacing the first PiP item.
- PiP displays up to three single-booking recommendation rows first, in first-detected order, including each route, potential/verification state, and combined fare; optional multi-booking combinations follow in the full list. If there are more than three individual recommendations, PiP displays a count of additional saved recommendations.
- The full in-app recommendations list continues to show all generated results.
- OCR interval remains 1.5 seconds. Driver confirmation remains required; no automatic accept/reject actions are introduced.

## Validation

- 52 Swift core tests passed, including a regression test that confirms off-screen candidates remain eligible and delivered candidates remain excluded.
- Portable source audit and Swift syntax parsing are included in the GitHub workflow.
- iOS device archive still requires GitHub's Xcode 27 runner; this environment does not have Xcode or a physical iPhone.

## Upload to GitHub

1. Upload `RiderWiseAI_iOS_3.4.9_PersistentMultiRecommendationPiP_1p5s_GitHub.zip` to the repository root.
2. Upload `riderwise-3.4.9-persistent-multi-recommendation-pip.yml` into `.github/workflows/`.
3. Commit both files.
4. Open Actions and run **RiderWise AI 3.4.9 - Persistent Multi-Recommendation PiP & Off-Screen Booking Retention**.
5. Check the portable audit and iOS device archive jobs before installing the resulting unsigned IPA with a valid signing/provisioning setup.

## Behavior and limits

- Off-screen compatible offers remain in the comparison pool for up to 24 hours, provided they remain complete and have not been marked accepted, dismissed, delivered, or stale.
- The PiP window shows the first three recommendations and an additional-count indicator; it cannot display an unlimited number of routes legibly in its native small window. The full list remains available in the RiderWise app.
- Geographic compatibility remains an approximate route-screening result, not road routing or a guarantee. Verify full addresses and confirm each booking in Lalamove.
