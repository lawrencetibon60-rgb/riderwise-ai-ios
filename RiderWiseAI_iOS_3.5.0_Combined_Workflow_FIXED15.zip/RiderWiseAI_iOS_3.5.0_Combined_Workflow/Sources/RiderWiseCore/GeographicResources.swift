import Foundation

/// Stable bundle token so the iOS app can load data packaged in the RiderWiseCore framework.
public final class RiderWiseBundleToken: NSObject {}

public enum GeographicResources {
    /// XcodeGen may place framework resources in the framework bundle or a nested
    /// resource bundle. Search the framework, main app and loaded bundles explicitly.
    public static func url(forResource name: String, withExtension ext: String,
                           bundle: Bundle = Bundle(for: RiderWiseBundleToken.self)) -> URL? {
        var candidates: [Bundle] = [bundle, .main]
        #if !os(Linux)
        // Apple platforms expose loaded framework/bundle enumeration reliably.
        // CoreFoundation's Linux implementation can crash when enumerating these
        // collections, so SwiftPM verification uses Bundle.module at the call site.
        candidates.append(contentsOf: Bundle.allFrameworks)
        candidates.append(contentsOf: Bundle.allBundles)
        #endif
        var seen = Set<String>()
        for candidate in candidates where seen.insert(candidate.bundleURL.path).inserted {
            if let url = candidate.url(forResource: name, withExtension: ext) { return url }
            if let resourceURL = candidate.resourceURL,
               let urls = try? FileManager.default.contentsOfDirectory(
                    at: resourceURL, includingPropertiesForKeys: [.isDirectoryKey],
                    options: [.skipsHiddenFiles]) {
                for child in urls {
                    guard let values = try? child.resourceValues(forKeys: [.isDirectoryKey]),
                          values.isDirectory == true,
                          let nested = Bundle(url: child),
                          let url = nested.url(forResource: name, withExtension: ext) else { continue }
                    return url
                }
            }
        }
        return nil
    }

    public static func loadCentroids(bundle: Bundle = Bundle(for: RiderWiseBundleToken.self)) throws -> CentroidResolver {
        try CentroidResolver(data: try Data(contentsOf: requiredURL("geographic_centroids_legacy", "json", bundle)))
    }

    public static func loadPSGC(bundle: Bundle = Bundle(for: RiderWiseBundleToken.self)) throws -> PSGCResolver {
        try PSGCResolver(data: try Data(contentsOf: requiredURL("luzon_psgc_3q_2026", "json", bundle)))
    }

    private static func requiredURL(_ name: String, _ ext: String, _ bundle: Bundle) throws -> URL {
        guard let url = url(forResource: name, withExtension: ext, bundle: bundle) else {
            throw NSError(domain: "GeographicResources", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Required geographic asset missing: \\(name).\\(ext)"])
        }
        return url
    }
}
