import Foundation
public enum BookingMatcher {
    /// Merge only a unique identity match. A booking code is strongest; otherwise require
    /// fare, endpoint containment, and vehicle agreement when both sides contain a vehicle.
    public static func uniqueMatch(for incoming:Booking, among existing:[Booking])->Int? {
        if let code=incoming.bookingCode, !code.isEmpty {
            let hits=existing.indices.filter{existing[$0].bookingCode?.caseInsensitiveCompare(code) == .orderedSame}
            if hits.count == 1 { return hits[0] }
            if !hits.isEmpty { return nil }
        }
        if incoming.isComplete, let fare=incoming.fare, let p=incoming.pickup, let d=incoming.dropoff {
            let hits=existing.indices.filter { i in
                let old=existing[i]
                guard old.isComplete,let of=old.fare,let op=old.pickup,let od=old.dropoff,
                      abs(of-fare)<0.011, endpointMatch(p,op), endpointMatch(d,od) else{return false}
                if let a=incoming.vehicleType,let b=old.vehicleType,
                   TextNormalization.normalize(a) != TextNormalization.normalize(b) { return false }
                return true
            }
            return hits.count == 1 ? hits[0] : nil
        }

        // Partial OCR observations previously received a fresh UUID on every scan.
        // Reconcile only when at least two independent visible fields agree and no
        // shared field conflicts. Ambiguous matches are deliberately left separate.
        let hits=existing.indices.filter { i in
            let old=existing[i]
            guard !old.isComplete else { return false }
            var anchors=0
            if let a=incoming.fare, let b=old.fare {
                guard abs(a-b)<0.011 else { return false }
                anchors += 1
            }
            if let a=incoming.pickup, let b=old.pickup {
                guard endpointMatch(a,b) else { return false }
                anchors += 1
            }
            if let a=incoming.dropoff, let b=old.dropoff {
                guard endpointMatch(a,b) else { return false }
                anchors += 1
            }
            if let a=incoming.vehicleType, let b=old.vehicleType {
                guard TextNormalization.normalize(a) == TextNormalization.normalize(b) else { return false }
                anchors += 1
            }
            if let a=incoming.bookingType, let b=old.bookingType {
                guard TextNormalization.normalize(a) == TextNormalization.normalize(b) else { return false }
                anchors += 1
            }
            return anchors >= 2
        }
        return hits.count == 1 ? hits[0] : nil
    }
    private static func endpointMatch(_ a:String,_ b:String)->Bool {
        let x=TextNormalization.normalize(a),y=TextNormalization.normalize(b)
        guard !x.isEmpty && !y.isEmpty else{return false}
        if x == y { return true }
        // A collapsed locality may match an expanded address only when the longer
        // string contains explicit address context. Bare-name substring matching
        // can merge different places such as San Mateo and San Mateo Rizal.
        let longer = x.count >= y.count ? x : y
        let rawLonger = a.count >= b.count ? a : b
        let hasAddressContext = rawLonger.contains(",") ||
            [" barangay "," brgy "," street "," st "," road "," rd "," warehouse "," building "," bldg "," blk "," lot "," unit "].contains { longer.contains($0) }
        return hasAddressContext && (x.contains(y) || y.contains(x))
    }
}
