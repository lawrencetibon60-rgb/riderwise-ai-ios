import Foundation

public enum BookingStatus: String, Codable, Sendable {
    case partial, detected, needsVerification, verified, accepted, delivered, dismissed, notVisible, stale
}
public enum BookingScreenKind: String, Codable, Sendable { case list, expanded, accepted, unknown }

/// Portable representation of a Lalamove offer. `pickupDistanceKm` is explicitly
/// rider-to-pickup proximity and must never be treated as delivery route distance.
public struct Booking: Codable, Identifiable, Hashable, Sendable {
    public var id: String
    public var bookingCode: String?
    public var pickup: String?
    public var dropoff: String?
    public var pickupFullAddress: String?
    public var dropoffFullAddress: String?
    public var baseFare: Double?
    public var additionalFare: Double?
    public var fare: Double?
    public var pickupDistanceKm: Double?
    public var deliveryDistanceKm: Double?
    public var vehicleType: String?
    public var bookingType: String?
    public var notes: String?
    public var paymentMethod: String?
    public var confidence: Double
    public var status: BookingStatus
    public var screenKind: BookingScreenKind
    public var firstSeen: Date
    public var lastSeen: Date
    public var seenCount: Int
    public var lastKnownPosition: Int?
    public var verifiedPickup: Bool
    public var verifiedDropoff: Bool
    public var sourceEvidence: [String]

    public init(id: String? = nil, bookingCode: String? = nil, pickup: String? = nil,
                dropoff: String? = nil, pickupFullAddress: String? = nil, dropoffFullAddress: String? = nil,
                baseFare: Double? = nil, additionalFare: Double? = nil, fare: Double? = nil,
                pickupDistanceKm: Double? = nil, deliveryDistanceKm: Double? = nil,
                vehicleType: String? = nil, bookingType: String? = nil, notes: String? = nil,
                paymentMethod: String? = nil, confidence: Double = 0, status: BookingStatus = .partial,
                screenKind: BookingScreenKind = .unknown, firstSeen: Date = .now, lastSeen: Date = .now,
                seenCount: Int = 1, lastKnownPosition: Int? = nil,
                verifiedPickup: Bool = false, verifiedDropoff: Bool = false,
                sourceEvidence: [String] = []) {
        self.bookingCode=bookingCode; self.pickup=pickup; self.dropoff=dropoff
        self.pickupFullAddress=pickupFullAddress; self.dropoffFullAddress=dropoffFullAddress
        self.baseFare=baseFare ?? fare
        self.additionalFare=additionalFare ?? 0
        // Keep an absent fare absent. Coalescing two missing components to zero
        // made incomplete OCR fragments appear as ₱0.00 bookings in the UI.
        if let fare {
            self.fare = fare
        } else if let baseFare {
            self.fare = baseFare + (additionalFare ?? 0)
        } else if let additionalFare {
            self.fare = additionalFare
        } else {
            self.fare = nil
        }
        self.pickupDistanceKm=pickupDistanceKm; self.deliveryDistanceKm=deliveryDistanceKm
        self.vehicleType=vehicleType; self.bookingType=bookingType; self.notes=notes
        self.paymentMethod=paymentMethod; self.confidence=confidence; self.status=status
        self.screenKind=screenKind; self.firstSeen=firstSeen; self.lastSeen=lastSeen
        self.seenCount=seenCount; self.lastKnownPosition=lastKnownPosition
        self.verifiedPickup=verifiedPickup; self.verifiedDropoff=verifiedDropoff
        self.sourceEvidence=sourceEvidence
        if let explicitID=id { self.id=explicitID }
        else if let code=bookingCode, !code.isEmpty { self.id="code:" + TextNormalization.normalize(code) }
        else if let p=pickup, let d=dropoff, let f=self.fare {
            self.id=Self.fingerprint(pickup:p,dropoff:d,fare:f,vehicle:vehicleType,bookingType:bookingType)
        } else { self.id="fragment:" + UUID().uuidString }
    }

    /// A booking is structurally complete when the two endpoints and a positive fare exist.
    /// Vehicle/service labels remain independently optional because OCR can miss those labels.
    public var isComplete: Bool {
        guard let p=pickup, let d=dropoff, let f=fare else { return false }
        return p.trimmingCharacters(in:.whitespacesAndNewlines).count >= 2 &&
            d.trimmingCharacters(in:.whitespacesAndNewlines).count >= 2 && f.isFinite && f > 0
    }
    public var effectivePickup: String? { pickupFullAddress ?? pickup }
    public var effectiveDropoff: String? { dropoffFullAddress ?? dropoff }
    public var farePerPickupKm: Double? { nil }

    public static func fingerprint(pickup: String?, dropoff: String?, fare: Double?, vehicle: String?, bookingType: String?) -> String {
        [pickup,dropoff,fare.map{String(format:"%.2f",$0)},vehicle,bookingType]
            .map { TextNormalization.normalize($0 ?? "") }.joined(separator:"|")
    }
}

public enum TextNormalization {
    public static func normalize(_ value: String) -> String {
        value.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier:"en_US_POSIX"))
            .lowercased().split(whereSeparator: { !$0.isLetter && !$0.isNumber }).joined(separator:" ")
    }
}
public enum BookingValidator {
    /// Reject obvious app/service/vehicle labels that OCR can accidentally promote
    /// to geographic endpoints (for example "l Delivery" or "ur Delivery").
    /// This is deliberately conservative: ordinary locality names such as "San Mateo"
    /// remain valid and ambiguous real place names are left for address verification.
    public static func isObviousNonLocationLabel(_ value: String) -> Bool {
        let tokens = Set(TextNormalization.normalize(value).split(separator: " ").map(String.init))
        let uiTokens: Set<String> = [
            "delivery", "pabili", "purchase", "regular", "priority", "express",
            "motorcycle", "motorbike", "hatchback", "truck", "wheeler", "van",
            "sedan", "mpv", "suv", "car", "pickup", "dropoff", "destination",
            "duty", "along", "above", "home", "record", "wallet", "mission",
            "profile", "settings", "verify", "addresses", "confirm", "accepted",
            "detected", "bookings", "newest", "first", "help", "client", "call"
        ]
        return !tokens.isDisjoint(with: uiTokens)
    }

    /// Safely repairs legacy OCR records without deleting booking history. Only
    /// obvious UI/service labels are removed; the remaining fields and evidence stay.
    public static func sanitizePersisted(_ booking: Booking) -> Booking {
        var repaired = booking
        var changed = false
        if let pickup = repaired.pickup, isObviousNonLocationLabel(pickup) {
            repaired.pickup = nil
            repaired.pickupFullAddress = nil
            repaired.verifiedPickup = false
            changed = true
        }
        if let dropoff = repaired.dropoff, isObviousNonLocationLabel(dropoff) {
            repaired.dropoff = nil
            repaired.dropoffFullAddress = nil
            repaired.verifiedDropoff = false
            changed = true
        }
        if changed {
            if repaired.status == .accepted || repaired.status == .verified {
                repaired.status = .needsVerification
            } else if repaired.status != .notVisible && repaired.status != .stale &&
                        repaired.status != .dismissed && repaired.status != .delivered {
                repaired.status = .partial
            }
            repaired.confidence = min(repaired.confidence, 0.35)
        }
        return repaired
    }

    public static func validate(_ b: Booking) -> [String] {
        var issues:[String]=[]
        if let p=b.pickup, (p.trimmingCharacters(in:.whitespacesAndNewlines).count < 2 || p.count > 180) { issues.append("Pickup length invalid") }
        if let d=b.dropoff, (d.trimmingCharacters(in:.whitespacesAndNewlines).count < 2 || d.count > 180) { issues.append("Drop-off length invalid") }
        if let p=b.pickup, isObviousNonLocationLabel(p) { issues.append("Pickup contains a non-location UI/service label") }
        if let d=b.dropoff, isObviousNonLocationLabel(d) { issues.append("Drop-off contains a non-location UI/service label") }
        // Identical short locality labels can still represent distinct addresses in one city.
        // Keep the observation and require full-address verification instead of discarding it.
        if let f=b.fare, (!f.isFinite || f <= 0 || f > 100_000) { issues.append("Fare outside allowed range") }
        if let base=b.baseFare, (!base.isFinite || base < 0) { issues.append("Base fare is invalid") }
        if let extra=b.additionalFare, (!extra.isFinite || extra < 0) { issues.append("Additional fare is invalid") }
        if let base=b.baseFare, let extra=b.additionalFare, let total=b.fare,
           abs(base + extra - total) > 0.011 { issues.append("Fare components do not equal total fare") }
        if !b.confidence.isFinite || !(0...1).contains(b.confidence) { issues.append("Invalid confidence") }
        if let km=b.pickupDistanceKm, (!km.isFinite || km < 0 || km > 1000) { issues.append("Invalid rider-to-pickup distance") }
        if let km=b.deliveryDistanceKm, (!km.isFinite || km <= 0 || km > 3000) { issues.append("Invalid delivery distance") }
        if b.seenCount < 1 { issues.append("Seen count must be positive") }
        if b.lastSeen < b.firstSeen { issues.append("Last-seen precedes first-seen") }
        return issues
    }
}
