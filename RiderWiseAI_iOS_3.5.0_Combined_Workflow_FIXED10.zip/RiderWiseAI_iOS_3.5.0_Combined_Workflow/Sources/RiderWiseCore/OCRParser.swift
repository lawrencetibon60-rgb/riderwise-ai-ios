import Foundation

public struct OCRLine: Codable, Sendable {
    public let text: String
    public let confidence: Double
    /// Vision normalized coordinates, origin at bottom-left.
    public let x: Double
    public let y: Double
    public let width: Double
    public let height: Double
    public init(text:String, confidence:Double=1, x:Double=0, y:Double=0, width:Double=1, height:Double=0.02) {
        self.text=text; self.confidence=confidence; self.x=x; self.y=y; self.width=width; self.height=height
    }
}
public struct OCRParseResult: Sendable {
    public let screenKind:BookingScreenKind
    public let bookings:[Booking]
    public let cardFragments:Int
    public let diagnostics:[String]
}
public struct FareComponents:Sendable,Equatable {
    public let base:Double; public let additional:Double; public var total:Double { base+additional }
}

/// Lalamove-specific parser. It preserves screen evidence and deliberately leaves
/// ambiguous/partially visible cards incomplete rather than fabricating fields.
public enum LalamoveOCRParser {
    private static let farePairPattern = #"(?:₱|PHP|P)\s*([0-9,]+(?:\.[0-9]{1,2})?)\s*\+\s*(?:₱|PHP|P)?\s*([0-9,]+(?:\.[0-9]{1,2})?)"#
    private static let farePattern = #"(?:₱|PHP|P)\s*([0-9,]+(?:\.[0-9]{1,2})?)"#
    private static let pickupDistancePattern = #"~\s*([0-9]+(?:\.[0-9]+)?)\s*km"#
    private static let genericDistancePattern = #"([0-9]+(?:\.[0-9]+)?)\s*km"#
    private static let codePattern = #"(?:#\s*|booking\s*(?:id|no\.?|number)\s*[:#-]?\s*)([A-Z0-9-]{6,})"#
    private static let vehicles = ["motorcycle","motorbike","hatchback","small truck","medium truck","large truck","6-wheeler","10-wheeler","4-wheeler","closed van","pickup truck","sedan","mpv","suv","van","truck","car"]
    private static let excludedExact:Set<String> = [
        "delivery","regular","priority","express","motorcycle","motorbike","sedan","car","mpv","suv","van","truck",
        "settle with customer","collect cash","report order","does this order look suspicious","proof of delivery",
        "find more orders at these locations","pick up now","call customer","help","home","along the way","above 50 km",
        "pickup","pick up","dropoff","drop off","destination","client","today","small parcel",
        // Common RiderWise/Lalamove interface labels that are not geographic endpoints.
        "ride","photos","ride photos","ride mode","detected bookings","newest first",
        "potential booking combinations","booking history","accepted","detected",
        "verify addresses","confirm accepted","recommendation status","net after fuel",
        "estimated fuel cost","fuel cost","available bookings","on duty","off duty",
        "record","wallet","mission","profile","pickup","pick up","home",
        "settings","profit estimate","bookings included","active reference booking",
        "along the way","above 50 km","drop-off incomplete","drop off incomplete",
        "pickup incomplete","pick up incomplete"
    ]

    /// Removes OCR text covered by RiderWise's own floating PiP dashboard.
    /// Vision coordinates are normalized with a bottom-left origin. The dashboard
    /// header anchors an approximate PiP rectangle; text inside that rectangle is
    /// excluded because it is not visible Lalamove content.
    public static func removeRiderWiseOverlay(from lines:[OCRLine]) -> [OCRLine] {
        guard !lines.isEmpty else { return lines }
        let strongMarkers = [
            "riderwise ai", "accepted reference", "top recommendation", "no accepted booking selected",
            "verify addresses", "confirm accepted", "recommendation status", "detected bookings",
            "newest first", "net after fuel", "estimated fuel cost", "available bookings",
            "no compatible booking", "no compatible booking yet", "notvisible", "partial"
        ].map { TextNormalization.normalize($0) }
        let normalized = lines.map { TextNormalization.normalize($0.text) }
        func isRiderWiseControl(_ normalizedLine: String) -> Bool {
            // Vision may combine adjacent button labels into one OCR line. Exact
            // equality allowed those combined strings to leak into booking parsing.
            strongMarkers.contains { marker in
                normalizedLine == marker || normalizedLine.contains(marker)
            }
        }
        let anchors = lines.indices.filter { index in
            let text = normalized[index]
            return text == "riderwise ai" || text.hasPrefix("riderwise ai ")
        }
        var overlayRects: [(left:Double, bottom:Double, right:Double, top:Double)] = []
        for index in anchors {
            let line = lines[index]
            // PiP is approximately 16:9 and can be docked to any screen corner.
            // The title is on the top edge of the PiP content.
            let left = max(0, line.x - 0.03)
            let right = min(1, left + 0.64)
            let bottom = max(0, line.y - 0.34)
            let top = min(1, line.y + max(0.045, line.height * 2.5))
            overlayRects.append((left, bottom, right, top))
        }
        // If OCR missed the title, only suppress exact RiderWise UI marker lines;
        // do not guess a large screen rectangle from a weak marker.
        if overlayRects.isEmpty {
            return lines.filter { line in
                let text = TextNormalization.normalize(line.text)
                return !isRiderWiseControl(text)
            }
        }
        return lines.filter { line in
            let text = TextNormalization.normalize(line.text)
            if isRiderWiseControl(text) { return false }
            let centerX = line.x + line.width / 2
            let centerY = line.y + line.height / 2
            return !overlayRects.contains { rect in
                centerX >= rect.left && centerX <= rect.right && centerY >= rect.bottom && centerY <= rect.top
            }
        }
    }

    /// Detects whether a captured frame contains Lalamove UI even when RiderWise
    /// remains active because its PiP window is visible. App lifecycle state alone
    /// must never suppress a real Lalamove frame.
    public static func hasLalamoveScreenEvidence(_ lines:[OCRLine]) -> Bool {
        // A full RiderWise dashboard can itself contain saved booking fragments
        // with the words "Pick Up Now". Never treat those dashboard cards as a
        // Lalamove source screen. PiP-only RiderWise text is removed below by its
        // spatial overlay filter; these markers identify the host dashboard.
        let rawText = TextNormalization.normalize(lines.map(\.text).joined(separator:" "))
        let dashboardOnlyMarkers = [
            "detected bookings", "newest first", "profit estimate",
            "estimated fuel cost", "net after fuel", "bookings included",
            "active reference booking", "potential booking combinations",
            "booking history", "verify addresses", "confirm accepted"
        ]
        if dashboardOnlyMarkers.contains(where: { rawText.contains($0) }) {
            return false
        }
        // When the full RiderWise app is foregrounded, its title is centered near
        // the top edge. PiP titles are normally anchored in a lower corner. Combine
        // the full-screen title geometry with any dashboard section label so a
        // missed/blurred "Detected bookings" heading cannot let saved cards pass.
        let hasFullScreenRiderWiseTitle = lines.contains { line in
            let n = TextNormalization.normalize(line.text)
            return n == "riderwise ai" && line.y > 0.86 &&
                line.x > 0.20 && line.x < 0.70 && line.width < 0.45
        }
        let dashboardSectionMarkers = ["detected bookings", "newest first", "profit estimate",
            "net after fuel", "bookings included", "active reference booking"]
        if hasFullScreenRiderWiseTitle && dashboardSectionMarkers.contains(where: { rawText.contains($0) }) {
            return false
        }

        let visible = removeRiderWiseOverlay(from: lines)
        let visibleRawText = visible.map(\.text).joined(separator:" ")
        let text = TextNormalization.normalize(visibleRawText)

        // "Pick Up Now" is not sufficient by itself: RiderWise's own detected
        // booking cards repeat that phrase. Require independent Lalamove detail.
        let acceptedMarkers = [
            "pick up at", "proof of delivery required",
            "call customer", "settle with customer", "collect cash"
        ]
        if acceptedMarkers.contains(where: { text.contains($0) }) { return true }

        let hasOfferHeader = text.contains("pick up now")
        let hasDeliveryType = text.contains("delivery")
        let hasVehicle = vehicles.contains(where: { text.contains($0) })
        let hasFare = firstMatch(farePattern, in:visibleRawText) != nil
        return hasOfferHeader && hasDeliveryType && hasVehicle && hasFare
    }

    public static func parse(_ lines:[OCRLine], now:Date = .now) -> OCRParseResult {
        let safeLines = removeRiderWiseOverlay(from: lines)
        let ordered=safeLines.enumerated().sorted { lhs,rhs in
            if lhs.element.y != rhs.element.y { return lhs.element.y > rhs.element.y }
            if lhs.element.x != rhs.element.x { return lhs.element.x < rhs.element.x }
            return lhs.offset < rhs.offset
        }.map(\.element)
        guard !ordered.isEmpty else { return OCRParseResult(screenKind:.unknown,bookings:[],cardFragments:0,diagnostics:["No OCR text was detected"]) }
        let joined=ordered.map(\.text).joined(separator:"\n").lowercased()
        let hasPickupTime = joined.contains("pick up at")
        let hasCallCustomer = joined.contains("call customer")
        let hasProofOfDelivery = joined.contains("proof of delivery required")
        let hasAcceptedPaymentPanel = joined.contains("collect cash") || joined.contains("settle with customer")
        let acceptedEvidenceCount = [hasPickupTime, hasCallCustomer, hasProofOfDelivery, hasAcceptedPaymentPanel].filter { $0 }.count
        // A single phrase can appear in an offer card or OCR noise. Require a post-acceptance
        // pickup-time marker plus at least two independent details before setting accepted.
        let accepted = hasPickupTime && acceptedEvidenceCount >= 3 && (hasCallCustomer || hasProofOfDelivery)
        let expanded=joined.contains("report order") || joined.contains("settle with customer")
        let hasHeader=ordered.contains { isBookingHeader($0.text) }
        let kind:BookingScreenKind = accepted ? .accepted : (expanded ? .expanded : (hasHeader ? .list : .unknown))
        guard kind != .unknown else { return OCRParseResult(screenKind:kind,bookings:[],cardFragments:0,diagnostics:["No recognized Lalamove screen markers"]) }

        let groups=segmentCards(ordered, hasHeader:hasHeader, kind:kind)
        var parsed:[Booking]=[]; var fragments=0
        for (index,group) in groups.enumerated() {
            guard !group.isEmpty else { continue }
            let booking=parseCard(group,kind:kind,position:index,now:now)
            if booking.isComplete && booking.confidence >= 0.30 && BookingValidator.validate(booking).isEmpty {
                parsed.append(booking)
            } else if looksLikeBookingFragment(group) {
                fragments += 1
                parsed.append(booking)
            }
        }
        let diagnostics=parsed.isEmpty ? ["Screen markers found, but no booking card could be safely extracted"] : []
        return OCRParseResult(screenKind:kind,bookings:parsed,cardFragments:fragments,diagnostics:diagnostics)
    }

    public static func parseFareComponents(_ text:String)->FareComponents? {
        if let pair=firstMatch(farePairPattern,in:text), pair.count >= 3,
           let a=number(pair[1]), let b=number(pair[2]) { return FareComponents(base:a,additional:b) }
        if let one=firstMatch(farePattern,in:text), one.count >= 2, let a=number(one[1]) { return FareComponents(base:a,additional:0) }
        return nil
    }

    private static func segmentCards(_ lines:[OCRLine],hasHeader:Bool,kind:BookingScreenKind)->[[OCRLine]] {
        guard hasHeader,kind == .list else { return [lines] }
        let headerIndices=lines.indices.filter { isBookingHeader(lines[$0].text) }
        guard !headerIndices.isEmpty else { return [lines] }
        var groups:[[OCRLine]]=[]
        for (position,start) in headerIndices.enumerated() {
            let end=position+1<headerIndices.count ? headerIndices[position+1] : lines.count
            let group=Array(lines[start..<end])
            if !group.isEmpty { groups.append(group) }
        }
        return groups
    }

    private static func parseCard(_ lines:[OCRLine],kind:BookingScreenKind,position:Int,now:Date)->Booking {
        let texts=lines.map { $0.text.trimmingCharacters(in:.whitespacesAndNewlines) }.filter{ !$0.isEmpty }
        let blob=texts.joined(separator:"\n")
        let fare=parseFareComponents(blob)
        let pickupKm=firstMatch(pickupDistancePattern,in:blob).flatMap{$0.count>1 ? number($0[1]):nil}
        let code=firstMatch(codePattern,in:blob).flatMap{$0.count>1 ? $0[1]:nil}
        let vehicle=texts.first { line in vehicles.contains { TextNormalization.normalize(line).contains(TextNormalization.normalize($0)) } }.map(canonicalVehicle)
        let serviceTypes=["delivery","pabili","purchase"]
        let priorityTypes=["priority","regular","express"]
        let service=texts.first { t in serviceTypes.contains{TextNormalization.normalize(t)==$0} }
        let priority=texts.first { t in priorityTypes.contains{TextNormalization.normalize(t)==$0} }
        let bookingType=[service,priority].compactMap{$0}.joined(separator:" · ")
        let payment:String? = texts.first(where:{TextNormalization.normalize($0).contains("collect cash")}) != nil ? "Collect cash" :
            (texts.first(where:{TextNormalization.normalize($0).contains("settle with customer")}) != nil ? "Settle with customer" : nil)

        var endpoints:[String]=[]; var endpointFull:[String?]=[]
        var lastEndpointOCRLine: OCRLine?
        for (idx,line) in texts.enumerated() {
            let sourceLine = lines.first(where: { $0.text.trimmingCharacters(in: .whitespacesAndNewlines) == line })
            if let labelled=labelledEndpoint(line) {
                endpoints.append(labelled.value); endpointFull.append(labelled.isFull ? labelled.value : nil)
                lastEndpointOCRLine = sourceLine
                continue
            }
            guard isPlaceCandidate(line) else { continue }
            let cleanedPlace = line.replacingOccurrences(of:#"^[O0]\s+(?=[A-Z])"#,with:"",options:[.regularExpression,.caseInsensitive])
            if isAddressDetail(line), !endpoints.isEmpty {
                if endpointFull.last ?? nil == nil {
                    // A detail line may repeat the place/POI heading. Prefer the full
                    // address line instead of concatenating the same place twice.
                    endpoints[endpoints.count-1] = mergeAddressHeading(endpoints.last ?? "", line)
                    endpointFull[endpointFull.count-1] = endpoints[endpoints.count-1]
                } else if sameAddressPrefix(endpoints.last ?? "",line) {
                    // The next OCR line repeats/expands the same street heading.
                    endpoints[endpoints.count-1] = mergeAddressHeading(endpoints.last ?? "", line)
                    endpointFull[endpointFull.count-1] = endpoints[endpoints.count-1]
                } else if isAdjacentAddressContinuation(previous: endpoints.last ?? "", next: line,
                                                        previousLine: lastEndpointOCRLine, nextLine: sourceLine) {
                    // Vision often splits "1850 San Mateo, Philippines" into
                    // "1850 San" + "Mateo, Philippines"; append the wrapped line
                    // instead of creating a false second endpoint.
                    endpoints[endpoints.count-1] = (endpoints.last ?? "") + " " + line
                    endpointFull[endpointFull.count-1] = endpoints[endpoints.count-1]
                } else {
                    // A different numbered street address after a completed pickup address is a new endpoint.
                    endpoints.append(cleanedPlace)
                    endpointFull.append(cleanedPlace)
                }
            } else {
                endpoints.append(cleanedPlace)
                endpointFull.append(isFullAddress(cleanedPlace) ? cleanedPlace : nil)
            }
            if sourceLine != nil { lastEndpointOCRLine = sourceLine }
            _ = idx
        }
        // On the list card, Lalamove displays the pickup above the drop-off.
        // Keep that order; never reverse based on place-name guesses.
        let pickup=endpoints.first
        let dropoff=endpoints.dropFirst().first
        let fullPickup=kind == .expanded || kind == .accepted ? (endpointFull.first ?? nil) : nil
        let fullDropoff=kind == .expanded || kind == .accepted ? (endpointFull.dropFirst().first ?? nil) : nil
        let notes=kind == .list ? texts.first { isLikelyNote($0, knownEndpoints:endpoints) } : nil
        let scoreFields=[pickup != nil,dropoff != nil,fare != nil,vehicle != nil,bookingType.isEmpty == false].filter{$0}.count
        let averageConfidence=lines.isEmpty ? 0 : lines.map{$0.confidence}.reduce(0,+)/Double(lines.count)
        let confidence=min(0.98,Double(scoreFields)/5 * averageConfidence)
        let isComplete=pickup != nil && dropoff != nil && fare != nil && TextNormalization.normalize(pickup ?? "") != TextNormalization.normalize(dropoff ?? "")
        return Booking(bookingCode:code,pickup:pickup,dropoff:dropoff,pickupFullAddress:fullPickup,dropoffFullAddress:fullDropoff,
                       baseFare:fare?.base,additionalFare:fare?.additional,fare:fare?.total,pickupDistanceKm:pickupKm,
                       vehicleType:vehicle,bookingType:bookingType.isEmpty ? nil:bookingType,notes:notes,paymentMethod:payment,
                       confidence:confidence,status:isComplete ? (kind == .accepted ? .accepted : ((kind == .expanded) ? .needsVerification:.detected)):.partial,
                       screenKind:kind,firstSeen:now,lastSeen:now,seenCount:1,lastKnownPosition:position,sourceEvidence:texts)
    }

    private static func isBookingHeader(_ raw:String)->Bool {
        let n=TextNormalization.normalize(raw)
        return n.contains("pick up now") || n.contains("pickup now") ||
            n.range(of:#"booking\s*#?\s*[0-9]{4,}"#,options:.regularExpression) != nil ||
            n.range(of:#"^(today|tomorrow|mon(day)?|tue(sday)?|wed(nesday)?|thu(rsday)?|fri(day)?|sat(urday)?|sun(day)?)\s+\d{1,2}(\s+\d{2})?\s*(am|pm)$"#,options:.regularExpression) != nil
    }
    private static func labelledEndpoint(_ raw:String)->(value:String,isFull:Bool)? {
        let patterns=[#"^(?:pickup|pick\s*up|from)\s*[:：-]?\s*(.+)$"#,#"^(?:drop\s*off|dropoff|destination|to)\s*[:：-]?\s*(.+)$"#]
        for p in patterns { if let m=firstMatch(p,in:raw),m.count>1 {
            let value=m[1].trimmingCharacters(in:.whitespacesAndNewlines)
            let normalized=TextNormalization.normalize(value)
            if normalized == "now" || normalized.hasPrefix("at ") || normalized.contains("am") || normalized.contains("pm") { continue }
            return (value,isFullAddress(value))
        } }
        return nil
    }
    private static func isPlaceCandidate(_ raw:String)->Bool {
        let s=raw.trimmingCharacters(in:.whitespacesAndNewlines), n=TextNormalization.normalize(raw)
        guard s.count>=3 && s.count<=180 && !n.isEmpty else{return false}
        if isInstructionOrCustomerText(s) { return false }
        if isBookingHeader(s) { return false }
        if isVehicleLikeLabel(n) || isRiderWiseInstructionText(n) || isInterfaceLabel(n) { return false }
        if excludedExact.contains(n) || n.hasPrefix("pick up now") || n.hasPrefix("~") {return false}
        if s.range(of:farePattern,options:.regularExpression) != nil || s.range(of:genericDistancePattern,options:.regularExpression) != nil {return false}
        if s.range(of:#"(?:\+?63|0)\s*9[0-9\s-]{8,}"#,options:.regularExpression) != nil {return false}
        if s.range(of:#"^#?\s*[0-9]{6,}$"#,options:.regularExpression) != nil {return false}
        if n.contains("proof of delivery") || n.contains("report order") || n.contains("customer") || n.contains("client") || n.contains("suspicious") || n.contains("find more orders") || n.hasPrefix("today ") {return false}
        if n.contains("settle with") || n.contains("collect cash") || n.contains("call customer") || n.contains("from you") {return false}
        if n.contains("philippines") || n.contains("metro manila") || n.contains("quezon city") || n.contains("street") || n.contains("barangay") || n.contains("brgy") {return true}
        if s.contains(",") {return true}
        // Lalamove collapsed cards commonly display bare localities such as San Mateo and Commonwealth.
        return s.split(separator:" ").count <= 4 && s.range(of:#"^[\p{L} .'-]+$"#,options:.regularExpression) != nil && !n.contains("pick up")
    }
    private static func isInterfaceLabel(_ normalized: String) -> Bool {
        let labels = ["on duty", "off duty", "along the way", "above 50 km", "pickup",
                      "pick up", "record", "wallet", "mission", "profile", "home",
                      "settings", "detected bookings", "newest first", "verify addresses",
                      "confirm accepted", "recommendation status", "net after fuel"]
        return labels.contains(normalized) || labels.contains(where: { normalized.hasPrefix($0 + " ") })
    }

    private static func isRiderWiseInstructionText(_ normalized: String) -> Bool {
        let markers = ["no compatible booking", "accepted reference is incomplete",
                       "confirm its pickup", "confirm its drop off", "confirm its fare",
                       "confirm pickup drop off and fare", "booking yet", "recommendation status",
                       "driver confirms every booking", "open lalamove"]
        return markers.contains(where: { normalized.contains($0) })
    }

    private static func isVehicleLikeLabel(_ normalized: String) -> Bool {
        if vehicles.contains(where: { normalized == TextNormalization.normalize($0) }) { return true }
        // Vision commonly misreads the final letters of "Motorcycle". Compare only
        // short single-token vehicle labels; do not classify arbitrary address lines.
        guard !normalized.contains(" "), normalized.count >= 5, normalized.count <= 14 else { return false }
        return vehicles.filter { !$0.contains(" ") }.contains { vehicle in
            let target = TextNormalization.normalize(vehicle)
            return editDistance(normalized, target) <= 2
        }
    }

    private static func editDistance(_ a: String, _ b: String) -> Int {
        let lhs = Array(a), rhs = Array(b)
        if lhs.isEmpty { return rhs.count }
        if rhs.isEmpty { return lhs.count }
        var previous = Array(0...rhs.count)
        for (i, left) in lhs.enumerated() {
            var current = [i + 1] + Array(repeating: 0, count: rhs.count)
            for (j, right) in rhs.enumerated() {
                current[j + 1] = min(previous[j + 1] + 1, current[j] + 1,
                                     previous[j] + (left == right ? 0 : 1))
            }
            previous = current
        }
        return previous[rhs.count]
    }

    private static func isAdjacentAddressContinuation(previous: String, next: String,
                                                        previousLine: OCRLine?, nextLine: OCRLine?) -> Bool {
        guard let previousLine, let nextLine else { return false }
        // Require close vertical spacing and near-identical left alignment. A new
        // numbered street address is a new endpoint, not a wrapped continuation.
        guard abs(previousLine.y - nextLine.y) <= 0.045,
              abs(previousLine.x - nextLine.x) <= 0.12 else {
            return false
        }
        let prior = TextNormalization.normalize(previous)
        let following = TextNormalization.normalize(next)
        // A four-digit postal code followed by a city/region is commonly the second
        // visual line of one Philippine address (e.g. "Quezon" + "1121 Metro Manila").
        // It must not be promoted to a separate drop-off endpoint.
        let isPostalRegionContinuation = next.range(
            of: #"^\s*[0-9]{4}\s+(?:metro|manila|quezon|caloocan|pasig|makati|marikina|rizal|bulacan|cavite|laguna|city|philippines)\b"#,
            options: [.regularExpression, .caseInsensitive]
        ) != nil
        if isPostalRegionContinuation &&
            (prior.contains(" st") || prior.contains(" street") || prior.contains(" quezon") ||
             prior.contains("metro") || prior.contains("manila") || prior.contains("city")) {
            return true
        }
        // A new numbered street address remains a new endpoint. Use a real regex
        // escape here (not a literal backslash sequence).
        if next.range(of: #"^\s*[0-9]+[A-Za-z]?\s+"#, options: .regularExpression) != nil {
            return false
        }
        guard !prior.isEmpty && !following.isEmpty else { return false }
        let incompleteLocationEnds = [" san", " santa", " sta", " quezon", " metro", " barangay", " brgy"]
        return incompleteLocationEnds.contains(where: { prior.hasSuffix($0) }) ||
            following == "mateo philippines" || following.hasPrefix("mateo philippines ") ||
            following.hasPrefix("rosa") || following.hasPrefix("maria") ||
            following.hasPrefix("city") || following.hasPrefix("manila")
    }

    private static func mergeAddressHeading(_ heading:String,_ detail:String)->String {
        let h=TextNormalization.normalize(heading), d=TextNormalization.normalize(detail)
        // If the detail already contains the heading (common in Lalamove's expanded
        // order screen), do not duplicate it.
        if !h.isEmpty && (d.contains(h) || sameAddressPrefix(heading,detail)) { return detail }
        if !d.isEmpty && h.contains(d) { return heading }
        return heading + ", " + detail
    }
    private static func isInstructionOrCustomerText(_ raw:String)->Bool {
        let n=TextNormalization.normalize(raw)
        let markers=[
            "hi kuya","kuya","pabili","please","kindly","call me","text me","send ko",
            "sa likod","pagpasok","turn left","turn right","turn right sa","turn left sa",
            "customer note","special instruction","instruction","landmark","wait lang",
            "fee","kona yung","need muna","ipick up","i pick up","proof of delivery",
            "small parcel","papadala","reseta",
            "collect cash","settle with customer","client","contact number","call customer"
        ]
        return markers.contains { n.contains(TextNormalization.normalize($0)) }
    }
    private static func sameAddressPrefix(_ first:String,_ second:String)->Bool {
        func prefix(_ value:String)->String {
            let tokens=TextNormalization.normalize(value).split(separator:" ").prefix(3).map(String.init)
            return tokens.joined(separator:" ").replacingOccurrences(of:" street",with:" st")
        }
        let a=prefix(first),b=prefix(second)
        return !a.isEmpty && (a==b || a.hasPrefix(b) || b.hasPrefix(a))
    }
    private static func isFullAddress(_ raw:String)->Bool {
        let n=TextNormalization.normalize(raw)
        return n.contains("philippines") || n.contains("metro manila") || n.contains("quezon city") || n.contains("street") || n.contains("st ") || n.contains("barangay") || n.contains("brgy") || raw.contains(",")
    }
    private static func isAddressDetail(_ raw:String)->Bool { raw.contains(",") && isFullAddress(raw) }
    private static func isLikelyNote(_ raw:String,knownEndpoints:[String])->Bool {
        let n=TextNormalization.normalize(raw)
        if isInstructionOrCustomerText(raw) { return true }
        if knownEndpoints.contains(where:{TextNormalization.normalize($0)==n}) {return false}
        if excludedExact.contains(n) || isPlaceCandidate(raw) {return false}
        if raw.range(of:farePattern,options:.regularExpression) != nil || raw.range(of:genericDistancePattern,options:.regularExpression) != nil {return false}
        return raw.count >= 10 && raw.count <= 180
    }
    private static func looksLikeBookingFragment(_ lines:[OCRLine])->Bool {
        lines.contains{isBookingHeader($0.text)} || lines.contains{ $0.text.range(of:farePattern,options:.regularExpression) != nil }
    }
    private static func canonicalVehicle(_ raw:String)->String {
        let n=TextNormalization.normalize(raw)
        if n.contains("motor") {return "Motorcycle"}; if n.contains("sedan") {return "Sedan"}; if n.contains("mpv") {return "MPV"}
        if n.contains("suv") {return "SUV"}; if n.contains("van") {return "Van"}; if n.contains("truck") {return "Truck"}; if n.contains("car") {return "Car"}
        return raw.capitalized
    }
    private static func number(_ s:String)->Double? { Double(s.replacingOccurrences(of:",",with:"")) }
    private static func firstMatch(_ pattern:String,in text:String)->[String]? {
        guard let regex=try? NSRegularExpression(pattern:pattern,options:[.caseInsensitive]),
              let match=regex.firstMatch(in:text,range:NSRange(text.startIndex...,in:text)) else{return nil}
        return (0..<match.numberOfRanges).map { i in
            guard let r=Range(match.range(at:i),in:text) else{return ""}; return String(text[r])
        }
    }
}
