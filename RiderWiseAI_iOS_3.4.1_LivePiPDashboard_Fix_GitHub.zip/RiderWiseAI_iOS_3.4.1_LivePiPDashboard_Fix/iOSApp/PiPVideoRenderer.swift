import AVFoundation
import AVKit
import CoreMedia
import CoreVideo
import SwiftUI
import UIKit

/// Renders RiderWise's own dashboard into Apple's native PiP surface.
/// It does not mirror or draw over another app's screen.
@MainActor
final class PiPVideoRenderer: NSObject, ObservableObject {
    @Published private(set) var isSupported = AVPictureInPictureController.isPictureInPictureSupported()
    @Published private(set) var isActive = false
    @Published private(set) var status = "PiP is ready when supported."
    @Published private(set) var isReady = false
    /// Last render dimensions reported by AVKit. PiP gestures and window sizing remain iOS-controlled.
    @Published private(set) var pipRenderSizeDescription = "Waiting for iOS PiP size"

    private var displayLayer: AVSampleBufferDisplayLayer?
    private var controller: AVPictureInPictureController?
    private var latestImage: UIImage?
    private var isPlaybackPaused = false
    private var pendingStart = false
    private var possibleObservation: NSKeyValueObservation?
    private var pipAudioSessionActivated = false

    override init() {
        super.init()
    }

    /// The sample-buffer layer must be hosted by a live UIKit view before it is used
    /// as a PiP content source. The SwiftUI host below attaches this layer.
    func attach(displayLayer: AVSampleBufferDisplayLayer) {
        if self.displayLayer === displayLayer { return }
        self.displayLayer = displayLayer
        displayLayer.videoGravity = .resizeAspect
        displayLayer.backgroundColor = UIColor.black.cgColor

        // Use AVSampleBufferDisplayLayer's synchronous enqueue API. The async
        // AVSampleBufferVideoRenderer.Receiver path can throw CancellationError
        // when AVKit flushes/reconfigures the renderer during PiP startup.
        // Direct enqueue avoids an unowned cancellable Task for each dashboard frame.
        displayLayer.controlTimebase = nil
        configureController()
        isReady = controller != nil
        if let latestImage { enqueue(latestImage) }
        status = isReady ? "PiP display surface attached. Waiting for iOS readiness." : "PiP could not initialize on this device."
    }

    func start(image: UIImage) {
        latestImage = image
        guard isSupported, let controller, displayLayer != nil else {
            status = "PiP display surface is not ready yet, or PiP is unavailable on this device."
            return
        }
        guard !controller.isPictureInPictureActive else {
            status = "RiderWise PiP dashboard is already active."
            return
        }
        do {
            try activatePiPAudioSession()
        } catch {
            status = "PiP audio/background playback setup failed: \(error.localizedDescription)"
            return
        }
        pendingStart = true
        status = "Preparing the RiderWise dashboard for PiP…"
        // Wait until AVFoundation has accepted the first frame before asking iOS
        // to start PiP. Calling start immediately after enqueue can race readiness.
        enqueue(image) { [weak self] in self?.attemptPendingStart() }
    }

    func update(image: UIImage) {
        latestImage = image
        guard isSupported, displayLayer != nil, !isPlaybackPaused else { return }
        enqueue(image)
    }

    func stop() {
        controller?.stopPictureInPicture()
    }

    /// Apple requires the app to be configured for background audio playback
    /// before AVKit can make Picture in Picture available. Mix with other audio
    /// so starting the silent visual dashboard does not take over the user's audio.
    private func activatePiPAudioSession() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])
        try session.setActive(true)
        pipAudioSessionActivated = true
    }

    private func deactivatePiPAudioSession() {
        guard pipAudioSessionActivated else { return }
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        } catch {
            status = "PiP stopped; audio session cleanup warning: \(error.localizedDescription)"
        }
        pipAudioSessionActivated = false
    }

    private func configureController() {
        guard isSupported, let displayLayer else { return }
        let source = AVPictureInPictureController.ContentSource(
            sampleBufferDisplayLayer: displayLayer,
            playbackDelegate: self
        )
        let pip = AVPictureInPictureController(contentSource: source)
        pip.delegate = self
        pip.requiresLinearPlayback = true
        pip.canStartPictureInPictureAutomaticallyFromInline = false
        controller = pip
        possibleObservation = pip.observe(\.isPictureInPicturePossible, options: [.initial, .new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in self?.attemptPendingStart() }
        }
    }

    private func attemptPendingStart() {
        guard pendingStart, let controller else { return }
        guard !controller.isPictureInPictureActive else {
            pendingStart = false
            return
        }
        guard controller.isPictureInPicturePossible else {
            status = "Dashboard frame is ready. Waiting for iOS to allow PiP in the current app state…"
            return
        }
        pendingStart = false
        status = "Starting RiderWise PiP dashboard…"
        controller.startPictureInPicture()
    }

    private func enqueue(_ image: UIImage, completion: (() -> Void)? = nil) {
        guard let cgImage = image.cgImage,
              let pixelBuffer = makePixelBuffer(cgImage) else {
            status = "Could not render the PiP dashboard frame."
            return
        }
        var format: CMVideoFormatDescription?
        guard CMVideoFormatDescriptionCreateForImageBuffer(
            allocator: kCFAllocatorDefault,
            imageBuffer: pixelBuffer,
            formatDescriptionOut: &format
        ) == noErr, let format else { return }

        var timing = CMSampleTimingInfo(
            duration: CMTime(value: 1, timescale: 2),
            presentationTimeStamp: CMClockGetTime(CMClockGetHostTimeClock()),
            decodeTimeStamp: .invalid
        )
        var sample: CMSampleBuffer?
        guard CMSampleBufferCreateReadyWithImageBuffer(
            allocator: kCFAllocatorDefault,
            imageBuffer: pixelBuffer,
            formatDescription: format,
            sampleTiming: &timing,
            sampleBufferOut: &sample
        ) == noErr, let sample else {
            status = "Could not prepare PiP video frame."
            return
        }
        guard let displayLayer else {
            status = "PiP display layer is not attached."
            return
        }
        // Recover a failed display layer before submitting a new frame.
        if displayLayer.status == .failed {
            let message = displayLayer.error?.localizedDescription ?? "Unknown display-layer error"
            displayLayer.flush()
            status = "PiP renderer recovered after display-layer error: \(message)"
        }
        // This dashboard is a live status surface, not a time-scheduled movie.
        // Present each new state immediately instead of allowing an old timed frame to linger.
        CMSetAttachment(
            sample,
            key: kCMSampleAttachmentKey_DisplayImmediately,
            value: kCFBooleanTrue,
            attachmentMode: kCMAttachmentMode_ShouldNotPropagate
        )
        displayLayer.enqueue(sample)
        if displayLayer.status == .failed {
            status = "PiP frame enqueue failed: \(displayLayer.error?.localizedDescription ?? "AVSampleBufferDisplayLayer failed")"
            return
        }
        completion?()
    }

    private func makePixelBuffer(_ cgImage: CGImage) -> CVPixelBuffer? {
        let width = 640, height = 360
        let attrs: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]
        var output: CVPixelBuffer?
        guard CVPixelBufferCreate(
            kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
            attrs as CFDictionary, &output
        ) == kCVReturnSuccess, let buffer = output else { return nil }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width, height: height, bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue |
                CGBitmapInfo.byteOrder32Little.rawValue
        ) else { return nil }
        context.interpolationQuality = .high
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        return buffer
    }

    static func makeDashboardFrame(
        reference: String,
        topRecommendation: String,
        detail: String,
        count: Int,
        scanning: Bool
    ) -> UIImage {
        let size = CGSize(width: 640, height: 360)
        return UIGraphicsImageRenderer(size: size).image { renderer in
            let c = renderer.cgContext
            c.setFillColor(UIColor(red: 0.055, green: 0.075, blue: 0.11, alpha: 1).cgColor)
            c.fill(CGRect(origin: .zero, size: size))

            func text(_ value: String, _ rect: CGRect, _ font: UIFont, _ color: UIColor) {
                (value as NSString).draw(in: rect, withAttributes: [
                    .font: font, .foregroundColor: color,
                    .paragraphStyle: {
                        let p = NSMutableParagraphStyle()
                        p.lineBreakMode = .byTruncatingTail
                        return p
                    }()
                ])
            }

            text("RIDERWISE AI", CGRect(x: 28, y: 22, width: 350, height: 30),
                 .boldSystemFont(ofSize: 22), .white)
            text(scanning ? "LIVE OCR" : "SCAN PAUSED",
                 CGRect(x: 470, y: 26, width: 145, height: 22),
                 .boldSystemFont(ofSize: 13), scanning ? .systemGreen : .systemOrange)

            c.setFillColor(UIColor(white: 1, alpha: 0.08).cgColor)
            c.fill(CGRect(x: 24, y: 70, width: 592, height: 76))
            text("ACCEPTED REFERENCE", CGRect(x: 42, y: 83, width: 300, height: 18),
                 .boldSystemFont(ofSize: 12), .systemTeal)
            text(reference.isEmpty ? "No accepted booking selected" : reference,
                 CGRect(x: 42, y: 105, width: 550, height: 28),
                 .boldSystemFont(ofSize: 18), .white)

            c.setFillColor(UIColor(red: 0.10, green: 0.27, blue: 0.22, alpha: 1).cgColor)
            c.fill(CGRect(x: 24, y: 164, width: 592, height: 112))
            text("TOP RECOMMENDATION", CGRect(x: 42, y: 178, width: 340, height: 18),
                 .boldSystemFont(ofSize: 12), .systemGreen)
            text(topRecommendation.isEmpty ? "Waiting for compatible bookings" : topRecommendation,
                 CGRect(x: 42, y: 205, width: 550, height: 30),
                 .boldSystemFont(ofSize: 21), .white)
            text(detail.isEmpty ? "New OCR results refresh this dashboard." : detail,
                 CGRect(x: 42, y: 240, width: 550, height: 24),
                 .systemFont(ofSize: 13), UIColor(white: 0.83, alpha: 1))
            text("\(count) recommendation(s) · Driver confirms every booking",
                 CGRect(x: 28, y: 312, width: 584, height: 22),
                 .systemFont(ofSize: 13), UIColor(white: 0.72, alpha: 1))
        }
    }
}

@MainActor
extension PiPVideoRenderer: @preconcurrency AVPictureInPictureControllerDelegate {
    func pictureInPictureControllerDidStartPictureInPicture(_ controller: AVPictureInPictureController) {
        pendingStart = false
        isActive = true
        status = "RiderWise PiP dashboard is active."
    }

    func pictureInPictureControllerDidStopPictureInPicture(_ controller: AVPictureInPictureController) {
        pendingStart = false
        isActive = false
        status = "RiderWise PiP dashboard is closed."
        deactivatePiPAudioSession()
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        failedToStartPictureInPictureWithError error: Error
    ) {
        pendingStart = false
        isActive = false
        status = "PiP failed to start: \(error.localizedDescription)"
        deactivatePiPAudioSession()
    }
}

@MainActor
extension PiPVideoRenderer: @preconcurrency AVPictureInPictureSampleBufferPlaybackDelegate {
    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        setPlaying playing: Bool
    ) {
        isPlaybackPaused = !playing
        if playing, let latestImage { enqueue(latestImage) }
        controller.invalidatePlaybackState()
    }

    func pictureInPictureControllerIsPlaybackPaused(
        _ controller: AVPictureInPictureController
    ) -> Bool { isPlaybackPaused }

    func pictureInPictureControllerTimeRangeForPlayback(
        _ controller: AVPictureInPictureController
    ) -> CMTimeRange {
        // This is a continuously refreshed live dashboard, not a finite video clip.
        CMTimeRange(start: .zero, duration: .positiveInfinity)
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        didTransitionToRenderSize newRenderSize: CMVideoDimensions
    ) {
        // AVKit reports the native PiP window's new render size after system-managed
        // gestures (for example, a size change). Never intercept or replace those gestures.
        pipRenderSizeDescription = "\(newRenderSize.width) × \(newRenderSize.height)"
        // Refresh the live dashboard after the transition so the latest information
        // remains visible at the new system-selected PiP size.
        if let latestImage, !isPlaybackPaused {
            enqueue(latestImage)
        }
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        skipByInterval interval: CMTime,
        completion completionHandler: @escaping @Sendable () -> Void
    ) {
        // A live dashboard has no seekable timeline; always finish the system request.
        completionHandler()
    }

    nonisolated func pictureInPictureControllerShouldProhibitBackgroundAudioPlayback(
        _ controller: AVPictureInPictureController
    ) -> Bool {
        true
    }
}


/// UIKit host for AVSampleBufferDisplayLayer. Keeping the layer in the view hierarchy
/// gives AVKit a real render surface for its sample-buffer PiP content source.
final class PiPSampleBufferDisplayView: UIView {
    override class var layerClass: AnyClass { AVSampleBufferDisplayLayer.self }
    var sampleBufferDisplayLayer: AVSampleBufferDisplayLayer {
        layer as! AVSampleBufferDisplayLayer
    }
}

struct PiPDisplayLayerHost: UIViewRepresentable {
    @ObservedObject var renderer: PiPVideoRenderer

    func makeUIView(context: Context) -> PiPSampleBufferDisplayView {
        let view = PiPSampleBufferDisplayView(frame: .zero)
        renderer.attach(displayLayer: view.sampleBufferDisplayLayer)
        return view
    }

    func updateUIView(_ uiView: PiPSampleBufferDisplayView, context: Context) {
        renderer.attach(displayLayer: uiView.sampleBufferDisplayLayer)
    }
}
