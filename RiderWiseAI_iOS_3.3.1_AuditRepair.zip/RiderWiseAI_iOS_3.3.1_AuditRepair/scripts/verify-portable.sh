#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test
while IFS= read -r -d '' f; do
  swiftc -frontend -parse "$f" >/dev/null
done < <(find iOSApp BroadcastExtension Sources/RiderWiseCore -type f -name '*.swift' -print0)
python3 - <<'PY'
import gzip, json, pathlib, plistlib, collections, re
root=pathlib.Path('.')
plistlib.loads((root/'iOSApp/Info.plist').read_bytes())
plistlib.loads((root/'BroadcastExtension/Info.plist').read_bytes())
app_entitlements = plistlib.loads((root/'iOSApp/RiderWiseAI.entitlements').read_bytes())
ext_entitlements = plistlib.loads((root/'BroadcastExtension/RiderWiseBroadcast.entitlements').read_bytes())
app_groups = app_entitlements.get('com.apple.security.application-groups', [])
ext_groups = ext_entitlements.get('com.apple.security.application-groups', [])
assert app_groups and app_groups == ext_groups, 'App Group entitlements must match between host app and broadcast extension'
project=(root/'project.yml').read_text()
assert 'ph.riderwise.ai.broadcast' in project
assert 'RiderWiseBroadcast' in project
geo=root/'iOSApp/Resources/Geography'
for name in ['luzon_psgc_3q_2026.json','luzon_psgc_3q_2026.json.gz','geographic_centroids_legacy.json','riderwise_upgrade_config.json']:
    assert (geo/name).is_file(), f'Missing app geography resource: {name}'
with gzip.open(root/'Sources/RiderWiseCore/luzon_psgc_3q_2026.json.gz','rt',encoding='utf-8') as f:
    data=json.load(f)
records=data['records']
codes={r['psgc'] for r in records}
counts=collections.Counter(r['level'] for r in records)
assert len(records)==21330 and len(codes)==len(records)
assert dict(counts)=={'Reg':8,'Prov':38,'City':77,'Mun':694,'SubMun':14,'Bgy':20499}
assert all(not r.get('parentPsgc') or r['parentPsgc'] in codes for r in records)
config=json.loads((geo/'riderwise_upgrade_config.json').read_text())
assert config['scan']['interval_ms']==2500
assert config['safety']['auto_accept_bookings'] is False
assert config['safety']['auto_reject_bookings'] is False
assert config['ai']['large_local_model_autostart'] is False
print('Info.plists, App Group entitlements, scan/safety config: PASS')
print('Geographic resources present: PASS')
print('PSGC dataset: PASS (21,330 records, unique codes, valid parent links)')
PY
