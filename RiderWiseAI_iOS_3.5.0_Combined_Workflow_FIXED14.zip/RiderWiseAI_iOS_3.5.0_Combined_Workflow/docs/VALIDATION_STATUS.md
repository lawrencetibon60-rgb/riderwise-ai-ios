# Validation status — current workspace

## Executed checks

- `swift test` on Linux / Swift 6.2: **34 tests passed, 0 failed**.
- `swiftc -frontend -parse` on all iOS app, Broadcast Extension, Live Activity and core Swift files: **syntax parse passed**.
- Original Android source ZIP opened and reviewed.
- Three supplied Lalamove iPhone screenshots used as OCR parser reference fixtures.
- App icon asset and XcodeGen project configuration created.

## Not executed

- XcodeGen project generation.
- `xcodebuild` simulator compilation.
- `xcodebuild` generic iOS device compilation.
- iPhone installation, permission prompt and ReplayKit broadcast stream.
- Live Activity extension runtime.
- LiteRT-LM package resolution and model load.
- Gemma model download from the app and on-device SHA verification.
- iPhone 13 Pro Max memory, thermal, battery and scan-cadence measurements.
- Signed IPA export, TestFlight upload or physical installation.

## Why this distinction matters

The Linux Swift test target compiles only `Sources/RiderWiseCore`. The iOS app and extension depend on Apple's iOS SDK, ScreenCaptureKit, Vision, ActivityKit, WidgetKit and LiteRT-LM. They must be compiled by Xcode on macOS. Syntax parsing is not an iOS build.

## Current result

The portable core is tested. The native iOS application is a prepared source/build project, not yet a verified installable iOS release.


## Consolidated audit update (2026-11-21)
See `CONSOLIDATED_SOURCE_AUDIT.md`. Portable verification passed with 34 tests, Swift parser checks, plist validation and Luzon PSGC resource integrity. Apple Xcode build and physical iPhone PiP/ReplayKit validation remain pending.


## Uploaded source package verification — 2026-11-21

- Source ZIP: opened and integrity verified (75 entries).
- `bash scripts/verify-portable.sh`: PASS.
- RiderWiseCore unit tests: 34 passed, 0 failed.
- Swift parser: 32 Swift files passed.
- App and Broadcast Extension Info.plists: valid.
- App Group entitlement identifiers: match (`group.ph.riderwise.ai`).
- Luzon PSGC compressed data: 21,330 records, unique codes, valid parent links.
- GitHub workflow: updated to discover source ZIP or extracted project rather than assuming a single current directory.
- Still pending: GitHub macOS/Xcode 27 build, simulator/device target compilation, ReplayKit/PiP physical-device validation, signing and IPA export.


## 3.3.4 migration work

ReplayKit Broadcast Upload Extension removed from the active target. Added iOS 27 ScreenCaptureKit picker/stream/output path and migrated PiP frame enqueue to `AVSampleBufferVideoRenderer` via `sampleBufferRenderer`. This is source-level work only; Xcode 27 build and iPhone validation remain mandatory.


## 3.4.5 full-pipeline audit update (2026-11-24)
- Fixed missing app-target symbols (`recommendationStatus`, `referenceSnapshot`, and `removeRiderWiseOverlay`).
- Reworked ScreenCaptureManager frame state, first-frame race handling, stream identity checks, no-frame watchdog/recovery, OCR queue backpressure, and 1.5-second cadence.
- Added PiP-overlay OCR filtering and a regression test.
- Current portable result: 45 tests passed, 0 failed; 29 Swift files parsed with no syntax errors; source/resource audit passed.
- Xcode 27 Simulator/device archive and physical iPhone 13 Pro Max testing are still required.


## 3.4.9 wrapped accepted-address regression repair (2026-11-24)
- Reproduced a parser defect where a wrapped pickup-address continuation such as `Mateo, Philippines` could be interpreted as the drop-off.
- Added coordinate-aware continuation merging and an accepted-screen regression fixture.
- Portable validation: 53 tests passed, 0 failed; `scripts/verify-portable.sh` passed.
- Xcode/iOS SDK archive and physical iPhone capture/OCR/PiP acceptance tests remain unexecuted. See `3.4.9_WRAPPED_ADDRESS_OCR_REPAIR.md`.


## 3.4.9 build-pipeline correction (2026-11-25)

- ScreenCaptureKit is an iOS 27 framework. The native capture implementation therefore requires the iOS 27 SDK and an iOS 27 deployment target.
- The combined GitHub Actions workflow runs portable tests, XcodeGen, simulator build, physical-device archive, IPA packaging, and artifact upload in one job on the `xcode-27` runner.
- The native Xcode archive and physical iPhone capture/PiP runtime still require GitHub Actions and device execution; they are not claimed as locally verified.


## 3.5.0 partial-booking and fare repair (2026-11-25)
- Fixed missing-fare defaulting: incomplete OCR records now retain `fare == nil` instead of being displayed as ₱0.00.
- Added conservative unique-match reconciliation for partial observations so repeated scans can update an existing partial record without arbitrarily merging ambiguous cards.
- Regression coverage added for absent fare, repeated partial scans, ambiguous matches and conflicting identity fields.
- `bash scripts/verify-portable.sh`: PASS; 61 Swift tests passed, 0 failed.
- Xcode 27 build/archive, IPA export and physical iPhone capture/OCR validation remain pending.


## 3.5.0 RiderWise UI OCR leakage repair (2026-11-25)
- Fixed the overlay filter so combined OCR lines containing RiderWise controls (for example `Verify addresses Confirm accepted`) are rejected by substring, not only exact text equality.
- Added regression tests that ensure combined controls and dashboard-only text cannot become booking records.
- `bash scripts/verify-portable.sh`: PASS; 63 Swift tests passed, 0 failed; geographic resources and source-level iOS capture/PiP checks passed.
- Physical-device OCR validation, Xcode 27 archive and IPA export remain pending.


## 3.5.0 self-dashboard OCR false-positive repair (2026-11-25)
- Supplied 11-second recording showed the RiderWise dashboard while OCR cards repeatedly contained RiderWise's own `Pick Up Now` text.
- Confirmed source defect: `pick up now` alone counted as Lalamove screen evidence; background frames without that evidence could also be forwarded to the parser.
- Tightened Lalamove screen evidence, added independent offer-card signals, and made capture forwarding require verified Lalamove evidence in all app states.
- Added dashboard false-positive and genuine-offer regression tests.
- `bash scripts/verify-portable.sh`: PASS; 65 tests passed, 0 failed; source, entitlement, and geography checks passed.
- Xcode 27 archive/IPA and physical iPhone Lalamove/PiP validation remain pending.


## 3.5.0 endpoint contamination and ingestion-gate repair (2026-11-26)
- FIXED9 follow-up screenshot confirmed new OCR output contamination: interface labels, vehicle text and truncated RiderWise PiP recommendation text were being parsed as endpoints.
- Tightened full-screen RiderWise/dashboard detection, endpoint candidate validation, fuzzy vehicle-label exclusion, and RiderWise instruction-text exclusion.
- Added independent source-screen evidence checks at both broadcast and image OCR ingestion entry points.
- Added regression coverage for the reported contamination patterns.
- `bash scripts/verify-portable.sh`: PASS; 68 tests passed, 0 failed; source, entitlement, and geography checks passed.
- Xcode 27 device archive/IPA and physical iPhone validation remain pending.


## 3.5.0 uploaded pickup-screen regression repair (2026-11-26)
- Added coordinate-aware OCR-line regression fixture derived from the user's 1284 × 2778 Lalamove screenshot: Bagong Silangan → Pasig (₱125), San Mateo → Marikina (₱91), and a clipped third card that must remain partial.
- Tightened offer-header matching to avoid splitting a card on customer-note sentences containing `Pick Up Now`.
- Expanded Filipino customer-note filtering and changed single-word marker matching to whole-token matching, preventing `ate` inside `San Mateo` from suppressing a real pickup locality.
- Tightened vehicle label normalization and OCR typo handling; added regression for `Motorcycia` and `Carmona`.
- `swift test`: PASS; 71 tests, 0 failures.
- `bash scripts/verify-portable.sh`: PASS; source parsing, capture/PiP guards, entitlements, and geographic resources passed.
- Screenshot test is based on coordinate-aware OCR-line fixture, not end-to-end Apple Vision processing of the raw image. Xcode 27 build/archive/IPA and physical iPhone capture/OCR/PiP acceptance remain pending because xcodebuild is unavailable in this Linux environment.


## 3.5.0 accepted-screen and PiP reference repair (2026-11-26)
- Fixed split OCR variants of the RiderWise PiP title (`RIDER WISE AI`) and leaked `LIVE OCR → ...` overlay text.
- Automatic accepted status/reference promotion now requires a readable Lalamove booking number; otherwise the screen remains available for manual verification.
- Removed the automatic-reference deadlock caused by Clear being pressed when no reference existed.
- Added upgrade migration to demote unreferenced legacy accepted records without a booking number; explicitly selected references are preserved.
- `bash scripts/verify-portable.sh`: PASS; 75 tests passed, 0 failed; ScreenCaptureKit/PiP, geographic and PSGC checks passed.
- Xcode 27 archive/IPA and physical iPhone acceptance testing remain pending.


## 3.5.0 FIXED13 endpoint contamination repair (2026-11-26)
- Rejected service/vehicle/navigation UI tokens from OCR endpoint candidates, including `l Delivery`, `u Delivery`, and `ur Delivery`.
- Strengthened spatial booking-header segmentation while preserving default-coordinate unit fixtures.
- Added safe migration for existing contaminated records: clear only obvious UI/service endpoint fields, retain the record/evidence, reset verification, cap confidence, and demote accepted/verified entries to needs-verification.
- Preserved and reran the user-screenshot regression fixture for Bagong Silangan → Pasig (₱125), San Mateo → Marikina (₱91), and a third partial card.
- `bash scripts/verify-portable.sh`: PASS; 79 tests passed, 0 failed; capture, PiP, accepted-reference, geography and PSGC checks passed.
- Xcode 27 archive/IPA and physical iPhone testing remain pending.


## 3.5.0 FIXED14 PiP/notification OCR repair (2026-11-26)
- Reopened the exact FIXED13 ZIP after user confirmed the screenshots were from FIXED13.
- Added clipped PiP title recognition (`RWISE AI`, `RWISE`, `WISE AI`) with geometry-aware overlay exclusion.
- Added iOS notification banner phrase filtering for `immediate`, `Hurry up`, `[Delivery]`, and `You've got a`; only route-arrow fragments within the banner band are removed so valid `Pick Up At` headers remain.
- Single-token place candidates now require a match in the packaged Luzon PSGC index, including common City/Municipality aliases; rejects `equia`, preserves known localities.
- Added regression tests for clipped PiP, notification contamination, and OCR garbage.
- `bash scripts/verify-portable.sh`: PASS; 82 tests passed, 0 failed; ScreenCaptureKit, PiP, accepted-reference, geographic and PSGC checks passed.
- Xcode 27 archive/IPA, Apple Vision live OCR and physical iPhone testing remain pending.
