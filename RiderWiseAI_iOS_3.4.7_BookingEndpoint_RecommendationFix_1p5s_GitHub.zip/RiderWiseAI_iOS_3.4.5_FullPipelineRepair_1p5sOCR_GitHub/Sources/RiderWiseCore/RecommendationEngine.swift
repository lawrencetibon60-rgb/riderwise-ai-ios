import Foundation

public struct Recommendation: Codable, Identifiable, Sendable {
    public var id:String
    public var anchorBookingID:String
    /// Kept for simple two-booking UI compatibility; first candidate in the combination.
    public var candidateBookingID:String
    public var candidateBookingIDs:[String]
    public var bookingIDs:[String]
    public var label:String
    public var score:Double
    public var reason:String
    public var requiresVerification:Bool
    public var lastSeen:Date
    public var availability:String
    public var basis:String
    public var sequence:String
    public var totalFare:Double
    public var detourKm:Double?
    /// Deprecated compatibility field; always zero. RiderWise no longer uses pickup heatmaps.
    public var areaActivityScore:Double

    public init(id:String,anchorBookingID:String,candidateBookingID:String,candidateBookingIDs:[String]?=nil,
                bookingIDs:[String]?=nil,label:String,score:Double,reason:String,requiresVerification:Bool,
                lastSeen:Date,availability:String,basis:String,sequence:String="",totalFare:Double=0,
                detourKm:Double?=nil,areaActivityScore:Double=0) {
        self.id=id; self.anchorBookingID=anchorBookingID; self.candidateBookingID=candidateBookingID
        self.candidateBookingIDs=candidateBookingIDs ?? [candidateBookingID]
        self.bookingIDs=bookingIDs ?? [anchorBookingID,candidateBookingID]
        self.label=label; self.score=score; self.reason=reason; self.requiresVerification=requiresVerification
        self.lastSeen=lastSeen; self.availability=availability; self.basis=basis; self.sequence=sequence
        self.totalFare=totalFare; self.detourKm=detourKm; self.areaActivityScore=areaActivityScore
    }
}

public enum RecommendationEngine {
    private static let maximumCandidates=10
    private static let maximumCombinationSize=6
    private static let maximumSearchNodes=6_000
    private static let maximumResults=30

    private struct RouteSearch {
        var bestDistance=Double.infinity
        var bestSequence:[String]=[]
        var nodes=0
    }
    private struct ResolvedGeoPoint {
        let point:GeoPoint
        let usesParentLocalityFallback:Bool
        let usesApproximateCentroidFallback:Bool
    }

    /// Reference-based combinations follow the Android source: deterministic location and
    /// vehicle checks first, then bounded pickup/drop-off ordering search from reference drop-off.
    public static func referenceBased(reference:Booking,candidates:[Booking],centroids:CentroidResolver?=nil,
                                      psgc:PSGCResolver?=nil,history:[Booking]=[])->[Recommendation] {
        guard reference.isComplete,
              let refPickup=resolvedPoint(reference.effectivePickup,centroids:centroids,psgc:psgc),
              let refDropoff=resolvedPoint(reference.effectiveDropoff,centroids:centroids,psgc:psgc) else { return [] }
        var seen=Set<String>()
        var eligible=candidates.filter { candidate in
            guard candidate.id != reference.id,candidate.isComplete,
                  candidate.status != .accepted,candidate.status != .dismissed,
                  candidate.status != .delivered,candidate.status != .notVisible,candidate.status != .stale,
                  let pickup=candidate.effectivePickup,let dropoff=candidate.effectiveDropoff,
                  resolvedPoint(pickup,centroids:centroids,psgc:psgc) != nil,
                  resolvedPoint(dropoff,centroids:centroids,psgc:psgc) != nil else { return false }
            if let a=reference.vehicleType,let b=candidate.vehicleType,
               !a.isEmpty && !b.isEmpty && TextNormalization.normalize(a) != TextNormalization.normalize(b) { return false }
            return seen.insert(candidate.id).inserted
        }
        eligible.sort { lhs,rhs in
            if lhs.confidence != rhs.confidence { return lhs.confidence > rhs.confidence }
            return lhs.lastSeen > rhs.lastSeen
        }
        if eligible.count>maximumCandidates { eligible=Array(eligible.prefix(maximumCandidates)) }
        guard !eligible.isEmpty else{return []}

        var results:[Recommendation]=[]
        func enumerate(_ start:Int,_ chosen:[Booking]) {
            if !chosen.isEmpty,let result=evaluate(chosen,reference:reference,referencePickup:refPickup,
                referenceDropoff:refDropoff,history:history,centroids:centroids,psgc:psgc) { results.append(result) }
            guard chosen.count<maximumCombinationSize else{return}
            for index in start..<eligible.count { enumerate(index+1,chosen+[eligible[index]]) }
        }
        enumerate(0,[])
        results.sort { $0.score > $1.score }
        return Array(results.prefix(maximumResults))
    }

    /// Explains why a reference-based recommendation list is empty. This is diagnostic
    /// output only; it never relaxes geographic or safety filters.
    public static func explainEmptyReferenceBased(reference:Booking,candidates:[Booking],
                                                   centroids:CentroidResolver?,psgc:PSGCResolver?)->String {
        guard reference.isComplete else { return "The accepted reference is incomplete. Confirm its pickup, drop-off and fare." }
        guard let refPickup=resolvedPoint(reference.effectivePickup,centroids:centroids,psgc:psgc),
              let refDropoff=resolvedPoint(reference.effectiveDropoff,centroids:centroids,psgc:psgc) else {
            return "The accepted reference locations could not be resolved. Open the reference booking and verify both full addresses."
        }
        guard !candidates.isEmpty else { return "No recent, complete, visible candidate bookings are available. Keep the offer cards visible during scanning." }
        var reasons:[String]=[]
        var individuallyFeasible=0
        for candidate in candidates.prefix(5) {
            let name="\(candidate.pickup ?? "?") → \(candidate.dropoff ?? "?")"
            guard candidate.isComplete, let pickupName=candidate.effectivePickup, let dropName=candidate.effectiveDropoff,
                  let pickup=resolvedPoint(pickupName,centroids:centroids,psgc:psgc),
                  let drop=resolvedPoint(dropName,centroids:centroids,psgc:psgc) else {
                reasons.append("\(name): incomplete or unresolved location")
                continue
            }
            if let a=reference.vehicleType,let b=candidate.vehicleType,!a.isEmpty,!b.isEmpty,
               TextNormalization.normalize(a) != TextNormalization.normalize(b) {
                reasons.append("\(name): vehicle type mismatch")
                continue
            }
            let match=RouteCompatibilityEngine.evaluate(referencePickup:refPickup.point,referenceDropoff:refDropoff.point,
                candidatePickup:pickup.point,candidateDropoff:drop.point,
                usesParentLocalityFallback:pickup.usesParentLocalityFallback || drop.usesParentLocalityFallback)
            if match.feasible {
                individuallyFeasible += 1
                reasons.append("\(name): individual route corridor passed (\(match.label))")
            } else {
                reasons.append("\(name): NOT ROUTE-COMPATIBLE — pickup/drop-off corridor or direction threshold failed (approx. \(String(format:"%.1f",match.deviationKm ?? 0)) km deviation)")
            }
        }
        let summary=reasons.isEmpty ? "No candidate passed the route-corridor and direction checks." : reasons.joined(separator:"; ")
        if individuallyFeasible > 0 {
            return "\(individuallyFeasible) candidate(s) passed the individual route check, but no valid pickup/drop-off order was found for a combined trip. \(summary). Approximate centroids are screening estimates only; verify full addresses."
        }
        return "No route-compatible recommendation yet. \(summary). Approximate centroids are screening estimates only; verify full addresses."
    }

    /// Reference-free matching preserves the Android source's pickup-gap/drop-off-gap logic.
    /// Ambiguous short locality names may use the legacy approximate centroid only for a
    /// clearly labelled shortlist; the score is capped and the driver must verify the full address.
    public static func referenceFree(bookings:[Booking],centroids:CentroidResolver?=nil,
                                      psgc:PSGCResolver?=nil)->[Recommendation] {
        let candidates=Array(bookings.filter{$0.isComplete && $0.status != .accepted && $0.status != .dismissed && $0.status != .delivered && $0.status != .notVisible && $0.status != .stale}.prefix(100))
        guard candidates.count>1 else{return []}
        var bestBySuggested:[String:Recommendation]=[:]
        for i in candidates.indices {
            for j in candidates.indices where j>i {
                let a=candidates[i],b=candidates[j]
                if let av=a.vehicleType,let bv=b.vehicleType,!av.isEmpty,!bv.isEmpty,
                   TextNormalization.normalize(av) != TextNormalization.normalize(bv) { continue }
                guard let ap=pointAllowingAmbiguous(a.effectivePickup,centroids:centroids,psgc:psgc),
                      let bp=pointAllowingAmbiguous(b.effectivePickup,centroids:centroids,psgc:psgc),
                      let ad=pointAllowingAmbiguous(a.effectiveDropoff,centroids:centroids,psgc:psgc),
                      let bd=pointAllowingAmbiguous(b.effectiveDropoff,centroids:centroids,psgc:psgc) else { continue }
                let pickupGap=GeoMath.distanceKm(ap,bp),dropGap=GeoMath.distanceKm(ad,bd)
                guard pickupGap.isFinite,dropGap.isFinite,pickupGap<=6,dropGap<=9 else{continue}
                // Every coordinate in this offline legacy centroid table is explicitly
                // approximate/unverified, even when the locality name itself is unique.
                let requiresVerification = true
                let pickupFit=max(0,1-pickupGap/6),dropFit=max(0,1-dropGap/9)
                var score=pickupFit*0.45+dropFit*0.55
                if requiresVerification { score=min(score,0.59) }
                let anchor:Booking,suggested:Booking
                if a.firstSeen <= b.firstSeen { anchor=a; suggested=b } else { anchor=b; suggested=a }
                // Always identify the exact candidate route in the UI; a generic
                // "potential booking" label is not actionable when several cards exist.
                let label="POTENTIAL: \(suggested.pickup ?? "?") → \(suggested.dropoff ?? "?")"
                let basis="APPROXIMATE LEGACY CENTROID COMPARISON; PICKUP-GAP AND DROPOFF-GAP; NOT ROAD ROUTING"
                let reason="No accepted reference booking is set. Earlier observed route: \(anchor.pickup ?? "?") → \(anchor.dropoff ?? "?"). Candidate route: \(suggested.pickup ?? "?") → \(suggested.dropoff ?? "?"). Pickup areas are approximately \(String(format:"%.1f",pickupGap)) km apart and destinations approximately \(String(format:"%.1f",dropGap)) km apart by straight-line centroids. This is route similarity only, not proof that two orders can be combined. Offline centroid coordinates are approximate; open the Lalamove card and verify the full address."
                let id=pairID(anchor.id,suggested.id)
                let rec=Recommendation(id:id,anchorBookingID:anchor.id,candidateBookingID:suggested.id,
                    candidateBookingIDs:[suggested.id],bookingIDs:[anchor.id,suggested.id],label:label,score:score,reason:reason,
                    requiresVerification:requiresVerification,lastSeen:max(anchor.lastSeen,suggested.lastSeen),
                    availability:"LAST_SEEN_NOT_LIVE_AVAILABILITY",basis:basis,
                    sequence:"EARLIER OBSERVED: \(anchor.pickup ?? "?") → \(anchor.dropoff ?? "?") | REVIEW: \(suggested.pickup ?? "?") → \(suggested.dropoff ?? "?")",
                    totalFare:(anchor.fare ?? 0)+(suggested.fare ?? 0))
                if let previous=bestBySuggested[suggested.id] {
                    if rec.score>previous.score { bestBySuggested[suggested.id]=rec }
                } else { bestBySuggested[suggested.id]=rec }
            }
        }
        return Array(bestBySuggested.values.sorted{$0.score>$1.score}.prefix(maximumResults))
    }

    private static func evaluate(_ chosen:[Booking],reference:Booking,referencePickup:ResolvedGeoPoint,
                                 referenceDropoff:ResolvedGeoPoint,history:[Booking],centroids:CentroidResolver?,
                                 psgc:PSGCResolver?)->Recommendation? {
        var pickups:[ResolvedGeoPoint]=[],dropoffs:[ResolvedGeoPoint]=[]
        for booking in chosen {
            guard let pickup=resolvedPoint(booking.effectivePickup,centroids:centroids,psgc:psgc),
                  let dropoff=resolvedPoint(booking.effectiveDropoff,centroids:centroids,psgc:psgc) else{return nil}
            pickups.append(pickup); dropoffs.append(dropoff)
        }
        var search=RouteSearch()
        var picked=Array(repeating:false,count:chosen.count),delivered=Array(repeating:false,count:chosen.count)
        searchRoute(chosen,pickups.map(\.point),dropoffs.map(\.point),&picked,&delivered,referenceDropoff.point,0,[],&search)
        guard !search.bestSequence.isEmpty,search.bestDistance.isFinite else{return nil}
        var totalFare=reference.fare ?? 0
        var baseline=0.0,confidence=reference.confidence,compatibility=0.0
        var label="SAME ROUTE"
        var parentFallback=referencePickup.usesParentLocalityFallback || referenceDropoff.usesParentLocalityFallback
        var centroidFallback=referencePickup.usesApproximateCentroidFallback || referenceDropoff.usesApproximateCentroidFallback
        for index in chosen.indices {
            let booking=chosen[index]
            totalFare += booking.fare ?? 0
            confidence += booking.confidence
            baseline += GeoMath.distanceKm(pickups[index].point,dropoffs[index].point)
            let fallback=referencePickup.usesParentLocalityFallback || referenceDropoff.usesParentLocalityFallback ||
                pickups[index].usesParentLocalityFallback || dropoffs[index].usesParentLocalityFallback
            parentFallback = parentFallback || fallback
            centroidFallback = centroidFallback || pickups[index].usesApproximateCentroidFallback || dropoffs[index].usesApproximateCentroidFallback
            let match=RouteCompatibilityEngine.evaluate(referencePickup:referencePickup.point,referenceDropoff:referenceDropoff.point,
                candidatePickup:pickups[index].point,candidateDropoff:dropoffs[index].point,usesParentLocalityFallback:fallback)
            // Do not call a route-compatible recommendation when direction/corridor checks fail.
            // A coarse parent-city fallback may still be useful for display, but it cannot
            // pass this gate unless the resulting geometry is actually feasible.
            guard match.feasible else { return nil }
            compatibility += match.score
            if label == "SAME ROUTE" && match.label != "SAME ROUTE" { label=match.label }
            // Pickup activity signals are intentionally not part of the recommendation score.
        }
        let detour=max(0,search.bestDistance-baseline)
        let avgConfidence=confidence/Double(chosen.count+1)
        let avgCompatibility=compatibility/Double(chosen.count)
        let detourFactor=1/(1+detour/15)
        let incrementalFare=chosen.compactMap{$0.fare}.reduce(0,+)
        // Ranking heuristic only: compare candidate fare against added straight-line
        // geographic deviation. This is not road distance, time, fuel cost or profit.
        let farePerAddedKm = incrementalFare / max(detour, 1.0)
        let fareEfficiencyFactor = min(1.0, max(0.0, farePerAddedKm / 30.0))
        let fareFactor=min(1,incrementalFare/1000)
        var score = avgCompatibility * 0.34 + avgConfidence * 0.20 + detourFactor * 0.22 + fareEfficiencyFactor * 0.19 + fareFactor * 0.05
        // Legacy centroids are approximate. Keep candidates visible, but cap their score
        // until the rider verifies the full addresses.
        if centroidFallback { score = min(score, 0.59) }
        let candidateIDs=chosen.map{$0.id}
        let allIDs=[reference.id]+candidateIDs
        let basis = centroidFallback
            ? "APPROXIMATE LEGACY CENTROID FALLBACK; VERIFY FULL ADDRESSES; NOT ROAD ROUTING"
            : (parentFallback ? RouteCompatibilityEngine.parentFallbackBasis : RouteCompatibilityEngine.basis)
        let routeText=search.bestSequence.joined(separator:" → ")
        let localityNote=parentFallback ? " At least one barangay was resolved only to its parent city; this is a coarse city-level match, not a precise barangay route." : ""
        let referenceNeedsVerification =
            referencePickup.usesApproximateCentroidFallback || referenceDropoff.usesApproximateCentroidFallback ||
            !reference.verifiedPickup || !reference.verifiedDropoff ||
            LocationVerificationManager.isAmbiguousBarePlace(reference.effectivePickup ?? "", psgc: psgc) ||
            LocationVerificationManager.isAmbiguousBarePlace(reference.effectiveDropoff ?? "", psgc: psgc)
        let needsVerification = referenceNeedsVerification || centroidFallback || chosen.contains { booking in
            !booking.verifiedPickup || !booking.verifiedDropoff ||
            LocationVerificationManager.isAmbiguousBarePlace(booking.effectivePickup ?? "", psgc: psgc) ||
            LocationVerificationManager.isAmbiguousBarePlace(booking.effectiveDropoff ?? "", psgc: psgc)
        }
        let verificationPrefix = needsVerification ? "NEEDS ADDRESS VERIFICATION — open the Lalamove offer card and confirm the full pickup and drop-off addresses. " : ""
        let reason=verificationPrefix + "Geographic fit rank: \(Int(avgCompatibility*100))%; OCR confidence: \(Int(avgConfidence*100))%. Candidate fare: PHP \(String(format:"%.2f",incrementalFare)); combined fare: PHP \(String(format:"%.2f",totalFare)). Estimated additional straight-line deviation: \(String(format:"%.1f",detour)) km; candidate fare per added geographic km: PHP \(String(format:"%.2f",farePerAddedKm)). This is a ranking heuristic, not road distance, travel time, fuel cost or guaranteed profit. Confirm full addresses in Lalamove. \(basis).\(localityNote)"
        return Recommendation(id:combinationID(allIDs),anchorBookingID:reference.id,candidateBookingID:candidateIDs[0],
            candidateBookingIDs:candidateIDs,bookingIDs:allIDs,
             label:needsVerification
                ? "POTENTIAL: " + chosen.map { "\($0.pickup ?? "?") → \($0.dropoff ?? "?")" }.joined(separator:" + ")
                : label,
             score:score,reason:reason,
            requiresVerification:needsVerification,lastSeen:chosen.map{$0.lastSeen}.max() ?? reference.lastSeen,
            availability:"LAST_SEEN_NOT_LIVE_AVAILABILITY",basis:basis,sequence:routeText,totalFare:totalFare,
            detourKm:detour,areaActivityScore:0)
    }

    private static func searchRoute(_ bookings:[Booking],_ pickups:[GeoPoint],_ dropoffs:[GeoPoint],
                                    _ picked:inout [Bool],_ delivered:inout [Bool],_ current:GeoPoint,
                                    _ distance:Double,_ sequence:[String],_ search:inout RouteSearch) {
        search.nodes += 1
        if search.nodes>maximumSearchNodes || distance>=search.bestDistance {return}
        var complete=true
        for value in delivered where !value {complete=false;break}
        if complete {search.bestDistance=distance;search.bestSequence=sequence;return}
        for index in bookings.indices {
            if !picked[index] {
                let leg=GeoMath.distanceKm(current,pickups[index])
                if leg.isFinite && leg<=60 {
                    picked[index]=true
                    searchRoute(bookings,pickups,dropoffs,&picked,&delivered,pickups[index],distance+leg,
                                sequence+["PICKUP \(bookings[index].pickup ?? "?")"],&search)
                    picked[index]=false
                }
            } else if !delivered[index] {
                let leg=GeoMath.distanceKm(current,dropoffs[index])
                if leg.isFinite && leg<=80 {
                    delivered[index]=true
                    searchRoute(bookings,pickups,dropoffs,&picked,&delivered,dropoffs[index],distance+leg,
                                sequence+["DROP \(bookings[index].dropoff ?? "?")"],&search)
                    delivered[index]=false
                }
            }
        }
    }

    private static func resolvedPoint(_ name:String?,centroids:CentroidResolver?,psgc:PSGCResolver?)->ResolvedGeoPoint? {
        guard let name,let centroids else{return nil}
        if let psgc {
            switch psgc.resolve(name) {
            case .ambiguous:
                if name.contains(","), case .unique(let addressRecord)=psgc.resolveFromAddress(name),
                   let resolved=localityPoint(for:addressRecord,psgc:psgc,centroids:centroids) {
                    return resolved
                }
                // A short ambiguous locality can use a unique legacy centroid only as a
                // provisional shortlist coordinate; the resulting recommendation is flagged.
                if case .unique(let centroid)=centroids.resolve(name), let point=centroid.point {
                    return ResolvedGeoPoint(point:point,usesParentLocalityFallback:false,
                                             usesApproximateCentroidFallback:true)
                }
                return nil
            case .unique(let record):
                if let resolved=localityPoint(for:record,psgc:psgc,centroids:centroids) {
                    return resolved
                }
            case .notFound:
                if name.contains(","),case .unique(let addressRecord)=psgc.resolveFromAddress(name),
                   let resolved=localityPoint(for:addressRecord,psgc:psgc,centroids:centroids) {
                    return resolved
                }
            }
        }
        guard case .unique(let centroid)=centroids.resolve(name),let point=centroid.point else{return nil}
        return ResolvedGeoPoint(point:point,usesParentLocalityFallback:false,
                                usesApproximateCentroidFallback:true)
    }
    private static func localityPoint(for record:PSGCRecord,psgc:PSGCResolver,centroids:CentroidResolver)->ResolvedGeoPoint? {
        // A province or region is not a destination locality. Never use its parent
        // centroid as if it were a precise drop-off point.
        guard record.level != "Prov", record.level != "Reg" else { return nil }
        // Prefer an exact locality/area centroid when one exists. The previous resolver
        // immediately collapsed every barangay to its parent city, so Commonwealth,
        // Diliman and other distinct areas in Quezon City could receive identical points.
        // Legacy centroids are explicitly approximate and remain verification-gated.
        if record.level != "City" && record.level != "Mun",
           case .unique(let exact)=centroids.resolve(record.name),let point=exact.point {
            return ResolvedGeoPoint(point:point,usesParentLocalityFallback:false,usesApproximateCentroidFallback:true)
        }
        let hierarchy=psgc.hierarchy(record)
        if let locality=hierarchy.first(where:{$0.level == "City" || $0.level == "Mun"}),
           case .unique(let centroid)=centroids.resolve(locality.name),let point=centroid.point {
            return ResolvedGeoPoint(point:point,usesParentLocalityFallback:record.level != "City" && record.level != "Mun",usesApproximateCentroidFallback:true)
        }
        if (record.level == "City" || record.level == "Mun"),case .unique(let centroid)=centroids.resolve(record.name),let point=centroid.point {
            return ResolvedGeoPoint(point:point,usesParentLocalityFallback:false,usesApproximateCentroidFallback:true)
        }
        return nil
    }
    private static func pointAllowingAmbiguous(_ name:String?,centroids:CentroidResolver?,psgc:PSGCResolver?)->GeoPoint? {
        if let safe=resolvedPoint(name,centroids:centroids,psgc:psgc) {return safe.point}
        guard let name,let centroids,case .unique(let record)=centroids.resolve(name) else{return nil}
        return record.point
    }
    private static func pairID(_ a:String,_ b:String)->String { [a,b].sorted().joined(separator:"::") }
    private static func combinationID(_ ids:[String])->String { ids.sorted().joined(separator:"||") }
}
