# RiderWise AI iOS 3.5.0 FIXED13 — booking reconciliation repair

## Source findings from FIXED12

- `BookingMatcher.uniqueMatch` did not reconcile a previously partial record with a later complete record.
- Vehicle and service labels were counted as independent anchors even though many offers share those labels.
- `RiderWiseStore.upsert` only copied incoming OCR fields when the incoming aggregate confidence was at least the stored confidence. This could prevent a lower-confidence frame from filling missing fields.

## Changes

- Matching now works in both directions (partial to complete and complete to partial).
- A match requires two strong shared anchors: booking code, fare, pickup, drop-off, or a very close rider-to-pickup distance paired with a shared endpoint.
- Conflicting shared fare, endpoint, vehicle, or booking-type values reject a candidate.
- Ambiguous matches remain separate rather than merging arbitrarily.
- Vehicle and booking-type labels alone are never sufficient identity evidence.
- Added `BookingReconciler` in RiderWiseCore. It fills missing fields even when the incoming frame has lower aggregate confidence, while only replacing existing values when confidence is at least as high.
- `RiderWiseStore.upsert` now uses the tested core reconciler.

## Regression coverage

Added tests for:
- Partial-to-complete matching in both directions.
- Rejection of generic vehicle/service-only matches.
- Ambiguous candidate rejection.
- Completing a partial record from a lower-confidence observation.
- Two visible Lalamove cards retaining their own route, fare, distance, and customer note.

## Validation

`swift test`: 75 tests passed, 0 failures.
`scripts/verify-portable.sh`: passed.

The Swift package tests run on Linux and validate the portable core. They do not replace an Xcode/iOS device archive or an on-device Lalamove screen-capture test.
