import XCTest
@testable import RiderWiseCore
final class CoreTests:XCTestCase {
    func testBookingFingerprintNormalizesCase() {
        XCTAssertEqual(Booking.fingerprint(pickup:"SAN MATEO",dropoff:"Commonwealth",fare:107,vehicle:"Motorcycle",bookingType:"Delivery"),
                       Booking.fingerprint(pickup:"San Mateo",dropoff:"COMMONWEALTH",fare:107,vehicle:"motorcycle",bookingType:"delivery"))
    }
    func testPickupDistanceNeverUsedAsDeliveryDistance() {
        let b=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,pickupDistanceKm:12.9)
        XCTAssertNil(b.farePerPickupKm)
    }
    func testPartialCardDoesNotBecomeComplete() {
        let lines=[OCRLine(text:"(~12.9 km) Pick Up Now"),OCRLine(text:"San Mateo"),OCRLine(text:"₱107.00"),OCRLine(text:"Motorcycle"),OCRLine(text:"Delivery")]
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count,1)
        XCTAssertEqual(result.bookings[0].status,.partial)
    }
    func testFareExtractionAndPickupDistance() {
        let b=LalamoveOCRParser.parse([OCRLine(text:"(~12.9 km) Pick Up Now"),OCRLine(text:"San Mateo"),OCRLine(text:"Commonwealth"),OCRLine(text:"Motorcycle"),OCRLine(text:"Delivery"),OCRLine(text:"₱107.00")]).bookings[0]
        XCTAssertEqual(b.fare,107)
        XCTAssertEqual(b.pickupDistanceKm,12.9)
    }
    func testExpandedAcceptedBookingKeepsPickupAndDropoffDistinct() {
        let text = [
            "Pick Up At 9:42 AM", "Client: roy vincent", "₱107.00", "Settle with customer",
            "Today, 9:42 AM", "Delivery", "Regular", "Proof of delivery required at drop-off.",
            "Infinite Powertech Warehouse",
            "Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
            "junel 09947563246",
            "544 B,Kamagong Street",
            "Collect Cash",
            "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
            "roy tangcay 09562559874",
            "Motorcycle", "Call Customer"
        ]
        let result = LalamoveOCRParser.parse(text.map { OCRLine(text:$0) })
        XCTAssertEqual(result.screenKind, .accepted)
        XCTAssertEqual(result.bookings.count, 1)
        let booking = try! XCTUnwrap(result.bookings.first)
        XCTAssertTrue(booking.pickup?.contains("1850 San Mateo") == true, "Pickup should retain its full address without repeating the POI.")
        XCTAssertTrue(booking.dropoff?.contains("Kamagong") == true, "Drop-off street must be extracted as a separate endpoint.")
        XCTAssertFalse(booking.pickup?.contains("Kamagong") == true)
        XCTAssertFalse(booking.dropoff?.contains("Infinite Powertech") == true)
        XCTAssertFalse(booking.pickup?.contains("Infinite Powertech Warehouse, Infinite Powertech Warehouse") == true)
    }
    func testCustomerInstructionsAreNotParsedAsEndpoints() {
        let text = ["(~2.5 km) Pick Up Now", "Delivery", "Regular", "San Mateo", "Makati",
                    "Pabili po send ko reseta i need muna", "Small parcel lang papadala", "Motorcycle", "₱211.00"]
        let result = LalamoveOCRParser.parse(text.map { OCRLine(text:$0) })
        XCTAssertEqual(result.bookings.count, 1)
        let booking = try! XCTUnwrap(result.bookings.first)
        XCTAssertEqual(booking.pickup, "San Mateo")
        XCTAssertEqual(booking.dropoff, "Makati")
        XCTAssertTrue(booking.notes?.contains("Pabili po send ko reseta") == true)
    }
    func testNoCoordinatesRequiresVerification() {
        let r=RouteCompatibilityEngine.evaluate(referencePickup:nil,referenceDropoff:nil,candidatePickup:nil,candidateDropoff:nil)
        XCTAssertEqual(r.label,"POSSIBLE COMPATIBILITY")
    }

    func testThreeVisibleCardsKeepPartialThirdSeparate() {
        let text=["(~12.9 km) Pick Up Now","Delivery","Regular","San Mateo","Commonwealth","Motorcycle","₱107.00",
                  "(~4.3 km) Pick Up Now","Delivery","Regular","San Mateo","San Mateo","Motorcycle","2kls talaba ipipick up","₱81.00",
                  "(~5.8 km) Pick Up Now"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.bookings.count,3)
        XCTAssertEqual(result.bookings[0].fare,107)
        XCTAssertEqual(result.bookings[1].fare,81)
        XCTAssertEqual(result.bookings[2].status,.partial)
    }
    func testExpandedScreenKeepsFullAddresses() {
        let text=["Pick Up Now","~6.8 km from you","San Mateo","Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
                  "Commonwealth","544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
                  "Motorcycle","₱107.00","Settle with customer","Report Order"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.expanded)
        XCTAssertTrue(result.bookings.first?.pickupFullAddress?.contains("Infinite Powertech") == true)
        XCTAssertTrue(result.bookings.first?.dropoffFullAddress?.contains("Quezon City") == true)
    }
    func testPSGCResolverKeepsAmbiguousLocalityAmbiguous() throws {
        let url=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let resolver=try PSGCResolver(data:Data(contentsOf:url))
        XCTAssertGreaterThan(resolver.recordCount,20_000)
        if case .ambiguous = resolver.resolve("San Mateo") { } else { XCTFail("San Mateo must remain ambiguous without parent context") }
    }
    func testProfitDoesNotInventFuelCost() {
        let b=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107)
        let p=ProfitCalculator.calculate(bookings:[b],deliveryDistanceKm:nil,durationHours:nil,fuelPricePerLiter:nil,kmPerLiter:nil)
        XCTAssertEqual(p.grossFare,107); XCTAssertNil(p.fuelCost); XCTAssertNil(p.netAfterFuel)
    }
    func testSameLocalityLabelsAreRetainedForFullAddressVerification() {
        let lines=["(~4.3 km) Pick Up Now","Delivery","Regular","San Mateo","San Mateo","Motorcycle","2kls talaba ipipick up","₱81.00"].map{OCRLine(text:$0)}
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count,1)
        XCTAssertTrue(result.bookings[0].isComplete)
        XCTAssertEqual(result.bookings[0].pickup,"San Mateo")
        XCTAssertEqual(result.bookings[0].dropoff,"San Mateo")
        XCTAssertEqual(result.bookings[0].notes,"2kls talaba ipipick up")
        XCTAssertEqual(result.bookings[0].pickupDistanceKm,4.3)
    }

    func testFarePairAndAdditionalFareArePreserved() {
        let pair=LalamoveOCRParser.parseFareComponents("₱100.00 + ₱25.00")
        XCTAssertEqual(pair?.base,100)
        XCTAssertEqual(pair?.additional,25)
        XCTAssertEqual(pair?.total,125)
    }

    func testPesoSignReadAsLetterPStillExtractsFare() {
        // The supplied iPhone screenshots may OCR the peso glyph as a plain P.
        XCTAssertEqual(LalamoveOCRParser.parseFareComponents("P107.00")?.total,107)
        XCTAssertEqual(LalamoveOCRParser.parseFareComponents("P81.00")?.total,81)
        let pair=LalamoveOCRParser.parseFareComponents("P100.00 + P25.00")
        XCTAssertEqual(pair?.total,125)
    }

    func testAcceptedScreenCapturesBookingCodeAndPaymentMethod() {
        let text=["Pick Up At 9:42 AM","# 36333344750352044516","Delivery","Regular",
                  "Infinite Powertech Warehouse","Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
                  "544 B,Kamagong Street","544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
                  "Motorcycle","₱107.00","Collect Cash","Call Customer","Proof of delivery required at dropoff."]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.accepted)
        XCTAssertEqual(result.bookings.first?.status,.accepted)
        XCTAssertEqual(result.bookings.first?.bookingCode,"36333344750352044516")
        XCTAssertEqual(result.bookings.first?.paymentMethod,"Collect cash")
        XCTAssertTrue(result.bookings.first?.pickupFullAddress?.contains("San Mateo") == true)
        XCTAssertTrue(result.bookings.first?.dropoffFullAddress?.contains("Quezon City") == true)
    }

    func testAcceptedScreenWrappedPickupAddressDoesNotBecomeDropoff() {
        let lines = [
            OCRLine(text: "Pick Up At 9:42 AM", x: 0.05, y: 0.94),
            OCRLine(text: "# 36333344750352044516", x: 0.05, y: 0.88),
            OCRLine(text: "Delivery", x: 0.05, y: 0.82),
            OCRLine(text: "Regular", x: 0.25, y: 0.82),
            OCRLine(text: "Infinite Powertech Warehouse", x: 0.08, y: 0.76),
            OCRLine(text: "Infinite Powertech Warehouse, 1850 San", x: 0.08, y: 0.73),
            OCRLine(text: "Mateo, Philippines", x: 0.08, y: 0.70),
            OCRLine(text: "junel 09947563246", x: 0.08, y: 0.66),
            OCRLine(text: "544 B, Kamagong Street", x: 0.08, y: 0.56),
            OCRLine(text: "Collect Cash", x: 0.08, y: 0.50),
            OCRLine(text: "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines", x: 0.08, y: 0.46),
            OCRLine(text: "roy tangcay 09562559874", x: 0.08, y: 0.40),
            OCRLine(text: "Motorcycle", x: 0.08, y: 0.30),
            OCRLine(text: "₱107.00", x: 0.08, y: 0.22),
            OCRLine(text: "Call Customer", x: 0.08, y: 0.14),
            OCRLine(text: "Proof of delivery required at dropoff.", x: 0.08, y: 0.08)
        ]
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.screenKind, .accepted)
        XCTAssertEqual(result.bookings.count, 1)
        XCTAssertTrue(result.bookings[0].pickupFullAddress?.contains("San Mateo") == true)
        XCTAssertTrue(result.bookings[0].dropoffFullAddress?.contains("Quezon City") == true)
        XCTAssertFalse(result.bookings[0].dropoffFullAddress?.contains("Mateo, Philippines") == true)
        let accepted = AcceptedBookingDetector.detect(lines: lines)
        XCTAssertNotNil(accepted)
        XCTAssertTrue(accepted?.booking.effectivePickup?.contains("San Mateo") == true)
        XCTAssertTrue(accepted?.booking.effectiveDropoff?.contains("Quezon City") == true)
    }

    func testAcceptedScreenRejectsRideAndPhotosAsEndpointLabels() {
        let text = [
            "Pick Up At 9:42 AM", "# 36333344750352044516", "Client: Roy Vincent",
            "Ride", "Photos", "Motorcycle", "₱107.00", "Collect Cash",
            "Call Customer", "Proof of delivery required at dropoff."
        ]
        let result = LalamoveOCRParser.parse(text.map { OCRLine(text: $0) })
        XCTAssertEqual(result.screenKind, .accepted)
        XCTAssertFalse(result.bookings.contains { $0.isComplete })
        XCTAssertFalse(result.bookings.contains { $0.pickup == "Ride" || $0.dropoff == "Photos" })
    }

    func testPostalCodeRegionWrappedLineStaysWithDropoffAddress() {
        let lines = [
            OCRLine(text: "Pick Up At 9:42 AM", x: 0.05, y: 0.94),
            OCRLine(text: "# 36333344750352044516", x: 0.05, y: 0.88),
            OCRLine(text: "Client: Roy Vincent", x: 0.05, y: 0.82),
            OCRLine(text: "Infinite Powertech Warehouse, 1850 San Mateo, Philippines", x: 0.08, y: 0.72),
            OCRLine(text: "544 B Kamagong St, Quezon", x: 0.08, y: 0.52),
            OCRLine(text: "1121 Metro Manila, Philippines", x: 0.08, y: 0.49),
            OCRLine(text: "Motorcycle", x: 0.08, y: 0.30),
            OCRLine(text: "₱107.00", x: 0.08, y: 0.22),
            OCRLine(text: "Collect Cash", x: 0.08, y: 0.18),
            OCRLine(text: "Call Customer", x: 0.08, y: 0.12),
            OCRLine(text: "Proof of delivery required at dropoff.", x: 0.08, y: 0.08)
        ]
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.screenKind, .accepted)
        XCTAssertEqual(result.bookings.count, 1)
        XCTAssertTrue(result.bookings[0].dropoffFullAddress?.contains("Quezon 1121 Metro Manila") == true)
        XCTAssertFalse(result.bookings[0].pickupFullAddress?.contains("1121 Metro Manila") == true)
    }

    func testLegacyUnreferencedAcceptedFragmentWithoutOrderNumberIsDemoted() {
        var falseAccepted = Booking(
            id:"legacy-false", pickup:"LIVE OCR", dropoff:"Satur RIDER WISE AI", fare:110,
            status:.accepted, screenKind:.accepted
        )
        var genuineAccepted = Booking(
            id:"genuine", bookingCode:"36333344750352044516",
            pickup:"Infinite Powertech Warehouse", dropoff:"544 B Kamagong Street",
            fare:107, status:.accepted, screenKind:.accepted
        )
        var history = [falseAccepted, genuineAccepted]
        AcceptedBookingReferenceRecovery.demoteUnreferencedAcceptedWithoutBookingCode(
            &history, protectedReferenceID:nil
        )
        XCTAssertEqual(history[0].status, .needsVerification)
        XCTAssertEqual(history[1].status, .accepted)

        falseAccepted.status = .accepted
        var explicitlySelected = [falseAccepted]
        AcceptedBookingReferenceRecovery.demoteUnreferencedAcceptedWithoutBookingCode(
            &explicitlySelected, protectedReferenceID:"legacy-false"
        )
        XCTAssertEqual(explicitlySelected[0].status, .accepted)
    }

    func testPersistedAcceptedHistoryRecoversFirstAcceptedReference() {
        let earlier = Booking(id: "accepted-earlier", pickup: "San Mateo", dropoff: "Quezon Ave", fare: 107,
                              status: .accepted, firstSeen: Date(timeIntervalSince1970: 100))
        let later = Booking(id: "accepted-later", pickup: "Batasan", dropoff: "Matandang Balara", fare: 120,
                            status: .accepted, firstSeen: Date(timeIntervalSince1970: 200))
        let recovered = AcceptedBookingReferenceRecovery.recover(
            bookings: [later, earlier], selectedReferenceID: nil, referenceSnapshot: nil,
            explicitlyCleared: false
        )
        XCTAssertEqual(recovered.referenceID, earlier.id)
        XCTAssertEqual(recovered.snapshot?.id, earlier.id)
    }

    func testPersistedReferenceRecoveryRespectsExplicitClear() {
        let accepted = Booking(id: "accepted", pickup: "San Mateo", dropoff: "Quezon Ave", fare: 107,
                               status: .accepted)
        let recovered = AcceptedBookingReferenceRecovery.recover(
            bookings: [accepted], selectedReferenceID: nil, referenceSnapshot: accepted,
            explicitlyCleared: true
        )
        XCTAssertNil(recovered.referenceID)
        XCTAssertNil(recovered.snapshot)
    }

    func testExpandedBookingMatchesCollapsedCardOnlyWhenUnique() {
        let collapsed=Booking(bookingCode:nil,pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",confidence:0.9,status:.detected)
        let expanded=Booking(pickup:"Infinite Powertech Warehouse, 1850 San Mateo, Philippines",dropoff:"Commonwealth, 544 B Kamagong St, Quezon City",fare:107,vehicleType:"Motorcycle",confidence:0.9,status:.needsVerification,screenKind:.expanded)
        XCTAssertEqual(BookingMatcher.uniqueMatch(for:expanded,among:[collapsed]),0)
        XCTAssertNil(BookingMatcher.uniqueMatch(for:expanded,among:[collapsed,collapsed]))
    }

    func testLegacyCentroidDatasetIsExplicitlyApproximate() throws {
        let url=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let resolver=try CentroidResolver(data:Data(contentsOf:url))
        XCTAssertGreaterThan(resolver.recordCount,50)
        guard case .unique(let commonwealth)=resolver.resolve("Commonwealth") else { return XCTFail("Expected one Commonwealth centroid") }
        XCTAssertEqual(commonwealth.coordinateStatus,"APPROXIMATE_CENTROID")
        XCTAssertNotNil(commonwealth.point)
    }

    func testThirtyVisibleCardsAreSegmentedIndependently() {
        var lines:[OCRLine]=[]
        for i in 0..<30 {
            lines += [OCRLine(text:"(~2.5 km) Pick Up Now"),OCRLine(text:"Delivery"),OCRLine(text:"Regular"),
                      OCRLine(text:"San Mateo"),OCRLine(text:"Commonwealth"),OCRLine(text:"Motorcycle"),OCRLine(text:"₱\(100+i).00")]
        }
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count,30)
        XCTAssertTrue(result.bookings.allSatisfy{$0.isComplete})
    }

    func testPSGCAddressContextDisambiguatesSanMateoRizal() throws {
        let url=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let resolver=try PSGCResolver(data:Data(contentsOf:url))
        guard case .unique(let record)=resolver.resolveFromAddress("San Mateo, Rizal, Philippines") else { return XCTFail("Province context should narrow the locality") }
        XCTAssertEqual(record.level,"Mun")
        XCTAssertEqual(resolver.hierarchy(record).first(where:{$0.level == "Prov"})?.name,"Rizal")
    }

    func testApproximateRouteMatchNeverClaimsVerifiedRoadCompatibility() {
        let result=RouteCompatibilityEngine.evaluate(
            referencePickup:GeoPoint(latitude:14.6982,longitude:121.1236),
            referenceDropoff:GeoPoint(latitude:14.6910,longitude:121.0830),
            candidatePickup:GeoPoint(latitude:14.6917,longitude:121.0950),
            candidateDropoff:GeoPoint(latitude:14.6426,longitude:121.0380))
        XCTAssertTrue(result.requiresVerification)
        XCTAssertTrue(result.basis.contains("NOT ROAD ROUTING"))
    }



    func testAmbiguousSanMateoUsesFlaggedCentroidFallbackForReferenceRecommendations() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let reference=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let pasig=Booking(pickup:"San Mateo",dropoff:"Pasig",fare:145,vehicleType:"Motorcycle")
        let antipolo=Booking(pickup:"San Mateo",dropoff:"Antipolo",fare:156,vehicleType:"Motorcycle")
        let recs=RecommendationEngine.referenceBased(reference:reference,candidates:[pasig,antipolo],centroids:centroids,psgc:psgc)
        XCTAssertFalse(recs.isEmpty, "A unique legacy San Mateo centroid should permit a provisional shortlist.")
        XCTAssertTrue(recs.allSatisfy{$0.requiresVerification}, "Ambiguous locality fallback must always require address verification.")
        XCTAssertTrue(recs.allSatisfy{$0.score <= 0.59}, "Approximate centroid matches must have a capped score.")
        XCTAssertTrue(recs.allSatisfy{$0.basis.contains("APPROXIMATE LEGACY CENTROID")})
        XCTAssertTrue(recs.allSatisfy{$0.candidateBookingIDs.contains(antipolo.id)})
        XCTAssertFalse(recs.contains{$0.candidateBookingIDs.contains(pasig.id)}, "Pasig must not pass the route-corridor check for this reference.")
    }

    func testReferenceFreeSimilarRoutesAreSurfacedWithAmbiguityWarning() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let a=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",firstSeen:Date(timeIntervalSince1970:1))
        let b=Booking(pickup:"San Mateo",dropoff:"Quezon Avenue",fare:120,vehicleType:"Motorcycle",firstSeen:Date(timeIntervalSince1970:2))
        let recs=RecommendationEngine.referenceFree(bookings:[a,b],centroids:centroids,psgc:psgc)
        XCTAssertEqual(recs.count,1)
        XCTAssertTrue(recs[0].requiresVerification)
        XCTAssertTrue(recs[0].label.contains("San Mateo") && recs[0].label.contains("→"), "Potential recommendations must identify the actual candidate route.")
        XCTAssertTrue(recs[0].basis.contains("NOT ROAD ROUTING"))
        XCTAssertLessThanOrEqual(recs[0].score,0.59, "Legacy centroid comparisons must remain capped until full-address verification and better coordinates are available.")
    }

    func testReferenceBasedEngineCanRecommendMultipleBookingCombination() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let ref=Booking(pickup:"Quezon City",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let one=Booking(pickup:"Commonwealth",dropoff:"Quezon Avenue",fare:120,vehicleType:"Motorcycle",status:.notVisible)
        let two=Booking(pickup:"Quezon Avenue",dropoff:"Diliman",fare:130,vehicleType:"Motorcycle",status:.detected)
        let recs=RecommendationEngine.referenceBased(reference:ref,candidates:[one,two],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.contains{$0.candidateBookingIDs.count==2})
        XCTAssertTrue(recs.contains{$0.candidateBookingIDs == [one.id]})
        XCTAssertTrue(recs.contains{$0.candidateBookingIDs == [two.id]})
        XCTAssertTrue(recs.allSatisfy{$0.requiresVerification}, "OCR-derived pickup/drop-off addresses must be confirmed by the driver.")
    }

    func testReferenceBasedEngineRejectsKnownVehicleMismatch() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let ref=Booking(pickup:"Quezon City",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let car=Booking(pickup:"Commonwealth",dropoff:"Quezon Avenue",fare:120,vehicleType:"Car")
        let recs=RecommendationEngine.referenceBased(reference:ref,candidates:[car],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.isEmpty)
    }

    func testProvidedIPhoneAvailableBookingScreenshotLayout() {
        let text=["Home Along the way Above 50 km",
            "(~12.9 km) Pick Up Now","Delivery","Regular","San Mateo","Commonwealth","Motorcycle","₱107.00",
            "(~4.3 km) Pick Up Now","Delivery","Regular","San Mateo","San Mateo","Motorcycle","2kls talaba ipipick up","₱81.00",
            "(~5.8 km) Pick Up Now","Find more orders at these locations"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.list)
        XCTAssertEqual(result.bookings.count,3)
        XCTAssertEqual(result.bookings[0].pickupDistanceKm,12.9)
        XCTAssertEqual(result.bookings[0].fare,107)
        XCTAssertEqual(result.bookings[1].notes,"2kls talaba ipipick up")
        XCTAssertEqual(result.bookings[1].pickup,result.bookings[1].dropoff)
        XCTAssertEqual(result.bookings[2].status,.partial)
    }

    func testProvidedIPhoneExpandedBookingScreenshotLayout() {
        let text=["Pick Up Now","~6.8 km from you","San Mateo",
            "Infinite Powertech Warehouse, 1850 San Mateo, Philippines","Commonwealth",
            "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines","Motorcycle","₱107.00",
            "Settle with customer","Does this order look suspicious?","Report Order","Slide to Take Order"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.expanded)
        XCTAssertEqual(result.bookings.first?.pickupDistanceKm,6.8)
        XCTAssertEqual(result.bookings.first?.fare,107)
        XCTAssertTrue(result.bookings.first?.pickupFullAddress?.contains("Infinite Powertech") == true)
        XCTAssertTrue(result.bookings.first?.dropoffFullAddress?.contains("Quezon City") == true)
        XCTAssertNil(result.bookings.first?.notes)
    }

    func testAcceptedLalamoveScreenIsRecognizedEvenWhenRiderWisePiPIsPresent() {
        let lines = [
            OCRLine(text:"Pick Up At 9:42 AM"),
            OCRLine(text:"Proof of delivery required at dropoff."),
            OCRLine(text:"Settle with customer"),
            OCRLine(text:"Infinite Powertech Warehouse"),
            OCRLine(text:"544 B, Kamagong Street"),
            OCRLine(text:"RIDERWISE AI", x:0.70, y:0.12, width:0.18, height:0.02),
            OCRLine(text:"TOP RECOMMENDATION", x:0.72, y:0.08, width:0.20, height:0.02)
        ]
        XCTAssertTrue(LalamoveOCRParser.hasLalamoveScreenEvidence(lines))
    }

    func testSplitRiderWisePiPTitleAndLiveOCRTextAreRemovedFromAcceptedScreen() {
        let lines = [
            OCRLine(text:"Pick Up At 9:42 AM", x:0.05, y:0.92),
            OCRLine(text:"# 36333344750352044516", x:0.05, y:0.86),
            OCRLine(text:"Client: Roy Vincent", x:0.05, y:0.80),
            OCRLine(text:"Delivery", x:0.05, y:0.75),
            OCRLine(text:"Regular", x:0.25, y:0.75),
            OCRLine(text:"Infinite Powertech Warehouse", x:0.08, y:0.68),
            OCRLine(text:"Infinite Powertech Warehouse, 1850 San Mateo, Philippines", x:0.08, y:0.64),
            OCRLine(text:"544 B, Kamagong Street", x:0.08, y:0.48),
            OCRLine(text:"544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines", x:0.08, y:0.44),
            OCRLine(text:"Motorcycle", x:0.08, y:0.30),
            OCRLine(text:"₱107.00", x:0.08, y:0.25),
            OCRLine(text:"Collect Cash", x:0.08, y:0.20),
            OCRLine(text:"Call Customer", x:0.08, y:0.08),
            OCRLine(text:"Proof of delivery required at dropoff.", x:0.08, y:0.12),
            OCRLine(text:"RIDER WISE AI", x:0.70, y:0.14, width:0.20, height:0.02),
            OCRLine(text:"LIVE OCR → Satur RIDER WISE AI", x:0.58, y:0.10, width:0.38, height:0.03),
            OCRLine(text:"ACCEPTED REFERENCE", x:0.60, y:0.08, width:0.30, height:0.02),
            OCRLine(text:"No accepted booking selected", x:0.60, y:0.05, width:0.35, height:0.02)
        ]
        let cleaned = LalamoveOCRParser.removeRiderWiseOverlay(from: lines)
        XCTAssertFalse(cleaned.contains { TextNormalization.normalize($0.text).contains("rider wise ai") })
        XCTAssertFalse(cleaned.contains { TextNormalization.normalize($0.text).contains("live ocr") })
        XCTAssertTrue(LalamoveOCRParser.hasLalamoveScreenEvidence(lines))
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count, 1)
        XCTAssertTrue(result.bookings.first?.pickup?.contains("Infinite Powertech Warehouse") == true)
        XCTAssertTrue(result.bookings.first?.pickup?.contains("1850 San Mateo") == true)
        XCTAssertTrue(result.bookings.first?.dropoff?.contains("Kamagong") == true)
        XCTAssertEqual(result.bookings.first?.fare, 107)
        XCTAssertEqual(result.bookings.first?.bookingCode, "36333344750352044516")
    }

    func testAcceptedScreenWithoutReadableBookingCodeCannotAutoPromoteReference() {
        let lines = [
            "Pick Up At 9:42 AM", "Client: Roy Vincent", "₱107.00", "Today, 9:42 AM",
            "Delivery", "Regular", "Proof of delivery required at dropoff",
            "Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
            "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
            "Motorcycle", "Collect Cash", "Call Customer"
        ].map { OCRLine(text:$0) }
        let parsed = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(parsed.screenKind, .accepted)
        XCTAssertEqual(parsed.bookings.first?.status, .needsVerification)
        XCTAssertNil(AcceptedBookingDetector.detect(lines: lines))
    }

    func testFirstNewAcceptedBookingCanBeSelectedAfterClearWithNoPriorReference() {
        XCTAssertEqual(
            AcceptedBookingReferenceSelection.firstEligible(
                acceptedIDs:["newly-accepted"], currentReferenceID:nil, explicitlyClearedID:nil
            ),
            "newly-accepted"
        )
    }

    func testRiderWiseDashboardCardsWithPickUpNowAreNotLalamoveEvidence() {
        let lines = [
            OCRLine(text:"RIDERWISE AI", x:0.40, y:0.96, width:0.20, height:0.02),
            OCRLine(text:"Profit estimate"),
            OCRLine(text:"Net after fuel"),
            OCRLine(text:"Detected bookings"),
            OCRLine(text:"Newest first"),
            OCRLine(text:"Veri → incomplete → Drop-off incomplete"),
            OCRLine(text:"(~600 m) Pick Up Now"),
            OCRLine(text:"Verify addresses Confirm accepted"),
            OCRLine(text:"Car")
        ]
        XCTAssertFalse(LalamoveOCRParser.hasLalamoveScreenEvidence(lines))
    }

    func testFullScreenRiderWiseDashboardIsRejectedEvenWhenCardsContainPickUpNow() {
        let lines = [
            OCRLine(text:"RIDERWISE AI", x:0.38, y:0.96, width:0.24, height:0.02),
            OCRLine(text:"Detected bookings", x:0.04, y:0.90, width:0.35, height:0.02),
            OCRLine(text:"Commonwealth → Pasong Tamo"),
            OCRLine(text:"(~4 km) Pick Up Now"),
            OCRLine(text:"Delivery"), OCRLine(text:"Motorcycle"), OCRLine(text:"₱63.00"),
            OCRLine(text:"Verify addresses Confirm accepted")
        ]
        XCTAssertFalse(LalamoveOCRParser.hasLalamoveScreenEvidence(lines))
    }

    func testUILabelsAndVehicleOCRNoiseCannotBecomeEndpoints() {
        let lines = [
            OCRLine(text:"(~4 km) Pick Up Now"), OCRLine(text:"Delivery"),
            OCRLine(text:"Priority"), OCRLine(text:"Gulod"),
            OCRLine(text:"Motorcycia"), OCRLine(text:"On Duty"), OCRLine(text:"₱120.00")
        ]
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count, 1)
        XCTAssertEqual(result.bookings[0].pickup, "Gulod")
        XCTAssertNil(result.bookings[0].dropoff)
    }

    func testRiderWiseInstructionFragmentCannotBecomeLocation() {
        let lines = [
            OCRLine(text:"(~4 km) Pick Up Now"), OCRLine(text:"Delivery"),
            OCRLine(text:"Priority"), OCRLine(text:"San Mateo"),
            OCRLine(text:"No compatible booking yet, accepted reference is incomplete. Confirm its pickup, drop-off and fare."),
            OCRLine(text:"Motorcycle"), OCRLine(text:"₱120.00")
        ]
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count, 1)
        XCTAssertEqual(result.bookings[0].pickup, "San Mateo")
        XCTAssertNil(result.bookings[0].dropoff)
    }

    func testLalamoveOfferCardRequiresIndependentCardFields() {
        let realCard = [
            OCRLine(text:"(~4 km) Pick Up Now"),
            OCRLine(text:"Delivery"),
            OCRLine(text:"Priority"),
            OCRLine(text:"San Mateo"),
            OCRLine(text:"Santa Maria"),
            OCRLine(text:"Motorcycle"),
            OCRLine(text:"₱348.00")
        ]
        XCTAssertTrue(LalamoveOCRParser.hasLalamoveScreenEvidence(realCard))
        XCTAssertFalse(LalamoveOCRParser.hasLalamoveScreenEvidence([
            OCRLine(text:"(~600 m) Pick Up Now"),
            OCRLine(text:"Car")
        ]))
    }

    func testRiderWiseDashboardAloneIsNotRecognizedAsLalamove() {
        let lines = [
            OCRLine(text:"RIDERWISE AI", x:0.70, y:0.12, width:0.18, height:0.02),
            OCRLine(text:"ACCEPTED REFERENCE", x:0.72, y:0.10, width:0.20, height:0.02),
            OCRLine(text:"TOP RECOMMENDATION", x:0.72, y:0.08, width:0.20, height:0.02)
        ]
        XCTAssertFalse(LalamoveOCRParser.hasLalamoveScreenEvidence(lines))
    }

    func testAcceptedBookingDetectedFromActualIPhoneAcceptedScreenMarkers() {
        let lines = [
            "Pick Up At 9:42 AM", "Client: Roy Vincent", "₱107.00", "Today, 9:42 AM",
            "# 36333344750352044516", "Delivery", "Regular", "Proof of delivery required at dropoff",
            "Infinite Powertech Warehouse", "Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
            "544 B, Kamagong Street", "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
            "Motorcycle", "Collect Cash", "Call Customer"
        ].map { OCRLine(text: $0) }
        let result = AcceptedBookingDetector.detect(lines: lines)
        XCTAssertNotNil(result)
        XCTAssertEqual(result?.booking.status, .accepted)
        XCTAssertEqual(result?.bookingCode, "36333344750352044516")
        XCTAssertEqual(result?.booking.fare, 107)
        XCTAssertTrue(result?.evidence.contains("POST_ACCEPTANCE_PICKUP_TIME") == true)
    }

    func testOrdinaryAvailableBookingCardCannotBeMistakenAsAccepted() {
        let lines = ["(~12.9 km) Pick Up Now", "Delivery", "Regular", "San Mateo", "Commonwealth", "Motorcycle", "₱107.00"].map { OCRLine(text: $0) }
        XCTAssertNil(AcceptedBookingDetector.detect(lines: lines))
    }

    func testSingleAcceptedMarkerDoesNotPromoteOfferToAccepted() {
        let lines = [
            "Booking #123456789", "Pick Up At 9:42 AM", "Call Customer",
            "San Mateo, Rizal", "Commonwealth, Quezon City", "₱107.00", "Motorcycle"
        ].map { OCRLine(text: $0) }
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.screenKind, .list)
        XCTAssertNotEqual(result.bookings.first?.status, .accepted)
    }

    func testFirstAcceptedBookingIsProtectedUntilExplicitReplacementOrClear() async throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let store = AcceptedBookingReferenceStore(fileURL: dir.appendingPathComponent("reference.json"))
        let first = Booking(bookingCode: "ORDER-000001", pickup: "San Mateo, Rizal", dropoff: "Commonwealth", fare: 107, status: .accepted, screenKind: .accepted)
        let second = Booking(bookingCode: "ORDER-000002", pickup: "San Mateo, Rizal", dropoff: "Quezon Avenue", fare: 120, status: .accepted, screenKind: .accepted)
        let d1 = AcceptedBookingDetection(booking: first, bookingCode: first.bookingCode, matchedPreAcceptanceBookingID: nil, confidence: 0.95, evidence: ["test"])
        let d2 = AcceptedBookingDetection(booking: second, bookingCode: second.bookingCode, matchedPreAcceptanceBookingID: nil, confidence: 0.95, evidence: ["test"])
        let acceptedFirst = try await store.recordFirstAccepted(d1)
        let acceptedSecond = try await store.recordFirstAccepted(d2)
        XCTAssertTrue(acceptedFirst)
        XCTAssertFalse(acceptedSecond)
        let protectedReference = await store.current()
        XCTAssertEqual(protectedReference?.bookingCode, "ORDER-000001")
        try await store.replace(with: second)
        let replacedReference = await store.current()
        XCTAssertEqual(replacedReference?.bookingCode, "ORDER-000002")
        try await store.clear()
        let clearedReference = await store.current()
        XCTAssertNil(clearedReference)
        try? FileManager.default.removeItem(at: dir)
    }

    func testBookingHistoryPolicyKeepsSevenDaysAndCapsAt1500() {
        let now=Date(timeIntervalSince1970:1_000_000)
        let recent=(0..<1520).map { index in
            Booking(id:"b\(index)",pickup:"A\(index)",dropoff:"B\(index)",fare:100,
                    firstSeen:now.addingTimeInterval(-Double(index)),lastSeen:now.addingTimeInterval(-Double(index)))
        }
        let old=Booking(id:"old",pickup:"Old",dropoff:"History",fare:100,
                        firstSeen:now.addingTimeInterval(-8*24*3600),lastSeen:now.addingTimeInterval(-8*24*3600))
        let pruned=BookingHistoryPolicy.prune(recent+[old],now:now)
        XCTAssertEqual(pruned.count,1500)
        XCTAssertFalse(pruned.contains{$0.id=="old"})
        XCTAssertEqual(pruned.first?.id,"b0")
    }


    func testActualIPhoneHomeScreenOCRTextFromProvidedScreenshot() {
        // OCR text transcribed from IMG_2256(1).png using local Tesseract.
        let text = [
            "On Duty", "Home", "Along the way", "Above 50 km",
            "(~12.9 km) Pick Up Now", "Delivery", "Regular", "San Mateo",
            "Commonwealth", "Motorcycle", "P107.00",
            "(~4.3 km) Pick Up Now", "Delivery", "Regular", "San Mateo",
            "San Mateo", "Motorcycle", "2kls talaba ipipick up", "P81.00",
            "(~5.8 km) Pick Up Now", "Find more orders at these locations"
        ]
        let result = LalamoveOCRParser.parse(text.map { OCRLine(text: $0) })
        XCTAssertEqual(result.screenKind, .list)
        XCTAssertEqual(result.bookings.count, 3)
        let first = result.bookings[0]
        XCTAssertEqual(first.pickup, "San Mateo")
        XCTAssertEqual(first.dropoff, "Commonwealth")
        XCTAssertEqual(first.pickupDistanceKm, 12.9)
        XCTAssertEqual(first.fare, 107)
        XCTAssertEqual(first.vehicleType, "Motorcycle")
        XCTAssertEqual(first.bookingType, "Delivery · Regular")
        let second = result.bookings[1]
        XCTAssertEqual(second.pickup, "San Mateo")
        XCTAssertEqual(second.dropoff, "San Mateo")
        XCTAssertEqual(second.fare, 81)
        XCTAssertEqual(second.notes, "2kls talaba ipipick up")
        XCTAssertEqual(second.vehicleType, "Motorcycle")
        XCTAssertEqual(result.bookings[2].status, .partial)
    }

    func testActualIPhoneExpandedOfferOCRTextFromProvidedScreenshot() {
        // OCR text transcribed from IMG_2257(1).png using local Tesseract.
        let text = [
            "Pick Up Now", "~6.8 km from you", "Delivery", "Regular",
            "San Mateo", "Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
            "Commonwealth", "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
            "Motorcycle", "P107.00", "Settle with customer",
            "Does this order look suspicious?", "Report Order", "Slide to Take Order"
        ]
        let result = LalamoveOCRParser.parse(text.map { OCRLine(text: $0) })
        XCTAssertEqual(result.screenKind, .expanded)
        XCTAssertEqual(result.bookings.count, 1)
        let booking = try! XCTUnwrap(result.bookings.first)
        XCTAssertEqual(booking.pickup, "Infinite Powertech Warehouse, 1850 San Mateo, Philippines")
        XCTAssertEqual(booking.dropoff, "Commonwealth, 544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines")
        XCTAssertEqual(booking.pickupDistanceKm, 6.8)
        XCTAssertEqual(booking.fare, 107)
        XCTAssertEqual(booking.vehicleType, "Motorcycle")
        XCTAssertEqual(booking.bookingType, "Delivery · Regular")
        XCTAssertEqual(booking.paymentMethod, "Settle with customer")
        XCTAssertEqual(booking.status, .needsVerification)
    }

    func testActualIPhoneAcceptedBookingOCRTextFromProvidedScreenshot() {
        // OCR text transcribed from IMG_2258(1).png using local Tesseract.
        let text = [
            "Pick Up At 9:42 AM", "Client: roy vincent", "P107.00",
            "Settle with customer", "Today, 9:42 AM", "# 3633344750352044516",
            "Delivery", "Regular", "Proof of delivery required at dropoff.",
            "Infinite Powertech Warehouse",
            "Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
            "junel 09947563246", "544 B,Kamagong Street", "Collect Cash",
            "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
            "roy tangcay 09562559874", "Motorcycle",
            "Confirm any additional expenses with the customer", "Call Customer"
        ]
        let result = LalamoveOCRParser.parse(text.map { OCRLine(text: $0) })
        XCTAssertEqual(result.screenKind, .accepted)
        XCTAssertEqual(result.bookings.count, 1)
        let booking = try! XCTUnwrap(result.bookings.first)
        XCTAssertEqual(booking.status, .accepted)
        XCTAssertEqual(booking.bookingCode, "3633344750352044516")
        XCTAssertEqual(booking.fare, 107)
        XCTAssertEqual(booking.vehicleType, "Motorcycle")
        XCTAssertEqual(booking.bookingType, "Delivery · Regular")
        XCTAssertEqual(booking.paymentMethod, "Collect cash")
        XCTAssertTrue(booking.pickupFullAddress?.contains("1850 San Mateo") == true)
        XCTAssertTrue(booking.dropoffFullAddress?.contains("Quezon City") == true)
    }

    func testAlongTheWayTabLabelDoesNotArtificiallyCreateCompatibility() {
        // Tab membership is not a routing verdict; compatibility is independently calculated.
        let lines = [
            "Along the way", "(~12.9 km) Pick Up Now", "Delivery", "Regular",
            "San Mateo", "Commonwealth", "Motorcycle", "P107.00"
        ].map { OCRLine(text: $0) }
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count, 1)
        XCTAssertEqual(result.bookings[0].pickup, "San Mateo")
        XCTAssertEqual(result.bookings[0].dropoff, "Commonwealth")
        XCTAssertFalse(result.bookings[0].sourceEvidence.contains("Along the way"))
    }


    func testRecommendationLearningUsesOnlyExplicitFeedbackAndIsBounded() {
        let booking = Booking(pickup:"San Mateo, Rizal",dropoff:"Commonwealth, Quezon City",
                              fare:107,vehicleType:"Motorcycle",bookingType:"Delivery")
        let key = RecommendationLearning.patternKey(for: booking)
        XCTAssertEqual(RecommendationLearning.adjustment(for:key,feedback:[]),0)
        let accepted = (0..<20).map { _ in RecommendationFeedback(patternKey:key,outcome:.accepted) }
        let rejected = (0..<20).map { _ in RecommendationFeedback(patternKey:key,outcome:.rejectedAsUnsuitable) }
        XCTAssertLessThanOrEqual(RecommendationLearning.adjustment(for:key,feedback:accepted),0.12)
        XCTAssertGreaterThanOrEqual(RecommendationLearning.adjustment(for:key,feedback:rejected),-0.12)
        XCTAssertGreaterThan(RecommendationLearning.adjustment(for:key,feedback:accepted),
                             RecommendationLearning.adjustment(for:key,feedback:rejected))
    }

    func testRecommendationLearningIgnoresUnrelatedRoutePatterns() {
        let booking = Booking(pickup:"San Mateo, Rizal",dropoff:"Commonwealth, Quezon City",
                              vehicleType:"Motorcycle",bookingType:"Delivery")
        let other = Booking(pickup:"Makati",dropoff:"Pasig",vehicleType:"Motorcycle",bookingType:"Delivery")
        let feedback = [RecommendationFeedback(patternKey:RecommendationLearning.patternKey(for:other),outcome:.rejectedAsUnsuitable)]
        XCTAssertEqual(RecommendationLearning.adjustment(for:RecommendationLearning.patternKey(for:booking),feedback:feedback),0)
    }


    func testBarangayExactCentroidIsPreferredToParentCityFallback() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let commonwealth=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let antipolo=Booking(pickup:"San Mateo",dropoff:"Antipolo",fare:156,vehicleType:"Motorcycle")
        let recs=RecommendationEngine.referenceBased(reference:commonwealth,candidates:[antipolo],centroids:centroids,psgc:psgc)
        XCTAssertFalse(recs.isEmpty, "Exact Commonwealth area centroid should not be collapsed to Quezon City centroid.")
        XCTAssertTrue(recs.allSatisfy{$0.requiresVerification})
        XCTAssertTrue(recs.allSatisfy{$0.score <= 0.59})
    }

    func testReferenceBasedEngineDoesNotRecommendInfeasiblePasigDetour() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let reference=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let pasig=Booking(pickup:"San Mateo",dropoff:"Pasig",fare:145,vehicleType:"Motorcycle")
        let recs=RecommendationEngine.referenceBased(reference:reference,candidates:[pasig],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.isEmpty, "Pasig is outside the current reference route corridor and must not be labelled compatible.")
        let reason=RecommendationEngine.explainEmptyReferenceBased(reference:reference,candidates:[pasig],centroids:centroids,psgc:psgc)
        XCTAssertTrue(reason.contains("No route-compatible recommendation"))
        XCTAssertTrue(reason.contains("NOT ROUTE-COMPATIBLE"))
    }


    func testScheduledBookingHeaderIsSegmentedAsItsOwnCard() {
        let lines=["Today, 6:30 PM","Delivery","Regular","San Mateo","Binangonan","Motorcycle","₱239.00"].map{OCRLine(text:$0)}
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.screenKind,.list)
        XCTAssertEqual(result.bookings.count,1)
        XCTAssertEqual(result.bookings.first?.pickup,"San Mateo")
        XCTAssertEqual(result.bookings.first?.dropoff,"Binangonan")
        XCTAssertEqual(result.bookings.first?.fare,239)
    }

    func testLeadingOFromOCRIsNotKeptAsPartOfPickupLocality() {
        let lines=["(~10.2 km) Pick Up Now","Delivery","Regular","O Bagong Silangan","San Francisco del Monte","Motorcycle","₱115.00"].map{OCRLine(text:$0)}
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.first?.pickup,"Bagong Silangan")
        XCTAssertEqual(result.bookings.first?.dropoff,"San Francisco del Monte")
    }

    func testRiderWisePiPOverlayTextIsRemovedWithoutDiscardingVisibleLalamoveCard() {
        let lines = [
            OCRLine(text:"RIDERWISE AI", confidence:0.99, x:0.02, y:0.24, width:0.18, height:0.025),
            OCRLine(text:"ACCEPTED REFERENCE", confidence:0.99, x:0.04, y:0.18, width:0.30, height:0.02),
            OCRLine(text:"No accepted booking selected", confidence:0.99, x:0.04, y:0.14, width:0.45, height:0.02),
            OCRLine(text:"TOP RECOMMENDATION", confidence:0.99, x:0.04, y:0.10, width:0.30, height:0.02),
            OCRLine(text:"Latest: San Mateo → Commonwealth", confidence:0.99, x:0.04, y:0.06, width:0.50, height:0.02),
            OCRLine(text:"(~5.1 km) Pick Up Now", confidence:0.99, x:0.03, y:0.82, width:0.40, height:0.03),
            OCRLine(text:"San Mateo", confidence:0.99, x:0.05, y:0.72, width:0.20, height:0.03),
            OCRLine(text:"Marikina", confidence:0.99, x:0.05, y:0.64, width:0.20, height:0.03),
            OCRLine(text:"Motorcycle", confidence:0.99, x:0.70, y:0.60, width:0.18, height:0.03),
            OCRLine(text:"₱83.00", confidence:0.99, x:0.80, y:0.52, width:0.12, height:0.03)
        ]
        let cleaned = LalamoveOCRParser.removeRiderWiseOverlay(from: lines)
        XCTAssertFalse(cleaned.contains { TextNormalization.normalize($0.text).contains("riderwise ai") })
        XCTAssertFalse(cleaned.contains { TextNormalization.normalize($0.text).contains("accepted reference") })
        XCTAssertTrue(cleaned.contains { $0.text == "(~5.1 km) Pick Up Now" })
        XCTAssertTrue(cleaned.contains { $0.text == "Marikina" })
        let parsed = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(parsed.bookings.count, 1)
        XCTAssertEqual(parsed.bookings.first?.pickup, "San Mateo")
        XCTAssertEqual(parsed.bookings.first?.dropoff, "Marikina")
        XCTAssertEqual(parsed.bookings.first?.fare, 83)
    }


    func testBareLocalitySubstringDoesNotMergeDifferentPlaces() {
        let collapsed=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.detected)
        let expandedBare=Booking(pickup:"San Mateo Rizal",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.needsVerification)
        XCTAssertNil(BookingMatcher.uniqueMatch(for:expandedBare,among:[collapsed]))
    }


    func testReferenceBasedEngineKeepsOffscreenCandidatesAndExcludesDeliveredCandidates() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let reference=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let hidden=Booking(pickup:"San Mateo",dropoff:"Antipolo",fare:156,vehicleType:"Motorcycle",status:.notVisible)
        let delivered=Booking(pickup:"San Mateo",dropoff:"Marikina",fare:145,vehicleType:"Motorcycle",status:.delivered)
        let recs=RecommendationEngine.referenceBased(reference:reference,candidates:[hidden,delivered],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.contains { $0.candidateBookingIDs.contains(hidden.id) })
        XCTAssertFalse(recs.contains { $0.candidateBookingIDs.contains(delivered.id) })
    }


    func testReferenceRouteScreensMarikinaButRejectsValenzuelaDetour() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let reference=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let marikina=Booking(pickup:"San Mateo",dropoff:"Marikina",fare:83,vehicleType:"Motorcycle")
        let valenzuela=Booking(pickup:"San Mateo",dropoff:"Valenzuela",fare:134,vehicleType:"Motorcycle")
        let recs=RecommendationEngine.referenceBased(reference:reference,candidates:[marikina,valenzuela],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.contains{$0.candidateBookingIDs.contains(marikina.id)})
        XCTAssertFalse(recs.contains{$0.candidateBookingIDs.contains(valenzuela.id)})
    }


    func testProvinceOnlyDestinationIsNotTreatedAsPreciseLocality() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let reference=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let provinceOnly=Booking(pickup:"San Mateo",dropoff:"Rizal",fare:537,vehicleType:"Motorcycle")
        let recs=RecommendationEngine.referenceBased(reference:reference,candidates:[provinceOnly],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.isEmpty, "A province-only label must not be treated as a geocoded city or municipality.")
    }


    func testNextDistinctAcceptedBookingCanBecomeReferenceAfterManualClear() {
        XCTAssertNil(AcceptedBookingReferenceSelection.firstEligible(
            acceptedIDs: ["accepted-1"], currentReferenceID: nil,
            explicitlyClearedID: "accepted-1"
        ), "The driver-cleared booking must not immediately reselect itself.")
        XCTAssertEqual(AcceptedBookingReferenceSelection.firstEligible(
            acceptedIDs: ["accepted-1", "accepted-2"], currentReferenceID: nil,
            explicitlyClearedID: "accepted-1"
        ), "accepted-2", "A later distinct accepted booking must become the new reference.")
        XCTAssertNil(AcceptedBookingReferenceSelection.firstEligible(
            acceptedIDs: ["accepted-2"], currentReferenceID: "accepted-1",
            explicitlyClearedID: nil
        ), "An active reference must never be replaced automatically.")
    }


    func testMissingFareRemainsNilInsteadOfDisplayingZeroPeso() {
        let partial = Booking(pickup: "Taytay", dropoff: nil, vehicleType: "Motorcycle", status: .partial)
        XCTAssertNil(partial.fare)
        XCTAssertFalse(partial.isComplete)
        XCTAssertTrue(BookingValidator.validate(partial).isEmpty)
    }

    func testPartialBookingObservationsMergeOnlyOnUniqueTwoFieldMatch() {
        let old = Booking(pickup: "Taytay", fare: 131, vehicleType: "Motorcycle", status: .partial)
        let repeated = Booking(pickup: "Taytay", fare: 131, vehicleType: "Motorcycle", status: .partial)
        XCTAssertEqual(BookingMatcher.uniqueMatch(for: repeated, among: [old]), 0)

        let ambiguous = [
            old,
            Booking(pickup: "Taytay", fare: 131, vehicleType: "Motorcycle", status: .partial)
        ]
        XCTAssertNil(BookingMatcher.uniqueMatch(for: repeated, among: ambiguous),
                     "Ambiguous partials must not be merged into an arbitrary booking.")
    }

    func testPartialBookingMatcherRejectsConflictingFareOrEndpoint() {
        let old = Booking(pickup: "Taytay", fare: 131, vehicleType: "Motorcycle", status: .partial)
        let changedFare = Booking(pickup: "Taytay", fare: 177, vehicleType: "Motorcycle", status: .partial)
        let changedPickup = Booking(pickup: "Taguig", fare: 131, vehicleType: "Motorcycle", status: .partial)
        XCTAssertNil(BookingMatcher.uniqueMatch(for: changedFare, among: [old]))
        XCTAssertNil(BookingMatcher.uniqueMatch(for: changedPickup, among: [old]))
    }


    func testCombinedRiderWiseButtonsAreRemovedFromOCR() {
        let lines = [
            OCRLine(text:"RIDERWISE AI", x:0.55, y:0.78, width:0.20, height:0.02),
            OCRLine(text:"Verify addresses Confirm accepted", x:0.42, y:0.45, width:0.45, height:0.03),
            OCRLine(text:"Detected bookings", x:0.05, y:0.90, width:0.30, height:0.03),
            OCRLine(text:"(~800 m) Pick Up Now"),
            OCRLine(text:"San Mateo"),
            OCRLine(text:"₱107.00"),
            OCRLine(text:"Motorcycle"),
            OCRLine(text:"Delivery")
        ]
        let cleaned = LalamoveOCRParser.removeRiderWiseOverlay(from: lines)
        XCTAssertFalse(cleaned.contains { TextNormalization.normalize($0.text).contains("verify addresses") })
        XCTAssertFalse(cleaned.contains { TextNormalization.normalize($0.text).contains("confirm accepted") })
        XCTAssertFalse(cleaned.contains { TextNormalization.normalize($0.text).contains("detected bookings") })
        XCTAssertTrue(cleaned.contains { $0.text.contains("Pick Up Now") })
    }

    func testRiderWiseControlLabelsAloneCannotBecomeBooking() {
        let lines = [
            "RIDERWISE AI", "Detected bookings", "Verify addresses Confirm accepted",
            "PARTIAL", "NOTVISIBLE", "Newest first"
        ].map { OCRLine(text:$0) }
        let cleaned = LalamoveOCRParser.removeRiderWiseOverlay(from: lines)
        let parsed = LalamoveOCRParser.parse(cleaned)
        XCTAssertTrue(parsed.bookings.isEmpty)
        XCTAssertEqual(parsed.screenKind, .unknown)
    }

    func testUploadedLalamovePickupScreenshotParsesEachVisibleCardIndependently() {
        let h = 2778.0, w = 1284.0
        func line(_ text:String, _ top:Double, _ left:Double=80, _ width:Double=500, _ height:Double=44) -> OCRLine {
            OCRLine(text:text, confidence:0.97, x:left/w, y:1.0-(top+height/2)/h,
                    width:width/w, height:height/h)
        }
        let lines = [
            line("On Duty",183,84,196,38),
            line("Home Along the way Above 50 km",333,51,753,43),
            line("(~10.3 km) Pick Up Now",505,53,549,46),
            line("Delivery",645,159,137,34), line("Regular",645,373,129,34),
            line("Bagong Silangan",738,154,367,45), line("Pasig",834,154,114,45),
            line("Motorcycle",953,947,262,50),
            line("upuan ng click .. pki msg ako kpg jn kn...",1068,196,976,50),
            line("₱125.00",1217,990,219,44),
            line("(~4.7 km) Pick Up Now",1426,53,524,46),
            line("Delivery",1566,159,137,34), line("Regular",1566,373,129,34),
            line("San Mateo",1660,153,213,36), line("Marikina",1755,154,183,37),
            line("Motorcycle",1874,947,262,50),
            line("wag na rsw po sabayan dagdagan naa...",1989,194,971,50),
            line("₱91.00",2138,1023,186,44),
            line("(~7.1 km) Pick Up Now",2347,53,510,46),
            line("Delivery",2491,159,137,32), line("Regular",2491,373,129,32)
        ]
        XCTAssertTrue(LalamoveOCRParser.hasLalamoveScreenEvidence(lines))
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.screenKind,.list)
        XCTAssertEqual(result.bookings.count,3)

        let first = result.bookings[0]
        XCTAssertEqual(first.pickup,"Bagong Silangan")
        XCTAssertEqual(first.dropoff,"Pasig")
        XCTAssertEqual(first.fare,125)
        XCTAssertEqual(first.vehicleType,"Motorcycle")
        XCTAssertEqual(first.bookingType,"Delivery · Regular")
        XCTAssertEqual(first.pickupDistanceKm ?? -1,10.3,accuracy:0.001)
        XCTAssertTrue(first.notes?.contains("pki msg") == true)
        XCTAssertNil(first.deliveryDistanceKm)

        let second = result.bookings[1]
        XCTAssertEqual(second.pickup,"San Mateo")
        XCTAssertEqual(second.dropoff,"Marikina")
        XCTAssertEqual(second.fare,91)
        XCTAssertEqual(second.vehicleType,"Motorcycle")
        XCTAssertEqual(second.bookingType,"Delivery · Regular")
        XCTAssertEqual(second.pickupDistanceKm ?? -1,4.7,accuracy:0.001)
        XCTAssertTrue(second.notes?.contains("sabayan") == true)
        XCTAssertNil(second.deliveryDistanceKm)

        let third = result.bookings[2]
        XCTAssertEqual(third.status,.partial)
        XCTAssertNil(third.pickup)
        XCTAssertNil(third.dropoff)
        XCTAssertNil(third.fare)
    }

    func testCustomerSentenceContainingPickUpNowDoesNotSplitBookingCard() {
        let lines = [
            "(~3.0 km) Pick Up Now","Delivery","Regular","Carmona","Pasig",
            "Please click Pick Up Now and message me when you arrive","Motorcycle","₱125.00",
            "(~4.0 km) Pick Up Now","Delivery","Regular","San Mateo","Marikina","Motorcycle","₱91.00"
        ].map { OCRLine(text:$0) }
        let result = LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count,2)
        XCTAssertEqual(result.bookings[0].pickup,"Carmona")
        XCTAssertEqual(result.bookings[0].dropoff,"Pasig")
        XCTAssertTrue(result.bookings[0].notes?.contains("Please click") == true)
        XCTAssertEqual(result.bookings[1].pickup,"San Mateo")
        XCTAssertEqual(result.bookings[1].dropoff,"Marikina")
    }

    func testVehicleOCRTypoDoesNotBecomeEndpointOrStealRealPickup() {
        let lines = ["(~3.0 km) Pick Up Now","Delivery","Regular","Carmona","Pasig","Motorcycia","₱100.00"]
            .map { OCRLine(text:$0) }
        let result = LalamoveOCRParser.parse(lines)
        let booking = try! XCTUnwrap(result.bookings.first)
        XCTAssertEqual(booking.pickup,"Carmona")
        XCTAssertEqual(booking.dropoff,"Pasig")
        XCTAssertEqual(booking.vehicleType,"Motorcycle")
    }

    func testOCRServiceAndVehicleFragmentsCannotBecomeGeographicEndpoints() {
        let fragments = ["l Delivery", "u Delivery", "ur Delivery", "I Delivery", "Motorcycle Delivery", "Regular"]
        for fragment in fragments {
            let lines = [
                OCRLine(text:"(~1.1 km) Pick Up Now"),
                OCRLine(text:"Delivery"), OCRLine(text:"Regular"),
                OCRLine(text:fragment),
                OCRLine(text:"San Mateo"),
                OCRLine(text:"Motorcycle"),
                OCRLine(text:"₱136.00")
            ]
            let result = LalamoveOCRParser.parse(lines)
            XCTAssertEqual(result.bookings.count, 1, "Expected one card for fragment: \\(fragment)")
            XCTAssertEqual(result.bookings[0].pickup, "San Mateo", "UI fragment must not become pickup: \\(fragment)")
            XCTAssertNil(result.bookings[0].dropoff, "UI fragment must not become drop-off: \\(fragment)")
            XCTAssertEqual(result.bookings[0].status, .partial)
        }
    }

    func testRealLocalitiesRemainValidAfterUIFragmentFiltering() {
        for locality in ["San Mateo", "Bagong Silangan", "Bagbag", "Balingasa", "Pasig", "Marikina"] {
            XCTAssertFalse(BookingValidator.isObviousNonLocationLabel(locality), locality)
        }
        for label in ["l Delivery", "u Delivery", "ur Delivery", "On Duty", "Motorcycle", "Priority"] {
            XCTAssertTrue(BookingValidator.isObviousNonLocationLabel(label), label)
        }
    }

    func testBookingValidatorFlagsServiceLabelUsedAsEndpoint() {
        let contaminated = Booking(pickup:"l Delivery", dropoff:"San Mateo", fare:136,
                                   vehicleType:"Motorcycle", bookingType:"Delivery · Regular")
        XCTAssertTrue(BookingValidator.validate(contaminated).contains("Pickup contains a non-location UI/service label"))
    }

    func testLegacyContaminatedEndpointIsSanitizedWithoutDeletingBooking() {
        let legacy = Booking(id:"legacy-fragment", pickup:"ur Delivery", dropoff:"San Mateo",
                             fare:136, vehicleType:"Motorcycle", bookingType:"Delivery · Regular",
                             status:.accepted, screenKind:.accepted, sourceEvidence:["ur Delivery","San Mateo"])
        let repaired = BookingValidator.sanitizePersisted(legacy)
        XCTAssertEqual(repaired.id, "legacy-fragment")
        XCTAssertNil(repaired.pickup)
        XCTAssertEqual(repaired.dropoff, "San Mateo")
        XCTAssertNil(repaired.pickupFullAddress)
        XCTAssertFalse(repaired.verifiedPickup)
        XCTAssertEqual(repaired.status, .needsVerification)
        XCTAssertEqual(repaired.sourceEvidence, ["ur Delivery","San Mateo"])
    }

}
