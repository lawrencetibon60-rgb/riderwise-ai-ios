import Foundation

public enum BookingMatcher {
    /// Reconcile OCR observations only when there is a unique, defensible identity.
    /// Vehicle and service labels are deliberately weak: many unrelated Lalamove
    /// offers share Motorcycle + Delivery + Regular.
    public static func uniqueMatch(for incoming: Booking, among existing: [Booking]) -> Int? {
        if let code = incoming.bookingCode, !code.isEmpty {
            let hits = existing.indices.filter {
                existing[$0].bookingCode?.caseInsensitiveCompare(code) == .orderedSame
            }
            if hits.count == 1 { return hits[0] }
            if !hits.isEmpty { return nil }
        }

        let hits = existing.indices.filter { index in
            let old = existing[index]
            if let a = incoming.bookingCode, let b = old.bookingCode,
               a.caseInsensitiveCompare(b) != .orderedSame { return false }

            // Any fields visible on both observations must agree. This prevents a
            // partial observation from absorbing a different booking with a
            // conflicting fare or endpoint.
            if let a = incoming.fare, let b = old.fare, abs(a - b) >= 0.011 { return false }
            if let a = incoming.pickup, let b = old.pickup, !endpointMatch(a, b) { return false }
            if let a = incoming.dropoff, let b = old.dropoff, !endpointMatch(a, b) { return false }
            if let a = incoming.vehicleType, let b = old.vehicleType,
               TextNormalization.normalize(a) != TextNormalization.normalize(b) { return false }
            if let a = incoming.bookingType, let b = old.bookingType,
               TextNormalization.normalize(a) != TextNormalization.normalize(b) { return false }

            var strongAnchors = 0
            if let a = incoming.fare, let b = old.fare, abs(a - b) < 0.011 { strongAnchors += 1 }
            if let a = incoming.pickup, let b = old.pickup, endpointMatch(a, b) { strongAnchors += 1 }
            if let a = incoming.dropoff, let b = old.dropoff, endpointMatch(a, b) { strongAnchors += 1 }

            // A very close rider-to-pickup distance is useful only alongside an
            // exact shared endpoint. It is never treated as delivery distance.
            let hasSharedEndpoint = sharedEndpoint(incoming, old)
            if hasSharedEndpoint,
               let a = incoming.pickupDistanceKm, let b = old.pickupDistanceKm,
               abs(a - b) <= 0.20 { strongAnchors += 1 }

            // Permit partial <-> complete reconciliation. Two independent strong
            // anchors are required; generic vehicle/type labels never count.
            return strongAnchors >= 2
        }
        return hits.count == 1 ? hits[0] : nil
    }

    private static func sharedEndpoint(_ a: Booking, _ b: Booking) -> Bool {
        if let x = a.pickup, let y = b.pickup, endpointMatch(x, y) { return true }
        if let x = a.dropoff, let y = b.dropoff, endpointMatch(x, y) { return true }
        return false
    }

    private static func endpointMatch(_ a: String, _ b: String) -> Bool {
        let x = TextNormalization.normalize(a), y = TextNormalization.normalize(b)
        guard !x.isEmpty && !y.isEmpty else { return false }
        if x == y { return true }
        // A collapsed locality may match an expanded address only when the longer
        // string contains explicit address context. Bare-name substring matching
        // can merge different places such as San Mateo and San Mateo Rizal.
        let longer = x.count >= y.count ? x : y
        let rawLonger = a.count >= b.count ? a : b
        let hasAddressContext = rawLonger.contains(",") ||
            [" barangay ", " brgy ", " street ", " st ", " road ", " rd ", " warehouse ", " building ", " bldg ", " blk ", " lot ", " unit "].contains { longer.contains($0) }
        return hasAddressContext && (x.contains(y) || y.contains(x))
    }
}

/// Deterministic field-level merge for repeated OCR observations of one booking.
public enum BookingReconciler {
    public static func merging(_ incoming: Booking, into existing: Booking, at now: Date = .now) -> Booking {
        var old = existing
        old.lastSeen = now
        old.seenCount += 1
        old.lastKnownPosition = incoming.lastKnownPosition

        if let newPickup = incoming.pickupFullAddress, let oldPickup = old.pickupFullAddress,
           newPickup != oldPickup { old.verifiedPickup = false }
        if let newDropoff = incoming.dropoffFullAddress, let oldDropoff = old.dropoffFullAddress,
           newDropoff != oldDropoff { old.verifiedDropoff = false }

        old.bookingCode = incoming.bookingCode ?? old.bookingCode
        old.pickupFullAddress = incoming.pickupFullAddress ?? old.pickupFullAddress
        old.dropoffFullAddress = incoming.dropoffFullAddress ?? old.dropoffFullAddress

        // Fill missing data even if the aggregate confidence is lower. Only replace
        // existing non-empty values when the new observation is at least as strong.
        let mayReplaceExisting = incoming.confidence >= old.confidence
        if old.pickup == nil || mayReplaceExisting { old.pickup = incoming.pickup ?? old.pickup }
        if old.dropoff == nil || mayReplaceExisting { old.dropoff = incoming.dropoff ?? old.dropoff }
        if old.baseFare == nil || mayReplaceExisting { old.baseFare = incoming.baseFare ?? old.baseFare }
        if old.additionalFare == nil || mayReplaceExisting { old.additionalFare = incoming.additionalFare ?? old.additionalFare }
        if old.fare == nil || mayReplaceExisting { old.fare = incoming.fare ?? old.fare }
        if old.pickupDistanceKm == nil || mayReplaceExisting { old.pickupDistanceKm = incoming.pickupDistanceKm ?? old.pickupDistanceKm }
        if old.vehicleType == nil || mayReplaceExisting { old.vehicleType = incoming.vehicleType ?? old.vehicleType }
        if old.bookingType == nil || mayReplaceExisting { old.bookingType = incoming.bookingType ?? old.bookingType }
        if old.notes == nil || mayReplaceExisting { old.notes = incoming.notes ?? old.notes }
        if old.paymentMethod == nil || mayReplaceExisting { old.paymentMethod = incoming.paymentMethod ?? old.paymentMethod }
        if !incoming.sourceEvidence.isEmpty && mayReplaceExisting { old.sourceEvidence = incoming.sourceEvidence }
        old.confidence = max(old.confidence, incoming.confidence)

        if old.isComplete && (old.status == .partial || old.status == .notVisible || old.status == .stale) {
            old.status = incoming.status == .partial ? .detected : incoming.status
        }
        if incoming.screenKind == .accepted && old.status != .delivered { old.status = .accepted }
        if incoming.screenKind == .expanded || incoming.screenKind == .accepted {
            old.screenKind = incoming.screenKind
            if incoming.screenKind != .accepted && old.pickupFullAddress != nil && old.dropoffFullAddress != nil &&
                old.status != .delivered && old.status != .accepted {
                old.status = old.verifiedPickup && old.verifiedDropoff ? .verified : .needsVerification
            }
        }
        return old
    }
}
