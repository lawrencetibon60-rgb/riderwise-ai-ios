#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test
while IFS= read -r -d '' f; do
  swiftc -frontend -parse "$f" >/dev/null
done < <(find iOSApp Sources/RiderWiseCore -type f -name '*.swift' -print0)
python3 - <<'PY'
import gzip, json, pathlib, plistlib, collections
root=pathlib.Path('.')
plist=plistlib.loads((root/'iOSApp/Info.plist').read_bytes())
ent=plistlib.loads((root/'iOSApp/RiderWiseAI.entitlements').read_bytes())
assert plist.get('NSScreenCaptureUsageDescription')
assert 'screen-capture' in plist.get('UIBackgroundModes', [])
assert 'audio' in plist.get('UIBackgroundModes', [])
project=(root/'project.yml').read_text()
assert 'RiderWiseBroadcast:' not in project
capture=(root/'iOSApp/ScreenCaptureManager.swift').read_text()
assert 'import ScreenCaptureKit' in capture
assert 'SCContentSharingPicker.shared' in capture
assert 'picker.present()' in capture
assert 'picker.isActive = true' in capture
assert capture.index('picker.isActive = true') < capture.index('picker.present()')
assert 'nanoseconds: 900_000_000' not in capture
assert 'picker.present(using: .display)' not in capture
assert 'allowedPickerModes' not in capture
assert 'VNRecognizeTextRequest' in capture
assert 'max(1.5, scanInterval)' in capture
assert 'TimeInterval = 1.5' in capture
assert 'ReplayKit' not in capture
assert '- sdk: ScreenCaptureKit.framework' not in project
assert 'OTHER_LDFLAGS[sdk=iphoneos*]' in project
assert not (root/'BroadcastExtension').exists()
geo=root/'iOSApp/Resources/Geography'
for name in ['luzon_psgc_3q_2026.json','luzon_psgc_3q_2026.json.gz','geographic_centroids_legacy.json','riderwise_upgrade_config.json']:
    assert (geo/name).is_file(), f'Missing app geography resource: {name}'
with gzip.open(root/'Sources/RiderWiseCore/luzon_psgc_3q_2026.json.gz','rt',encoding='utf-8') as f:
    data=json.load(f)
records=data['records']
codes={r['psgc'] for r in records}
counts=collections.Counter(r['level'] for r in records)
assert len(records)==21330 and len(codes)==len(records)
assert dict(counts)=={'Reg':8,'Prov':38,'City':77,'Mun':694,'SubMun':14,'Bgy':20499}
assert all(not r.get('parentPsgc') or r['parentPsgc'] in codes for r in records)
config=json.loads((geo/'riderwise_upgrade_config.json').read_text())
assert config['scan']['interval_ms']==1500
assert config['safety']['auto_accept_bookings'] is False
assert config['safety']['auto_reject_bookings'] is False
assert config['ai']['large_local_model_autostart'] is False
pip=(root/'iOSApp/PiPVideoRenderer.swift').read_text()
assert 'displayLayer.enqueue(sample)' in pip
assert 'activatePiPAudioSession()' in pip
assert 'setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])' in pip
assert 'setActive(true)' in pip
assert 'CMSetAttachment(' in pip and 'kCMSampleAttachmentKey_DisplayImmediately' in pip
assert 'receiver.enqueue' not in pip
app=(root/'iOSApp/RiderWiseApp.swift').read_text()
assert '.onChange(of: pipFrameRevision)' in app
assert 'store.rideMode ? "ride-on" : "ride-off"' in app
assert 'store.bookings.map' in app
assert 'PiP frame enqueue failed: \\(error.localizedDescription)' not in pip
print('ScreenCaptureKit picker activation-before-presentation, full-display call, capture path, permission declaration and no-extension architecture: PASS')
print('PiP frame delivery: synchronous display-layer enqueue; no cancellable receiver task: PASS')
print('PiP background audio capability and activation: PASS')
print('Geographic resources: PASS')
print('PSGC dataset: PASS (21,330 records, unique codes, valid parent links)')
PY
