import Foundation
import Combine
import CryptoKit
import LiteRTLM
import RiderWiseCore

/// Optional on-device Gemma 4 E2B ranker. It may reorder only deterministic candidate IDs;
/// all booking facts, route labels, and compatibility decisions remain owned by RiderWiseCore.
@MainActor final class OfflineAIManager: ObservableObject {
    @Published private(set) var status = "Offline AI model not downloaded. Deterministic recommendations are active."
    @Published private(set) var isDownloading = false
    @Published private(set) var isReady = false
    private var engine: Engine?

    private let modelName = "gemma-4-E2B-it.litertlm"
    private let modelURL = URL(string:"https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/6b78abd019e61a1ca4cbe3b212d2c9ce8ff38a94/gemma-4-E2B-it.litertlm")!
    private let expectedSHA256 = "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c"
    private let minimumBytes: Int64 = 2_000_000_000

    private var modelFile: URL {
        let directory=FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("RiderWiseModels",isDirectory:true)
        return directory.appendingPathComponent(modelName)
    }

    init() {
        if FileManager.default.fileExists(atPath:modelFile.path) {
            status="Gemma model file found. Verify and load it before use."
        }
    }

    func downloadModel() async {
        guard !isDownloading else{return}
        isDownloading=true
        status="Downloading Gemma 4 E2B (~2.59 GB). Wi-Fi and at least 5 GB free storage are recommended."
        defer { isDownloading=false }
        do {
            let (temporary,response)=try await URLSession.shared.download(from:modelURL)
            guard let http=response as? HTTPURLResponse,(200..<300).contains(http.statusCode) else {
                throw NSError(domain:"RiderWiseModel",code:1,userInfo:[NSLocalizedDescriptionKey:"Model host returned an unsuccessful response."])
            }
            let values=try temporary.resourceValues(forKeys:[.fileSizeKey])
            guard Int64(values.fileSize ?? 0) >= minimumBytes else {
                throw NSError(domain:"RiderWiseModel",code:2,userInfo:[NSLocalizedDescriptionKey:"Downloaded model is smaller than expected; it may be incomplete."])
            }
            status="Verifying model integrity…"
            let digest=try Self.sha256(file:temporary)
            guard digest == expectedSHA256 else {
                throw NSError(domain:"RiderWiseModel",code:3,userInfo:[NSLocalizedDescriptionKey:"Model SHA-256 verification failed. The file will not be loaded."])
            }
            try FileManager.default.createDirectory(at:modelFile.deletingLastPathComponent(),withIntermediateDirectories:true)
            if FileManager.default.fileExists(atPath:modelFile.path) { try FileManager.default.removeItem(at:modelFile) }
            try FileManager.default.moveItem(at:temporary,to:modelFile)
            status="Model downloaded and SHA-256 verified. Tap Load Offline AI."
        } catch {
            status="Model download failed: \(error.localizedDescription). Screenshot OCR and deterministic recommendations remain available."
        }
    }

    func loadModel() async {
        guard FileManager.default.fileExists(atPath:modelFile.path) else {
            status="Model file is not installed. Download it first."; return
        }
        do {
            status="Verifying and loading local AI model…"
            let digest=try Self.sha256(file:modelFile)
            guard digest == expectedSHA256 else { throw NSError(domain:"RiderWiseModel",code:4,userInfo:[NSLocalizedDescriptionKey:"Model integrity check failed."]) }
            let cache=FileManager.default.urls(for:.cachesDirectory,in:.userDomainMask)[0].appendingPathComponent("LiteRTLM",isDirectory:true)
            try FileManager.default.createDirectory(at:cache,withIntermediateDirectories:true)
            do {
                let gpuConfig=try EngineConfig(modelPath:modelFile.path,backend:.gpu,maxNumTokens:512,cacheDir:cache.path)
                let gpuEngine=Engine(engineConfig:gpuConfig)
                try await gpuEngine.initialize()
                engine=gpuEngine
                status="Gemma 4 E2B loaded with Metal GPU acceleration."
            } catch {
                let cpuConfig=try EngineConfig(modelPath:modelFile.path,backend:.cpu(),maxNumTokens:512,cacheDir:cache.path)
                let cpuEngine=Engine(engineConfig:cpuConfig)
                try await cpuEngine.initialize()
                engine=cpuEngine
                status="Gemma 4 E2B loaded using CPU fallback."
            }
            isReady=true
        } catch {
            engine=nil; isReady=false
            status="Offline AI could not load on this iPhone: \(error.localizedDescription). Deterministic fallback remains active."
        }
    }

    func rank(_ recommendations:[Recommendation]) async -> [Recommendation] {
        guard isReady,let engine,!recommendations.isEmpty else{return recommendations}
        let bounded=Array(recommendations.prefix(8))
        let prompt=buildString {
            append("Rank ONLY these RiderWise candidate IDs from best to worst. Return only IDs C1 through C8, one per line. Do not add, remove, invent, or modify facts. Do not change fare, route, distance, confidence, compatibility, or verification state. The deterministic engine is authoritative.\n")
            for (index,item) in bounded.enumerated() {
                append("C\(index+1) | score=\(String(format:"%.3f",item.score)) | label=\(item.label) | reason=\(item.reason.prefix(350))\n")
            }
        }
        do {
            let conversation=try engine.createConversation()
            let response=try await conversation.sendMessage(Message(prompt))
            let answer=response.toString
            let regex=try NSRegularExpression(pattern:"(?<![A-Za-z0-9])C([1-8])(?![0-9])")
            let ns=answer as NSString
            let indices=regex.matches(in:answer,range:NSRange(location:0,length:ns.length)).compactMap { match -> Int? in
                guard match.numberOfRanges>1 else{return nil}
                let n=ns.substring(with:match.range(at:1))
                guard let value=Int(n),value>0,value<=bounded.count else{return nil}
                return value-1
            }
            var ordered:[Recommendation]=[]; var used:Set<String>=[]
            for index in indices where index<bounded.count {
                let item=bounded[index]
                if used.insert(item.id).inserted { ordered.append(item) }
            }
            for item in bounded where used.insert(item.id).inserted { ordered.append(item) }
            return ordered + Array(recommendations.dropFirst(bounded.count))
        } catch {
            status="Local AI ranking unavailable; deterministic recommendation order retained."
            return recommendations
        }
    }

    private static func sha256(file:URL)throws->String {
        let handle=try FileHandle(forReadingFrom:file); defer { try? handle.close() }
        var hasher=SHA256()
        while true {
            let chunk=try handle.read(upToCount:4*1024*1024) ?? Data()
            if chunk.isEmpty { break }
            hasher.update(data:chunk)
        }
        return hasher.finalize().map{String(format:"%02x",$0)}.joined()
    }
}
