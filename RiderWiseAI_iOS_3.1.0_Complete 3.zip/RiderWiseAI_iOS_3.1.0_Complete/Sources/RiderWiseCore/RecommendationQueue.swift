import Foundation

public enum RecommendationState:String,Codable,Sendable {
    case newlyDetected="NEWLY_DETECTED"
    case partial="PARTIAL"
    case needsAddressVerification="NEEDS_ADDRESS_VERIFICATION"
    case verifiedCandidate="VERIFIED_CANDIDATE"
    case recommended="RECOMMENDED"
    case notVisibleLastScan="NOT_VISIBLE_LAST_SCAN"
    case seenAgain="SEEN_AGAIN"
    case accepted="ACCEPTED"
    case rejectedByDriver="REJECTED_BY_DRIVER"
    case expiredConfirmed="EXPIRED_CONFIRMED"
    case staleUnverified="STALE_UNVERIFIED"
    // Backward-compatible persisted values from the first iOS source draft.
    case needsVerification="needsVerification"
    case notVisible="notVisible"
    case stale="stale"
    case dismissed="dismissed"
}
public struct SavedRecommendation:Codable,Identifiable,Sendable {
    public var id:String
    public var description:String
    public var state:RecommendationState
    public var firstSeen:Date
    public var lastSeen:Date
    public var score:Double
    public var availability:String
}

/// Persistent bounded queue. Disappearing from a captured screen is never treated as expiry.
public actor RecommendationQueue {
    private let fileURL:URL
    private var entries:[SavedRecommendation]=[]
    private let limit=200
    public init(fileURL:URL) {
        self.fileURL=fileURL
        if let d=try? Data(contentsOf:fileURL),let x=try? JSONDecoder().decode([SavedRecommendation].self,from:d){entries=x}
    }
    public func all()->[SavedRecommendation]{entries.sorted{$0.lastSeen>$1.lastSeen}}
    public func clear() throws { entries=[]; try persist() }
    public func refresh(_ incoming:[SavedRecommendation],at now:Date = .now)throws {
        let incomingIDs=Set(incoming.map(\.id))
        for i in entries.indices where !isTerminal(entries[i].state) && !incomingIDs.contains(entries[i].id) {
            let age=now.timeIntervalSince(entries[i].lastSeen)
            entries[i].state = age > 24*60*60 ? .staleUnverified : .notVisibleLastScan
            entries[i].availability = "NOT_VISIBLE_IN_LAST_CAPTURE; NOT PROOF_OF_UNAVAILABILITY"
        }
        for var item in incoming {
            if let old=entries.first(where:{$0.id==item.id}) {
                if isTerminal(old.state) { continue }
                item.firstSeen=old.firstSeen
                if old.state == .notVisibleLastScan || old.state == .staleUnverified || old.state == .notVisible || old.state == .stale {
                    item.state = .seenAgain
                }
            }
            item.lastSeen=now
            item.availability="SEEN_AT_LAST_CAPTURE; LIVE_AVAILABILITY_UNVERIFIED"
            if let i=entries.firstIndex(where:{$0.id==item.id}){entries[i]=item}else{entries.append(item)}
        }
        if entries.count>limit { entries=Array(entries.sorted{$0.lastSeen<$1.lastSeen}.suffix(limit)) }
        try persist()
    }
    public func mark(_ id:String,state:RecommendationState)throws {
        guard let i=entries.firstIndex(where:{$0.id==id}) else{return}
        entries[i].state=state
        if isTerminal(state) { entries[i].availability="REMOVED_FROM_ACTIVE_RECOMMENDATIONS_BY_DRIVER_OR_CONFIRMED_EVENT" }
        try persist()
    }
    private func isTerminal(_ state:RecommendationState)->Bool {
        state == .accepted || state == .rejectedByDriver || state == .expiredConfirmed || state == .dismissed
    }
    private func persist()throws {
        try FileManager.default.createDirectory(at:fileURL.deletingLastPathComponent(),withIntermediateDirectories:true)
        try JSONEncoder().encode(entries).write(to:fileURL,options:.atomic)
    }
}
