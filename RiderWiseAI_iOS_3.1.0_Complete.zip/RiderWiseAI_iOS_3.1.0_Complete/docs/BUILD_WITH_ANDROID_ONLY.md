# Build RiderWise iOS from an Android phone (no PC)

The source can be edited and uploaded from an Android browser. Xcode itself must run on a cloud macOS runner; it cannot run on Android.

## What the included workflow does

1. Runs `swift test` on a Linux runner.
2. Starts an Xcode 27 macOS runner.
3. Installs XcodeGen and generates `RiderWiseAI.xcodeproj` from `project.yml`.
4. Resolves the LiteRT-LM Swift package.
5. Builds the iOS Simulator app without signing.
6. Builds the generic iOS device target without signing.
7. Uploads both the simulator app and the unsigned iOS-device app as GitHub Actions artifacts.

The artifact is a simulator build, not a physical-device IPA.

## Upload using GitHub from Android

1. Open GitHub in Chrome on Android and sign in.
2. Create a repository for RiderWise iOS (private is fine; check your Actions minutes and macOS runner billing).
3. Upload `RiderWiseAI_iOS_3.1.0_Complete.zip` as a repository file and commit it.
4. Open the repository's **Code** menu and start a GitHub Codespace if available for your account.
5. In the Codespaces terminal, run:

```bash
unzip RiderWiseAI_iOS_3.1.0_Complete.zip -d /tmp/riderwise-ios
cp -a /tmp/riderwise-ios/RiderWiseAI_iOS_3.1.0_Complete/. .
rm RiderWiseAI_iOS_3.1.0_Complete.zip
git add .
git commit -m "Add RiderWise AI native iOS port"
 git push
```

6. Open the repository's **Actions** tab. Select **RiderWise iOS Build and Test** and run it if it did not start automatically.
7. Wait for both jobs. Open the run and inspect the build logs. Download the simulator artifact only for inspection; it cannot be installed on your iPhone.

If Codespaces is not available, use another trusted browser-based Git environment that can unzip and push the repository. Do not paste Apple credentials into a public terminal or source file.

## Getting a signed IPA

The current workflow deliberately does not sign. To install on a physical iPhone and distribute reliably without owning a Mac, configure Apple signing through a cloud service or App Store Connect workflow.

- TestFlight distribution requires Apple Developer Program membership and App Store Connect setup.
- An ordinary Apple Account alone does not create a permanent distributable IPA.
- Never send your Apple password, 2FA code, private key, distribution certificate or provisioning profile in this chat.
- Add secrets only through the trusted cloud build service's encrypted secrets UI.

## Device test sequence after signing

1. Install RiderWise AI on the iPhone 13 Pro Max.
2. Open the app and grant screen-capture permission only when prompted.
3. Start the system screen-sharing picker and select the full display.
4. Switch to Lalamove Driver and leave the available-bookings screen visible for at least 15 seconds.
5. Scroll slowly through several cards, then open one booking's full details.
6. Accept a test booking only if you genuinely intend to accept it; verify that it becomes the first reference.
7. Capture a second accepted booking and verify that the first reference remains protected.
8. Mark the first reference delivered, then verify that a later accepted booking can become the new reference.
9. Test app switching, phone call interruption, screen lock, capture stop, and restart.
10. Download Gemma only on Wi-Fi with adequate free storage; test GPU and CPU fallback, memory pressure, heat and battery.

## Build failure reporting

If CI fails, download or copy the complete failing Xcode build log and attach it here. Do not share signing secrets. A successful Linux `swift test` alone does not prove the iOS app target compiles.


## What the cloud build can and cannot deliver

The GitHub Actions workflow in this project can run the portable Swift tests, generate the Xcode project with XcodeGen, and attempt unsigned simulator and iOS-device builds on a macOS runner. It uploads the simulator app and unsigned device app as CI artifacts.

An unsigned `.app` is **not installable** on the iPhone. Do not rename it to `.ipa`. A signed IPA or TestFlight build requires the user's Apple signing credentials and the appropriate Apple Developer Program membership. With only an ordinary Apple Account and no Mac, we can prepare and compile the project in the cloud, but permanent iPhone installation is not yet available. Do not send Apple passwords, verification codes, certificates, or private keys in chat.

The user's iPhone 13 Pro Max is already running iOS 27.2.1, so the deployment target is iOS 27.0. Physical-device validation of ScreenCaptureKit, background capture continuity, Vision OCR performance, memory use, and battery impact remains a required release gate.
