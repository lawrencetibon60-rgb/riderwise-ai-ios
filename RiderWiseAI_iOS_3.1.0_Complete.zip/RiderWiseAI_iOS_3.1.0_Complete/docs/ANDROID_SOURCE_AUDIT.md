# Android source audit — supplied RiderWise AI 3.1.0

## Source examined

- Archive: `RiderWise_AI_3.1.0_Automatic_Dashboard_First_Source(3).zip`
- Archive entries: 72
- Android implementation: Java and Kotlin under `app/src/main/java/com/riderwise/ai/`
- Geographic assets: `luzon_psgc_3q_2026.json.gz`, `riderwise_upgrade_config.json`
- Tests: `BookingAndGeoTest`, `BookingHeaderDetectorTest`, `ProfitCalculatorTest`
- Requirements and design docs: `LOCKED_BOOKING_INTELLIGENCE_REQUIREMENTS.md`, `PERSISTENT_RECOMMENDATION_ENGINE.md`, `OFFLINE_AI_IMPLEMENTATION.md`, `DEVELOPER_UPGRADE_CONFIG.md`
- Original Android ZIP is preserved in `reference/Android_Source_RiderWise_AI_3.1.0.zip`.

## Source modules reviewed

| Android source | Responsibility / port target |
|---|---|
| `MainActivity.java` | Android main screen and workflow; replaced by SwiftUI dashboard/coordinator |
| `Booking.java` | Booking fields, identity and state; ported to Swift `Booking` |
| `BookingExtractor.java` | OCR text extraction; ported/adapted to `LalamoveOCRParser` |
| `BookingHeaderDetector.java` | Card/header segmentation; adapted to Vision bounding boxes and header bands |
| `BookingValidator.java` | Deterministic validation; ported to Swift `BookingValidator` |
| `OcrProcessor.java` | Android OCR wrapper; replaced by Apple Vision request path |
| `ScreenCaptureService.java` | Android MediaProjection service; adapted to ScreenCaptureKit and explicit iOS system picker |
| `PermissionManager.java` | Android permissions; replaced by iOS privacy prompts/capabilities |
| `FloatingAssistantService.java` | Android overlay; adapted to in-app SwiftUI dashboard and Live Activity |
| `BookingStore.java` | Persistent booking history/upsert; ported into SwiftUI store persistence and bounded 7-day/500-record policy |
| `RecommendationQueueStore.java` | Persistent candidate lifecycle; ported to `RecommendationQueue` actor |
| `AcceptedBookingDetector.java` | Accepted screen detection; ported into accepted-screen OCR markers and first-reference protection |
| `RecommendationEngine.java` | Multi-booking combination scoring and route order search; ported to deterministic Swift recommendation engine |
| `RouteCompatibilityEngine.java` | Route geometry; adapted to straight-line legacy-centroid estimates, always labelled approximate |
| `LocationVerificationManager.java` | Ambiguous place/address verification; ported to PSGC context and driver-confirmed full addresses |
| `GeographicDataset.java` | Legacy area centroids and aliases; ported to `geographic_centroids_legacy.json` with unverified provenance warning |
| `PsgcDataset.java` | Offline administrative hierarchy; original PSGC data retained |
| `GeoMatcher.java` | Geographic name matching; replaced by `PSGCResolver` and `CentroidResolver` |
| `GeographicIntelligence.java` | Local pickup activity; ported as observed-history counts, not forecasting |
| `RoadRoutingProvider.java` | Road routing abstraction; no verified provider/data was included, so real road routing remains pending |
| `ProfitCalculator.java` | Fare/fuel/profit math; ported to Swift `ProfitCalculator` |
| `UpgradeConfig.java` | Upgrade configuration; original JSON retained |
| `LiteRtLocalAnalyzer.kt` | Android LiteRT-LM integration; iOS LiteRT-LM adapter source added |
| `OfflineAiCoordinator.java` | Deterministic gate and model orchestration; adapted to candidate-ID-only local ranker |
| `AiModelManager.java` | Model download/storage lifecycle; iOS model download + SHA-256 verification added |

## Important source-level constraints preserved

- The Android requirements document says this is a specification, not evidence every feature is implemented or device-tested.
- No automatic Lalamove taps, scrolling, accepting or rejecting are added.
- Only observed screen content can be recognized; unobserved cards must not be claimed as scanned.
- `~N km` is rider-to-pickup distance, not delivery distance.
- Ambiguous localities remain uncertain until address context resolves them.
- Centroid distance is not road distance or ETA.
- Local AI is optional and can only rank deterministic candidate IDs.
- Not visible does not mean expired or unavailable.

## Porting decisions

The Android `FloatingAssistantService` cannot be reproduced as a system-wide overlay in an ordinary iOS app. The iOS app uses an adaptive SwiftUI dashboard and a Lock Screen Live Activity. The iPhone 13 Pro Max does not have Dynamic Island.

The Android `RoadRoutingProvider` is an interface, not proof that a working road-network dataset/provider is bundled. The iOS port does not invent one. Its centroid-based route scores remain explicitly approximate until a real provider is selected and tested.


## Source-package consistency warning

The uploaded archive is named and released as RiderWise AI 3.1.0: `app/build.gradle` reports `versionName "3.1.0"` and the archive contains `RELEASE_NOTES_3.1.0.md`. However, the included `VALIDATION_REPORT.md` is stale and identifies itself as a 3.0.0 validation report. It must not be treated as proof that the 3.1.0 Android build was validated. The iOS port therefore treats source code and tests as the migration baseline, not as proof of a verified Android release.
