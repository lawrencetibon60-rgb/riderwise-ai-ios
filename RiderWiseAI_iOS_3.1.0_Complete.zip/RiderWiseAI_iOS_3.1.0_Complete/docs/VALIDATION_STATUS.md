# Validation status — current workspace

## Executed checks

- `swift test` on Linux / Swift 6.2: **33 tests passed, 0 failed**.
- `swiftc -frontend -parse` on all iOS app and Live Activity Swift files: **syntax parse passed**.
- Original Android source ZIP opened and reviewed.
- Three supplied Lalamove iPhone screenshots used as OCR parser reference fixtures.
- App icon asset and XcodeGen project configuration created.

## Not executed

- XcodeGen project generation.
- `xcodebuild` simulator compilation.
- `xcodebuild` generic iOS device compilation.
- iPhone installation, permission prompt and ScreenCaptureKit stream.
- Live Activity extension runtime.
- LiteRT-LM package resolution and model load.
- Gemma model download from the app and on-device SHA verification.
- iPhone 13 Pro Max memory, thermal, battery and scan-cadence measurements.
- Signed IPA export, TestFlight upload or physical installation.

## Why this distinction matters

The Linux Swift test target compiles only `Sources/RiderWiseCore`. The iOS app and extension depend on Apple's iOS SDK, ScreenCaptureKit, Vision, ActivityKit, WidgetKit and LiteRT-LM. They must be compiled by Xcode on macOS. Syntax parsing is not an iOS build.

## Current result

The portable core is tested. The native iOS application is a prepared source/build project, not yet a verified installable iOS release.
