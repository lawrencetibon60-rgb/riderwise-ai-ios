# iOS port gap register

This register separates implemented source from features that require Xcode or physical-device proof.

| Area | Current state | Remaining gap / risk |
|---|---|---|
| Xcode project generation | XcodeGen `project.yml` prepared | Must run on Xcode 27 cloud runner |
| iOS Simulator build | Workflow configured | Not executed yet |
| iOS device build | Unsigned device build configured | Not executed; signing not configured |
| Signed IPA | Not generated | Apple signing and distribution configuration required |
| ScreenCaptureKit | Native manager and system picker source added | API compile, permission, background capability, stream interruption and real Lalamove capture need device tests |
| 2.5-second cadence | Frame sampler with quick unchanged-frame debounce | Measure real cadence and missed-card behavior on iPhone |
| Vision OCR | Native Vision request source added | OCR accuracy on iPhone screenshots and live capture not measured |
| Multi-card parser | Header/bounding-box segmentation and 33 portable core tests | Additional Lalamove screen variants and real scroll tests |
| Expanded-address merge | Conservative unique matcher | Test ambiguous and repeated cards on device |
| Accepted reference | First accepted screen saved and protected in app logic | Verify real accepted booking screen markers; app state integration not Xcode-compiled |
| Booking history | Seven-day/500-record pruning in app store | Restart, storage pressure and migration test on iPhone |
| Recommendation queue | Persistent actor with lifecycle states | App lifecycle/restart integration test |
| Multi-booking recommendations | Up to six candidates, bounded route-order search | Compare scores and order against Android reference scenarios |
| PSGC | Full supplied data, hierarchy and contextual address resolver | Validate every user-entered address; data version/provenance check |
| Legacy centroid coordinates | Ported, marked approximate | Coordinates are not verified road geometry; do not use as precise address geocoding |
| Road routing | Not included | Select lawful provider/road graph and validate coverage/terms |
| Offline AI | Gemma 4 E2B model download/hash/rank source added | Swift package resolve, model artifact compatibility, model load, GPU/CPU performance and memory test on iPhone 13 Pro Max |
| Live Activity | Widget extension and manager source added | Xcode extension embedding, user permission and Lock Screen test |
| Dashboard resizing | Compact/comfortable adaptive layout | Does not replicate Android floating overlay or drag-resize window |
| Floating overlay | Not supported as Android-style cross-app overlay | Adapted to Live Activity and native app dashboard |
| Profit calculator | Fare components and explicit user route/fuel inputs | Verify with actual driver-entered values |
| Local heatmap | Historical pickup counts | No live demand/traffic feed; not a predictive heatmap |
| Diagnostics | Bounded local event log | App UI, rotation and privacy review on device |
| App distribution | Cloud build workflow prepared | User must configure Apple account signing; TestFlight requires paid membership |

## Release blockers

Do not label the project a finished iOS app or provide an installable IPA until:

1. Xcode 27 CI completes both simulator and device builds.
2. iPhone 13 Pro Max installs a signed build.
3. ScreenCaptureKit is tested with the actual Lalamove app and the user-authorized full-display picker.
4. OCR, booking identity, accepted reference, queue persistence, address verification and route behavior pass the physical-device acceptance plan.
5. Offline model download/hash/load and memory/thermal behavior are measured.
6. Live Activity extension builds and displays correctly.
7. Signing/distribution is verified.
