# RiderWise AI 3.1.0 — Native iOS Port

This repository is the iOS migration workspace for the supplied Android `RiderWise_AI_3.1.0_Automatic_Dashboard_First_Source` project.

## Current engineering status

- The portable Swift core builds on Linux with Swift 6.2.
- **33 automated core tests pass** (including OCR fixtures modeled on the three iPhone Lalamove screenshots supplied by the owner).
- iOS app, ScreenCaptureKit, Live Activity, and LiteRT-LM source files are present.
- The Xcode project is generated from `project.yml` with XcodeGen in the cloud macOS workflow.
- **The native iOS target has not yet been compiled with Xcode or run on the iPhone 13 Pro Max.** The cloud workflow must pass before calling this an installable iOS build.
- **No signed IPA has been produced.** A signed device build requires Apple signing and distribution configuration.

## Project layout

- `Sources/RiderWiseCore/` — portable booking, OCR parsing, PSGC, centroid compatibility, multi-booking recommendation, queue, profit and diagnostics logic.
- `iOSApp/` — SwiftUI app, Vision OCR, ScreenCaptureKit manager, offline Gemma model manager and adaptive dashboard.
- `LiveActivityWidget/` — Lock Screen Live Activity and Dynamic Island presentation for supported devices.
- `Tests/RiderWiseCoreTests/` — automated core tests.
- `docs/` — source audit, feature matrix, limitations, build and test instructions.
- `.github/workflows/ios-build.yml` — cloud macOS Xcode build workflow.

## Key behavior and safety rules

1. Screen capture starts only after the driver explicitly opens Apple's system sharing picker and chooses what to share.
2. OCR samples frames at a configurable default of 2.5 seconds. Fast scrolling can still cause missed cards.
3. Rider-to-pickup distance (the orange `~N km` value) is not delivery-route distance and is never used as such.
4. Partial cards stay partial. Ambiguous localities such as a bare `San Mateo` are not silently assigned a unique administrative location for reference-based route decisions.
5. The legacy Android coordinate table is explicitly approximate. It is not a road-routing, traffic or ETA provider.
6. Recommendations never accept or reject a Lalamove booking. The driver must open and confirm the real booking in Lalamove.
7. The first detected accepted booking is saved as the reference; later accepted bookings do not silently replace it. The driver can mark it delivered or manually replace it.
8. The local AI model can reorder only already-computed candidate IDs. Deterministic OCR, fares, route rules and verification remain authoritative.
9. Historical absence from a screen is not treated as proof that an offer expired or is unavailable.
10. Diagnostics must not store customer phone numbers, names, full addresses or raw booking identifiers.

## Build

See `docs/BUILD_WITH_ANDROID_ONLY.md`. The included GitHub Actions workflow runs core tests and uses an Xcode 27 cloud macOS runner to build the simulator and unsigned device targets.

## Signing and IPA

An unsigned build is not installable on a physical iPhone. To distribute to the owner's iPhone without a Mac, configure Apple signing in the cloud build environment. TestFlight distribution requires Apple Developer Program membership and App Store Connect configuration. Do not place Apple passwords, 2FA codes, private keys or certificates in source files.

## Compatibility

- App deployment target: iOS 27.0 (the supplied target device is iPhone 13 Pro Max on iOS 27.2.1).
- iPhone 13 Pro Max has no Dynamic Island; Live Activity is presented on the Lock Screen.
- Android-style always-on floating overlay is not available to ordinary iOS apps. The iOS replacement is the native in-app dashboard plus Live Activity.


## Build status and limits

- Portable Swift core: **33 tests pass** on Swift 6.2/Linux.
- iOS app and Live Activity source: syntax-parsed locally; Apple framework type-checking and linking still require Xcode on macOS.
- PSGC asset: **21,330 records**; unique codes and parent links validated.
- iPhone 13 Pro Max / iOS 27.2.1: target test device supplied by the user; no physical-device run has occurred yet.
- No signed IPA is included. The cloud workflow builds unsigned iOS device and simulator products; signing/distribution requires the user's own Apple signing setup.

The uploaded Android archive contains a stale 3.0.0 validation report despite its 3.1.0 Gradle version and release notes. See `docs/ANDROID_SOURCE_AUDIT.md`.


## Booking history and accepted reference policy

- Rolling local history retention: 7 days.
- Maximum queried/retained booking records: **1,500** (newest observations first).
- Reappearing records preserve their original `firstSeen` and increment `seenCount`; a resurfaced booking is not silently treated as a new offer.
- The first accepted booking is saved as the protected reference. Later accepted bookings do not overwrite it. The driver can explicitly replace or clear the reference.
- Acceptance detection requires multiple explicit post-acceptance screen markers (for example `Pick Up At`, `Call Customer`, and/or `Proof of delivery required at dropoff`), plus a complete booking extraction and fare. A swipe gesture or an available booking card alone is not proof of acceptance.
- When possible, the accepted screen is matched to the pre-acceptance card by booking code. If no code is available, a unique composite match uses fare, endpoints, and vehicle agreement. Ambiguous matches remain unmatched for driver verification.
