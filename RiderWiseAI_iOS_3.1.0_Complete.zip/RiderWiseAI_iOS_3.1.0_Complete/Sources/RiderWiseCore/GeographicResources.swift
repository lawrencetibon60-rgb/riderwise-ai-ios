import Foundation

/// Stable bundle token so the iOS app can load data packaged in the RiderWiseCore framework.
public final class RiderWiseBundleToken: NSObject {}
public enum GeographicResources {
    public static func loadCentroids(bundle:Bundle = Bundle(for:RiderWiseBundleToken.self)) throws -> CentroidResolver {
        try CentroidResolver(bundle:bundle)
    }
    public static func loadPSGC(bundle:Bundle = Bundle(for:RiderWiseBundleToken.self)) throws -> PSGCResolver {
        try PSGCResolver(bundle:bundle)
    }
}
