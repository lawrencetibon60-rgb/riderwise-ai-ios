import Foundation

public struct PickupHotspot:Sendable,Identifiable {
    public let id:String
    public let name:String
    public let observations:Int
    public let hasApproximateCentroid:Bool
    public let basis:String
}
public struct GeographicActivitySummary:Sendable {
    public let bookingCount:Int
    public let pickupObservations:Int
    public let dropoffObservations:Int
    public let unresolvedPickupCount:Int
    public let hotspots:[PickupHotspot]
    public let disclaimer:String
}
public enum GeographicIntelligence {
    /// Describes observed historical pickup frequency only. It is not demand forecasting,
    /// an availability feed, or proof that a locality has more current bookings.
    public static func analyze(bookings:[Booking],centroids:CentroidResolver?,psgc:PSGCResolver? = nil)->GeographicActivitySummary {
        var pickups:[String:(String,Int,Bool)]=[:]
        var pickupCount=0,dropCount=0,unresolved=0,valid=0
        for booking in bookings where booking.isComplete {
            valid += 1
            if let p=booking.pickup {
                pickupCount += 1
                let key=TextNormalization.normalize(p)
                let ambiguous:Bool
                if let psgc,case .ambiguous=psgc.resolve(p) { ambiguous=true } else { ambiguous=false }
                let mapped:Bool
                if !ambiguous,let centroids,case .unique(let record)=centroids.resolve(p) { mapped=record.point != nil } else { mapped=false }
                if !mapped { unresolved += 1 }
                let old=pickups[key] ?? (p,0,mapped)
                pickups[key]=(old.0,old.1+1,old.2 || mapped)
            }
            if booking.dropoff != nil { dropCount += 1 }
        }
        var hotspotValues:[PickupHotspot]=[]
        for item in pickups.values {
            let basis=item.2 ? "Approximate legacy centroid available; unverified" : "Text-only locality; geographic verification needed"
            let hotspot=PickupHotspot(id:TextNormalization.normalize(item.0),name:item.0,observations:item.1,hasApproximateCentroid:item.2,basis:basis)
            hotspotValues.append(hotspot)
        }
        hotspotValues.sort { lhs,rhs in
            if lhs.observations == rhs.observations { return lhs.name < rhs.name }
            return lhs.observations > rhs.observations
        }
        let topHotspots=Array(hotspotValues.prefix(8))
        return GeographicActivitySummary(bookingCount:valid,pickupObservations:pickupCount,dropoffObservations:dropCount,
            unresolvedPickupCount:unresolved,hotspots:topHotspots,
            disclaimer:"Historical OCR observations only. Not a live heatmap, demand forecast, road map, or booking availability signal.")
    }
}
