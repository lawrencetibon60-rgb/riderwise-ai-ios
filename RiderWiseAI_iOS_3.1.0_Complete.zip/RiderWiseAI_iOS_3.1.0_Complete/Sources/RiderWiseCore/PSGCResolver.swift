import Foundation

public struct PSGCRecord:Codable,Sendable,Hashable {
    public let psgc:String
    public let name:String
    public let level:String
    public let parentPsgc:String?
    public let oldNames:String?
    public let cityClass:String?
    public let incomeClassification:String?
    public let urbanRural:String?
    public let population2024:Int?
    public let status:String?
}
private struct PSGCFile:Codable { let source:String?; let publicationDate:String?; let scope:String?; let recordCount:Int; let note:String?; let records:[PSGCRecord] }
public enum PSGCResolution:Sendable { case unique(PSGCRecord); case ambiguous([PSGCRecord]); case notFound }

/// Offline administrative-place resolver. It identifies administrative names and hierarchy;
/// it does not provide street geocoding, barangay polygons, road distance, or ETA.
public final class PSGCResolver: @unchecked Sendable {
    private let records:[PSGCRecord]
    private let byCode:[String:PSGCRecord]
    private let byName:[String:[PSGCRecord]]
    public init(data:Data) throws {
        let file=try JSONDecoder().decode(PSGCFile.self,from:data)
        records=file.records; byCode=Dictionary(uniqueKeysWithValues:file.records.map{($0.psgc,$0)})
        var map:[String:[PSGCRecord]]=[:]
        for r in file.records {
            map[TextNormalization.normalize(r.name),default:[]].append(r)
            for alias in r.oldNames?.split(separator:"|").map(String.init) ?? [] { map[TextNormalization.normalize(alias),default:[]].append(r) }
        }
        byName=map
    }
    public convenience init(bundle:Bundle = .main) throws {
        guard let url=bundle.url(forResource:"luzon_psgc_3q_2026",withExtension:"json") else { throw NSError(domain:"PSGCResolver",code:1,userInfo:[NSLocalizedDescriptionKey:"PSGC data asset missing"]) }
        try self.init(data:Data(contentsOf:url))
    }
    public func resolve(_ name:String)->PSGCResolution { resolve(name,parentHint:nil) }
    public func resolve(_ name:String,parentHint:String?)->PSGCResolution {
        let q=TextNormalization.normalize(name)
        guard !q.isEmpty,let hits=byName[q],!hits.isEmpty else{return .notFound}
        if let hint=parentHint, !TextNormalization.normalize(hint).isEmpty {
            let h=TextNormalization.normalize(hint)
            let narrowed=hits.filter { record in
                hierarchy(record).contains { TextNormalization.normalize($0.name)==h }
            }
            if narrowed.count==1,let r=narrowed.first{return .unique(r)}
            if narrowed.count>1{return .ambiguous(narrowed)}
        }
        if hits.count==1,let first=hits.first{return .unique(first)}
        return .ambiguous(hits)
    }
    public func resolveFromAddress(_ address:String)->PSGCResolution {
        let n=TextNormalization.normalize(address)
        guard !n.isEmpty else{return .notFound}
        let matches=records.filter { r in
            let key=TextNormalization.normalize(r.name)
            return key.count>=4 && (n==key || n.contains(" "+key) || n.hasPrefix(key+" "))
        }
        guard !matches.isEmpty else{return .notFound}
        // Prefer the most specific named locality in the address, then use visible parent
        // province/city tokens to disambiguate repeated barangay/municipality names.
        let maxLength=matches.map{TextNormalization.normalize($0.name).count}.max() ?? 0
        let longest=matches.filter{TextNormalization.normalize($0.name).count==maxLength}
        let contextual=longest.map { record -> (PSGCRecord,Int) in
            let ancestors=hierarchy(record).dropFirst()
            let score=ancestors.filter{n.contains(TextNormalization.normalize($0.name))}.count
            return (record,score)
        }
        let maxScore=contextual.map{$0.1}.max() ?? 0
        let best=contextual.filter{$0.1==maxScore}.map{$0.0}
        if best.count==1,let r=best.first{return .unique(r)}
        return .ambiguous(best)
    }
    public func findAllByName(_ name:String)->[PSGCRecord] { byName[TextNormalization.normalize(name)] ?? [] }
    public func record(psgc:String)->PSGCRecord? { byCode[psgc] }
    public func hierarchy(_ record:PSGCRecord)->[PSGCRecord] {
        var result=[record], cursor=record, seen:Set<String>=[record.psgc]
        while let parent=cursor.parentPsgc, let p=byCode[parent], seen.insert(p.psgc).inserted { result.append(p); cursor=p }
        return result
    }
    public func children(of psgc:String)->[PSGCRecord] { records.filter{$0.parentPsgc==psgc} }
    public var recordCount:Int { records.count }
}
