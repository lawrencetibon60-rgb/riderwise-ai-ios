import ActivityKit
import Foundation
import Combine
import RiderWiseCore

@MainActor
final class LiveActivityManager: ObservableObject {
    @Published private(set) var status = "Live Activity is ready for the Lock Screen."
    private var currentID: String?

    func beginScanning(reference: Booking?, recommendations: [Recommendation], scanIsActive: Bool) {
        sync(reference: reference, recommendations: recommendations, scanIsActive: scanIsActive, keepAliveWithoutReference: true)
    }

    func sync(reference: Booking?, recommendationCount: Int) {
        sync(reference: reference, recommendations: [], scanIsActive: false, keepAliveWithoutReference: false, fallbackCount: recommendationCount)
    }

    func sync(reference: Booking?, recommendations: [Recommendation], scanIsActive: Bool, keepAliveWithoutReference: Bool = true, fallbackCount: Int? = nil) {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            status = "Enable Live Activities in iPhone Settings → RiderWise AI."
            return
        }
        guard reference != nil || keepAliveWithoutReference else { end(); return }

        let best = recommendations.first
        let state = RiderWiseActivityAttributes.ContentState(
            pickup: reference.map { $0.pickupFullAddress ?? $0.pickup ?? "Pickup pending" } ?? "Waiting for accepted booking",
            dropoff: reference.map { $0.dropoffFullAddress ?? $0.dropoff ?? "Drop-off pending" } ?? "Start Lalamove broadcast",
            fare: reference?.fare.map { String(format: "₱%.2f", $0) } ?? "—",
            recommendationCount: fallbackCount ?? recommendations.count,
            bestRecommendation: best?.label ?? "No compatible booking yet",
            recommendationFare: best.map { String(format: "₱%.2f", $0.totalFare) } ?? "—",
            recommendationScore: best.map { String(format: "%.0f%%", $0.score * 100) } ?? "—",
            recommendationStatus: best.map { $0.requiresVerification ? "VERIFY ADDRESS" : $0.availability.replacingOccurrences(of: "_", with: " ") } ?? "Waiting for booking data",
            scanStatus: scanIsActive ? "LIVE SCAN · user-authorized broadcast" : "Broadcast not confirmed active",
            status: scanIsActive ? "SCANNING" : (reference == nil ? "READY" : "REFERENCE ACTIVE")
        )

        let content = ActivityContent(state: state, staleDate: .now.addingTimeInterval(60 * 60))
        if let active = Activity<RiderWiseActivityAttributes>.activities.first {
            currentID = active.id
            Task { await active.update(content) }
            status = "Live Activity updated. Latest data: \(state.status)."
            return
        }
        do {
            let activity = try Activity.request(attributes: RiderWiseActivityAttributes(), content: content, pushType: nil)
            currentID = activity.id
            status = "RiderWise Live Activity started on the Lock Screen."
        } catch {
            status = "Live Activity could not start: \(error.localizedDescription)"
        }
    }

    func end() {
        let activities = Activity<RiderWiseActivityAttributes>.activities
        Task { for activity in activities { await activity.end(nil, dismissalPolicy: .immediate) } }
        currentID = nil
        status = "No active RiderWise Live Activity."
    }
}
