import ActivityKit
import Foundation
import Combine
import RiderWiseCore

@MainActor final class LiveActivityManager:ObservableObject {
    @Published private(set) var status="Live Activity is available for the active reference on the Lock Screen."
    private var currentID:String?

    func sync(reference:Booking?,recommendationCount:Int) {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            status="Live Activities are disabled in iOS settings."; return
        }
        guard let reference else { end(); return }
        let state=RiderWiseActivityAttributes.ContentState(
            pickup:reference.pickupFullAddress ?? reference.pickup ?? "Pickup pending",
            dropoff:reference.dropoffFullAddress ?? reference.dropoff ?? "Drop-off pending",
            fare:reference.fare.map{String(format:"₱%.2f",$0)} ?? "Fare pending",
            recommendationCount:recommendationCount,status:reference.status.rawValue.uppercased())
        if let active=Activity<RiderWiseActivityAttributes>.activities.first {
            currentID=active.id
            Task { await active.update(ActivityContent(state:state,staleDate:nil)) }
            status="Live Activity updated on the Lock Screen."
            return
        }
        do {
            let activity=try Activity.request(attributes:RiderWiseActivityAttributes(),content:ActivityContent(state:state,staleDate:nil),pushType:nil)
            currentID=activity.id
            status="Live Activity started on the Lock Screen."
        } catch {
            status="Live Activity could not start: \(error.localizedDescription)"
        }
    }

    func end() {
        let activities=Activity<RiderWiseActivityAttributes>.activities
        Task {
            for activity in activities { await activity.end(nil,dismissalPolicy:.immediate) }
        }
        currentID=nil
        status="No active reference Live Activity."
    }
}
