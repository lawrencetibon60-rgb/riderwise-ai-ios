import ActivityKit
import Foundation

public struct RiderWiseActivityAttributes:ActivityAttributes {
    public struct ContentState:Codable,Hashable {
        public var pickup:String
        public var dropoff:String
        public var fare:String
        public var recommendationCount:Int
        public var status:String
        public var updatedAt:Date
        public init(pickup:String,dropoff:String,fare:String,recommendationCount:Int,status:String,updatedAt:Date = .now) {
            self.pickup=pickup; self.dropoff=dropoff; self.fare=fare
            self.recommendationCount=recommendationCount; self.status=status; self.updatedAt=updatedAt
        }
    }
    public var title:String
    public init(title:String="RiderWise active booking") { self.title=title }
}
