import ActivityKit
import Foundation

/// Lock Screen Live Activity state. iPhone 13 Pro Max displays the Lock Screen
/// presentation; Dynamic Island regions are available only on supported models.
public struct RiderWiseActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        public var pickup: String
        public var dropoff: String
        public var fare: String
        public var recommendationCount: Int
        public var bestRecommendation: String
        public var recommendationFare: String
        public var recommendationScore: String
        public var recommendationStatus: String
        public var scanStatus: String
        public var status: String
        public var updatedAt: Date

        public init(
            pickup: String = "Waiting for accepted booking",
            dropoff: String = "Start Lalamove broadcast",
            fare: String = "—",
            recommendationCount: Int = 0,
            bestRecommendation: String = "No recommendation yet",
            recommendationFare: String = "—",
            recommendationScore: String = "—",
            recommendationStatus: String = "Waiting for booking data",
            scanStatus: String = "Broadcast not started",
            status: String = "READY",
            updatedAt: Date = .now
        ) {
            self.pickup = pickup
            self.dropoff = dropoff
            self.fare = fare
            self.recommendationCount = recommendationCount
            self.bestRecommendation = bestRecommendation
            self.recommendationFare = recommendationFare
            self.recommendationScore = recommendationScore
            self.recommendationStatus = recommendationStatus
            self.scanStatus = scanStatus
            self.status = status
            self.updatedAt = updatedAt
        }
    }

    public var title: String
    public init(title: String = "RiderWise AI · Lalamove") { self.title = title }
}
