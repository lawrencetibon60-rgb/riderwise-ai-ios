import Foundation
import Combine
@preconcurrency import ScreenCaptureKit
import CoreMedia
import CoreImage
import CoreVideo
import UIKit

/// iOS 27+ user-authorized screen capture. The system picker controls what is shared.
/// Frames are sampled at the configured interval; no Lalamove UI action is automated.
@MainActor final class ScreenCaptureManager: NSObject, ObservableObject, SCContentSharingPickerObserver, SCStreamDelegate {
    @Published private(set) var isCapturing = false
    @Published private(set) var status = "Screen capture is off. Start only when you want to share your screen."
    @Published var scanInterval: TimeInterval = 2.5 { didSet { output.interval = scanInterval } }
    var onFrame: ((UIImage) -> Void)?

    private var stream: SCStream?
    private let output = RiderWiseFrameOutput()
    private var registered = false

    func presentSystemPicker() {
        guard SCContentSharingPicker.shared.isAvailable else {
            status = "System screen sharing is unavailable on this device or OS build. Use screenshot import instead."
            return
        }
        if !registered {
            SCContentSharingPicker.shared.add(self)
            registered = true
        }
        var pickerConfiguration=SCContentSharingPicker.shared.defaultConfiguration
        pickerConfiguration.allowedPickerModes = .singleDisplay
        pickerConfiguration.allowsChangingSelectedContent = true
        SCContentSharingPicker.shared.defaultConfiguration = pickerConfiguration
        SCContentSharingPicker.shared.isActive = true
        status = "Choose the full display in Apple's screen-sharing picker, then switch to Lalamove."
        SCContentSharingPicker.shared.present()
    }

    func stop() {
        guard let active = stream else {
            isCapturing = false
            status = "Screen capture is off."
            SCContentSharingPicker.shared.isActive = false
            if registered { SCContentSharingPicker.shared.remove(self); registered=false }
            return
        }
        active.stopCapture { [weak self] error in
            Task { @MainActor in
                guard let self else { return }
                self.stream = nil
                self.isCapturing = false
                self.status = error.map { "Capture stopped: \($0.localizedDescription)" } ?? "Screen capture stopped."
                SCContentSharingPicker.shared.isActive = false
                if self.registered { SCContentSharingPicker.shared.remove(self); self.registered=false }
            }
        }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didUpdateWith filter: SCContentFilter, for suppliedStream: SCStream?) {
        Task { @MainActor [weak self] in
            await self?.configure(filter: filter)
        }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didCancelFor suppliedStream: SCStream?) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            if suppliedStream == nil {
                self.status = "Screen sharing selection cancelled. Screenshot import remains available."
                SCContentSharingPicker.shared.isActive = false
                if self.registered { SCContentSharingPicker.shared.remove(self); self.registered=false }
            }
        }
    }

    nonisolated func contentSharingPickerStartDidFailWithError(_ error: Error) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            self.status = "Screen sharing could not start: \(error.localizedDescription)"
            SCContentSharingPicker.shared.isActive = false
            if self.registered { SCContentSharingPicker.shared.remove(self); self.registered=false }
        }
    }

    nonisolated func stream(_ stream: SCStream, didStopWithError error: Error) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            self.stream = nil
            self.isCapturing = false
            self.status = "Screen capture ended: \(error.localizedDescription). Import screenshots if needed."
            SCContentSharingPicker.shared.isActive = false
            if self.registered { SCContentSharingPicker.shared.remove(self); self.registered=false }
        }
    }

    private func configure(filter: SCContentFilter) async {
        if let active=stream {
            do {
                try await active.updateContentFilter(filter)
                status = "Screen sharing selection updated."
                isCapturing = true
            } catch {
                status = "Could not update screen-sharing selection: \(error.localizedDescription)"
            }
            return
        }

        let configuration = SCStreamConfiguration()
        configuration.width = 1284
        configuration.height = 2778
        configuration.minimumFrameInterval = CMTime(value: 1, timescale: 30)
        configuration.queueDepth = 3
        configuration.capturesAudio = false

        let newStream = SCStream(filter: filter, configuration: configuration, delegate: self)
        do {
            try newStream.addStreamOutput(output, type: .screen, sampleHandlerQueue: DispatchQueue(label: "ph.riderwise.capture.frames", qos: .userInitiated))
            output.interval = scanInterval
            output.onImage = { [weak self] image in
                DispatchQueue.main.async {
                    guard let self, self.isCapturing else { return }
                    self.onFrame?(image)
                }
            }
            stream = newStream
            try await newStream.startCapture()
            isCapturing = true
            status = String(format: "Screen capture is active. OCR samples are processed every %.1f seconds on-device.", scanInterval)
        } catch {
            stream = nil
            isCapturing = false
            status = "Screen capture failed: \(error.localizedDescription). Screenshot import remains available."
            SCContentSharingPicker.shared.isActive = false
            if registered { SCContentSharingPicker.shared.remove(self); registered=false }
        }
    }
}

private final class RiderWiseFrameOutput: NSObject, SCStreamOutput {
    var interval: TimeInterval = 2.5
    var onImage: ((UIImage) -> Void)?
    private let lock = NSLock()
    private var lastFrameTime: TimeInterval = 0
    private var lastFingerprint: UInt64?
    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])

    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .screen, CMSampleBufferIsValid(sampleBuffer),
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let now = ProcessInfo.processInfo.systemUptime
        lock.lock()
        let shouldProcess = now - lastFrameTime >= max(1.0, interval)
        if shouldProcess { lastFrameTime = now }
        lock.unlock()
        guard shouldProcess else { return }
        guard let fingerprint = Self.quickFingerprint(pixelBuffer) else { return }
        lock.lock()
        let unchanged = lastFingerprint == fingerprint
        if !unchanged { lastFingerprint = fingerprint }
        lock.unlock()
        guard !unchanged else { return }

        let image = CIImage(cvPixelBuffer: pixelBuffer)
        guard let cgImage = ciContext.createCGImage(image, from: image.extent) else { return }
        onImage?(UIImage(cgImage: cgImage))
    }

    private static func quickFingerprint(_ pixelBuffer:CVPixelBuffer)->UInt64? {
        CVPixelBufferLockBaseAddress(pixelBuffer,.readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer,.readOnly) }
        let width=CVPixelBufferGetWidth(pixelBuffer),height=CVPixelBufferGetHeight(pixelBuffer)
        guard width>0,height>0 else{return nil}
        let base:UnsafeMutableRawPointer?
        let bytesPerRow:Int
        if CVPixelBufferIsPlanar(pixelBuffer) {
            base=CVPixelBufferGetBaseAddressOfPlane(pixelBuffer,0)
            bytesPerRow=CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer,0)
        } else {
            base=CVPixelBufferGetBaseAddress(pixelBuffer)
            bytesPerRow=CVPixelBufferGetBytesPerRow(pixelBuffer)
        }
        guard let base else{return nil}
        let bytes=base.assumingMemoryBound(to:UInt8.self)
        var hash:UInt64=1469598103934665603
        // A 16x16 luma/sample grid is a cheap debounce, not a cryptographic identity check.
        for row in 0..<16 {
            let y=min(height-1,row*height/16)
            for col in 0..<16 {
                let x=min(width-1,col*width/16)
                let value=bytes[y*bytesPerRow+x]
                hash ^= UInt64(value)
                hash = hash &* 1099511628211
            }
        }
        return hash
    }
}
