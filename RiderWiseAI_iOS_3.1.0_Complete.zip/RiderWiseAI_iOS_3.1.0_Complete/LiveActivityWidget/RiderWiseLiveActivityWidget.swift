import ActivityKit
import SwiftUI
import WidgetKit

struct RiderWiseLiveActivityWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: RiderWiseActivityAttributes.self) { context in
            lockScreenView(context: context)
                .activityBackgroundTint(Color.black.opacity(0.88))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: "bicycle").font(.title2).foregroundStyle(.green)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(context.state.recommendationFare).font(.caption.bold())
                        Text(context.state.recommendationScore).font(.caption2).foregroundStyle(.secondary)
                    }
                }
                DynamicIslandExpandedRegion(.center) {
                    Text(context.state.status).font(.caption.bold())
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 5) {
                        Label(context.state.scanStatus, systemImage: "dot.radiowaves.left.and.right").font(.caption2).foregroundStyle(.green)
                        Text(context.state.bestRecommendation).font(.subheadline.bold()).lineLimit(2)
                        Text(context.state.recommendationStatus).font(.caption2).foregroundStyle(.secondary)
                        Text("Pickup: \(context.state.pickup)").lineLimit(1)
                        Text("Drop-off: \(context.state.dropoff)").lineLimit(1)
                        Text("\(context.state.recommendationCount) suggestions").font(.caption2).foregroundStyle(.secondary)
                    }.font(.caption)
                }
            } compactLeading: {
                Image(systemName: "bicycle").foregroundStyle(.green)
            } compactTrailing: {
                Text(context.state.recommendationFare.replacingOccurrences(of: "₱", with: "")).font(.caption2.bold())
            } minimal: {
                Image(systemName: "bicycle")
            }
        }
    }

    @ViewBuilder
    private func lockScreenView(context: ActivityViewContext<RiderWiseActivityAttributes>) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Label("RiderWise AI", systemImage: "bicycle").font(.headline)
                Spacer()
                Text(context.state.status).font(.caption2.bold()).foregroundStyle(context.state.status == "SCANNING" ? .green : .secondary)
            }
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("ACCEPTED BOOKING").font(.caption2.bold()).foregroundStyle(.secondary)
                    Text(context.state.pickup).font(.caption).lineLimit(1)
                    Text("↓ \(context.state.dropoff)").font(.caption).lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(context.state.fare).font(.headline)
            }
            Divider().overlay(.white.opacity(0.2))
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("BEST COMPATIBLE OFFER").font(.caption2.bold()).foregroundStyle(.green)
                    Text(context.state.bestRecommendation).font(.subheadline.bold()).lineLimit(2)
                    Text(context.state.recommendationStatus).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                VStack(alignment: .trailing, spacing: 3) {
                    Text(context.state.recommendationFare).font(.headline)
                    Text(context.state.recommendationScore).font(.caption2).foregroundStyle(.secondary)
                }
            }
            HStack {
                Label(context.state.scanStatus, systemImage: "dot.radiowaves.left.and.right").font(.caption2).foregroundStyle(.green)
                Spacer()
                Text("\(context.state.recommendationCount) suggestions").font(.caption2).foregroundStyle(.secondary)
            }
        }
        .foregroundStyle(.white)
        .padding(.vertical, 7)
        .padding(.horizontal, 4)
    }
}

@main
struct RiderWiseLiveActivityWidgetBundle: WidgetBundle {
    var body: some Widget { RiderWiseLiveActivityWidget() }
}
