import ActivityKit
import SwiftUI
import WidgetKit

struct RiderWiseLiveActivityWidget:Widget {
    var body:some WidgetConfiguration {
        ActivityConfiguration(for:RiderWiseActivityAttributes.self) { context in
            VStack(alignment:.leading,spacing:7) {
                HStack { Label("RiderWise · Active reference",systemImage:"bicycle").font(.headline); Spacer(); Text(context.state.fare).font(.headline) }
                Text("Pickup: \(context.state.pickup)").font(.caption).lineLimit(1)
                Text("Drop-off: \(context.state.dropoff)").font(.caption).lineLimit(1)
                HStack { Text(context.state.status); Spacer(); Text("\(context.state.recommendationCount) suggestions") }
                    .font(.caption2).foregroundStyle(.secondary)
            }.padding()
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) { Image(systemName:"bicycle").font(.title2) }
                DynamicIslandExpandedRegion(.trailing) { Text(context.state.fare).font(.caption.bold()) }
                DynamicIslandExpandedRegion(.center) { Text(context.state.status).font(.caption) }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment:.leading) {
                        Text("Pickup: \(context.state.pickup)").lineLimit(1)
                        Text("Drop-off: \(context.state.dropoff)").lineLimit(1)
                        Text("\(context.state.recommendationCount) suggestions").font(.caption2)
                    }.font(.caption)
                }
            } compactLeading: {
                Image(systemName:"bicycle")
            } compactTrailing: {
                Text(context.state.fare.replacingOccurrences(of:"₱",with:""))
            } minimal: {
                Image(systemName:"bicycle")
            }
        }
    }
}

@main struct RiderWiseLiveActivityWidgetBundle:WidgetBundle {
    var body:some Widget { RiderWiseLiveActivityWidget() }
}
