#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test
for f in iOSApp/*.swift LiveActivityWidget/*.swift Sources/RiderWiseCore/*.swift; do
  swiftc -frontend -parse "$f" >/dev/null
done
python3 - <<'PY'
import gzip, json, pathlib, plistlib, collections
root=pathlib.Path('.')
plistlib.loads((root/'iOSApp/Info.plist').read_bytes())
with gzip.open(root/'Sources/RiderWiseCore/luzon_psgc_3q_2026.json.gz','rt',encoding='utf-8') as f:
    data=json.load(f)
records=data['records']
codes={r['psgc'] for r in records}
counts=collections.Counter(r['level'] for r in records)
assert len(records)==21330 and len(codes)==len(records)
assert dict(counts)=={'Reg':8,'Prov':38,'City':77,'Mun':694,'SubMun':14,'Bgy':20499}
assert all(not r.get('parentPsgc') or r['parentPsgc'] in codes for r in records)
print('Info.plist: PASS')
print('PSGC dataset: PASS (21,330 records, unique codes, valid parent links)')
PY
