import Foundation
import Combine
import SwiftUI
import ReplayKit
import RiderWiseCore

/// Starts Apple's user-approved ReplayKit broadcast extension. iOS displays its own
/// broadcast confirmation UI; the app never captures another app's screen silently.
@MainActor final class ScreenCaptureManager: ObservableObject {
    @Published private(set) var isCapturing = false
    @Published private(set) var status = "Screen broadcast is off. Tap Start and approve the iOS broadcast prompt."
    @Published var scanInterval: TimeInterval = 2.5 {
        didSet { writeScanInterval() }
    }
    @Published var showBroadcastPicker = false
    var onOCRLines: (([OCRLine]) async -> Void)?

    private let appGroup = "group.ph.riderwise.ai"
    private var pollTask: Task<Void, Never>?
    private var lastPayloadID = ""

    func presentSystemPicker() {
        showBroadcastPicker = true
        status = "Tap Start Broadcast in Apple's system panel, then switch to Lalamove. You remain in control of screen sharing."
    }

    func pickerPresented() { startPolling() }

    func stop() {
        // ReplayKit broadcasts are stopped using Apple's system broadcast control.
        status = "To stop sharing, open the iOS Screen Broadcast control and tap Stop Broadcast."
    }

    private func writeScanInterval() {
        guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroup) else { return }
        let url = container.appendingPathComponent("scan-interval.json")
        let data = try? JSONEncoder().encode(ScanInterval(value: scanInterval))
        if let data { try? data.write(to: url, options: .atomic) }
    }

    private func startPolling() {
        guard pollTask == nil else { return }
        pollTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let self else { break }
                await self.readLatestFrame()
                try? await Task.sleep(for: .seconds(1))
            }
        }
    }

    private func readLatestFrame() async {
        guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroup) else {
            status = "App Group is not available. The app's App Group entitlement must be enabled before broadcast can exchange OCR data."
            return
        }
        let statusURL = container.appendingPathComponent("broadcast-status.json")
        if let data = try? Data(contentsOf: statusURL),
           let state = try? JSONDecoder().decode(BroadcastStatus.self, from: data) {
            isCapturing = state.active
            if state.active {
                status = String(format: "User-authorized Lalamove broadcast active · on-device OCR every %.1f seconds", scanInterval)
            } else if !state.message.isEmpty {
                status = state.message
            }
        }
        let frameURL = container.appendingPathComponent("ocr-queue.json")
        guard let data = try? Data(contentsOf: frameURL),
              let payloads = try? JSONDecoder().decode([BroadcastOCRPayload].self, from: data) else { return }
        for payload in payloads {
            guard payload.id != lastPayloadID else { continue }
            lastPayloadID = payload.id
            if !payload.lines.isEmpty { await onOCRLines?(payload.lines) }
        }
    }
}

private struct ScanInterval: Codable { let value: TimeInterval }
private struct BroadcastStatus: Decodable {
    let active: Bool
    let message: String
}
private struct BroadcastOCRPayload: Decodable {
    let id: String
    let lines: [OCRLine]
}

struct RiderWiseBroadcastPicker: UIViewRepresentable {
    let onReady: () -> Void
    func makeUIView(context: Context) -> RPSystemBroadcastPickerView {
        let picker = RPSystemBroadcastPickerView(frame: .zero)
        picker.preferredExtension = "ph.riderwise.ai.broadcast"
        picker.showsMicrophoneButton = false
        DispatchQueue.main.async { onReady() }
        return picker
    }
    func updateUIView(_ uiView: RPSystemBroadcastPickerView, context: Context) {}
}
