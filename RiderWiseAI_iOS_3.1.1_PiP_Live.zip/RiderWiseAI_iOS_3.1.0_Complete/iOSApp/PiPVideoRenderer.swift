import AVFoundation
import AVKit
import CoreMedia
import CoreVideo
import SwiftUI
import UIKit

/// Renders RiderWise's own dashboard into Apple's native PiP surface.
/// It does not mirror or draw over another app's screen.
@MainActor
final class PiPVideoRenderer: NSObject, ObservableObject {
    @Published private(set) var isSupported = AVPictureInPictureController.isPictureInPictureSupported()
    @Published private(set) var isActive = false
    @Published private(set) var status = "PiP is ready when supported."

    private let displayLayer = AVSampleBufferDisplayLayer()
    private var controller: AVPictureInPictureController?

    override init() {
        super.init()
        displayLayer.videoGravity = .resizeAspect
        displayLayer.backgroundColor = UIColor.black.cgColor
        configureController()
    }

    func start(image: UIImage) {
        guard isSupported, let controller else {
            status = "Picture in Picture is unavailable on this device or could not initialize."
            return
        }
        enqueue(image)
        if !controller.isPictureInPictureActive {
            controller.startPictureInPicture()
            status = "Starting RiderWise PiP…"
        }
    }

    func update(image: UIImage) {
        guard isSupported else { return }
        enqueue(image)
    }

    func stop() {
        controller?.stopPictureInPicture()
    }

    private func configureController() {
        guard isSupported else { return }
        let source = AVPictureInPictureController.ContentSource(
            sampleBufferDisplayLayer: displayLayer,
            playbackDelegate: self
        )
        let pip = AVPictureInPictureController(contentSource: source)
        pip.delegate = self
        pip.requiresLinearPlayback = true
        pip.canStartPictureInPictureAutomaticallyFromInline = false
        controller = pip
    }

    private func enqueue(_ image: UIImage) {
        guard let cgImage = image.cgImage,
              let pixelBuffer = makePixelBuffer(cgImage) else {
            status = "Could not render the PiP dashboard frame."
            return
        }
        var format: CMVideoFormatDescription?
        guard CMVideoFormatDescriptionCreateForImageBuffer(
            allocator: kCFAllocatorDefault,
            imageBuffer: pixelBuffer,
            formatDescriptionOut: &format
        ) == noErr, let format else { return }

        let timing = CMSampleTimingInfo(
            duration: CMTime(value: 1, timescale: 2),
            presentationTimeStamp: CMClockGetTime(CMClockGetHostTimeClock()),
            decodeTimeStamp: .invalid
        )
        var sample: CMSampleBuffer?
        guard CMSampleBufferCreateReadyWithImageBuffer(
            allocator: kCFAllocatorDefault,
            imageBuffer: pixelBuffer,
            formatDescription: format,
            sampleTiming: &timing,
            sampleBufferOut: &sample
        ) == noErr, let sample else {
            status = "Could not prepare PiP video frame."
            return
        }
        if displayLayer.status == .failed { displayLayer.flush() }
        displayLayer.enqueue(sample)
    }

    private func makePixelBuffer(_ cgImage: CGImage) -> CVPixelBuffer? {
        let width = 640, height = 360
        let attrs: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]
        var output: CVPixelBuffer?
        guard CVPixelBufferCreate(
            kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
            attrs as CFDictionary, &output
        ) == kCVReturnSuccess, let buffer = output else { return nil }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width, height: height, bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue |
                CGBitmapInfo.byteOrder32Little.rawValue
        ) else { return nil }
        context.interpolationQuality = .high
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        return buffer
    }

    static func makeDashboardFrame(
        reference: String,
        topRecommendation: String,
        detail: String,
        count: Int,
        scanning: Bool
    ) -> UIImage {
        let size = CGSize(width: 640, height: 360)
        return UIGraphicsImageRenderer(size: size).image { renderer in
            let c = renderer.cgContext
            c.setFillColor(UIColor(red: 0.055, green: 0.075, blue: 0.11, alpha: 1).cgColor)
            c.fill(CGRect(origin: .zero, size: size))

            func text(_ value: String, _ rect: CGRect, _ font: UIFont, _ color: UIColor) {
                (value as NSString).draw(in: rect, withAttributes: [
                    .font: font, .foregroundColor: color,
                    .paragraphStyle: {
                        let p = NSMutableParagraphStyle()
                        p.lineBreakMode = .byTruncatingTail
                        return p
                    }()
                ])
            }

            text("RIDERWISE AI", CGRect(x: 28, y: 22, width: 350, height: 30),
                 .boldSystemFont(ofSize: 22), .white)
            text(scanning ? "LIVE OCR" : "SCAN PAUSED",
                 CGRect(x: 470, y: 26, width: 145, height: 22),
                 .boldSystemFont(ofSize: 13), scanning ? .systemGreen : .systemOrange)

            c.setFillColor(UIColor(white: 1, alpha: 0.08).cgColor)
            c.fill(CGRect(x: 24, y: 70, width: 592, height: 76))
            text("ACCEPTED REFERENCE", CGRect(x: 42, y: 83, width: 300, height: 18),
                 .boldSystemFont(ofSize: 12), .systemTeal)
            text(reference.isEmpty ? "No accepted booking selected" : reference,
                 CGRect(x: 42, y: 105, width: 550, height: 28),
                 .boldSystemFont(ofSize: 18), .white)

            c.setFillColor(UIColor(red: 0.10, green: 0.27, blue: 0.22, alpha: 1).cgColor)
            c.fill(CGRect(x: 24, y: 164, width: 592, height: 112))
            text("TOP RECOMMENDATION", CGRect(x: 42, y: 178, width: 340, height: 18),
                 .boldSystemFont(ofSize: 12), .systemGreen)
            text(topRecommendation.isEmpty ? "Waiting for compatible bookings" : topRecommendation,
                 CGRect(x: 42, y: 205, width: 550, height: 30),
                 .boldSystemFont(ofSize: 21), .white)
            text(detail.isEmpty ? "New OCR results refresh this dashboard." : detail,
                 CGRect(x: 42, y: 240, width: 550, height: 24),
                 .systemFont(ofSize: 13), UIColor(white: 0.83, alpha: 1))
            text("\(count) recommendation(s) · Driver confirms every booking",
                 CGRect(x: 28, y: 312, width: 584, height: 22),
                 .systemFont(ofSize: 13), UIColor(white: 0.72, alpha: 1))
        }
    }
}

extension PiPVideoRenderer: AVPictureInPictureControllerDelegate {
    func pictureInPictureControllerDidStartPictureInPicture(_ controller: AVPictureInPictureController) {
        isActive = true
        status = "RiderWise PiP dashboard is active."
    }

    func pictureInPictureControllerDidStopPictureInPicture(_ controller: AVPictureInPictureController) {
        isActive = false
        status = "RiderWise PiP dashboard is closed."
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        failedToStartPictureInPictureWithError error: Error
    ) {
        isActive = false
        status = "PiP failed: \(error.localizedDescription)"
    }
}

extension PiPVideoRenderer: AVPictureInPictureSampleBufferPlaybackDelegate {
    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        setPlaying playing: Bool
    ) {}

    func pictureInPictureControllerIsPlaybackPaused(
        _ controller: AVPictureInPictureController
    ) -> Bool { false }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        timeRangeForPlayback: CMTimeRange
    ) -> CMTimeRange {
        CMTimeRange(start: .zero, duration: CMTime(value: 1, timescale: 1))
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        didTransitionToRenderSize newRenderSize: CMVideoDimensions
    ) {}

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        skipByInterval interval: CMTime,
        completion: @escaping () -> Void
    ) {
        completion()
    }
}
