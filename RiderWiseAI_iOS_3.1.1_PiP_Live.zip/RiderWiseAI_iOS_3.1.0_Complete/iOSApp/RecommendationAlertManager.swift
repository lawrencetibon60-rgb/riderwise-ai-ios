import Foundation
import Combine
import AudioToolbox
import AVFAudio

/// Plays a short local notification when a genuinely new recommendation appears.
/// This does not play continuous or fabricated audio to keep the app alive.
@MainActor final class RecommendationAlertManager: ObservableObject {
    @Published var isEnabled: Bool {
        didSet { UserDefaults.standard.set(isEnabled, forKey: "riderwise.recommendationSoundEnabled") }
    }
    @Published var speakRecommendation: Bool {
        didSet { UserDefaults.standard.set(speakRecommendation, forKey: "riderwise.speakRecommendation") }
    }
    private var announced = Set<String>()

    init() {
        isEnabled = UserDefaults.standard.object(forKey: "riderwise.recommendationSoundEnabled") as? Bool ?? true
        speakRecommendation = UserDefaults.standard.bool(forKey: "riderwise.speakRecommendation")
    }

    func prime(_ recommendations: [RiderWiseCore.Recommendation]) {
        announced = Set(recommendations.map(\.id))
    }

    func announceNewRecommendations(_ recommendations: [RiderWiseCore.Recommendation]) {
        let current = Set(recommendations.map(\.id))
        let fresh = recommendations.filter { !announced.contains($0.id) }
        announced.formUnion(current)
        announced.formIntersection(current)
        guard isEnabled, !fresh.isEmpty else { return }
        // System notification sound; no background-audio loophole or continuous playback.
        AudioServicesPlaySystemSound(1007)
    }

    func playTestSound() {
        guard isEnabled else { return }
        AudioServicesPlaySystemSound(1007)
    }
}
