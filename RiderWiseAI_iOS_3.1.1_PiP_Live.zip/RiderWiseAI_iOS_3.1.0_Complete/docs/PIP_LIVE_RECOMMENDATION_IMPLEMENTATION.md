# PiP live recommendation integration

## Implemented in source
- `iOSApp/PiPVideoRenderer.swift` creates a native `AVPictureInPictureController` using `AVSampleBufferDisplayLayer`.
- The renderer produces a compact 640x360 dashboard frame containing the selected accepted reference, best current recommendation, recommendation count and scan state.
- `DashboardView` exposes a manual Start/Stop PiP control. PiP is not started without an explicit user tap.
- `RiderWiseStore.ingestOCRLines` remains the live OCR entry point. The existing `ScreenCaptureManager` polls the App Group OCR queue and forwards new lines to this method.
- Changes to recommendations, selected reference and broadcast state refresh the PiP video frame.
- The PiP surface displays RiderWise-generated information only; it does not attempt to overlay or mirror Lalamove's screen.

## Platform constraints
- ReplayKit screen broadcast still requires the user to start Apple's system broadcast flow.
- PiP support and background behavior are controlled by iOS. Source implementation is not proof of successful device behavior.
- The renderer does not provide interactive booking controls inside the PiP window. Drivers must return to RiderWise/Lalamove and make all booking decisions themselves.

## Required validation
1. Build the app and all extensions with Xcode 27.
2. Install a signed build on iPhone 13 Pro Max.
3. Start PiP from RiderWise, switch to Lalamove, and confirm the PiP window remains visible.
4. Capture a screen containing multiple booking cards and confirm OCR results update the PiP recommendation title/detail/count.
5. Confirm reference protection when a second booking is accepted.
6. Stop PiP, stop the ReplayKit broadcast, interrupt with a phone call, and verify recovery/status messaging.
7. Measure update cadence, memory, thermal behavior and battery impact over a representative driving session.
