import XCTest
@testable import RiderWiseCore
final class CoreTests:XCTestCase {
    func testBookingFingerprintNormalizesCase() {
        XCTAssertEqual(Booking.fingerprint(pickup:"SAN MATEO",dropoff:"Commonwealth",fare:107,vehicle:"Motorcycle",bookingType:"Delivery"),
                       Booking.fingerprint(pickup:"San Mateo",dropoff:"COMMONWEALTH",fare:107,vehicle:"motorcycle",bookingType:"delivery"))
    }
    func testPickupDistanceNeverUsedAsDeliveryDistance() {
        let b=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,pickupDistanceKm:12.9)
        XCTAssertNil(b.farePerPickupKm)
    }
    func testPartialCardDoesNotBecomeComplete() {
        let lines=[OCRLine(text:"(~12.9 km) Pick Up Now"),OCRLine(text:"San Mateo"),OCRLine(text:"₱107.00"),OCRLine(text:"Motorcycle"),OCRLine(text:"Delivery")]
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count,1)
        XCTAssertEqual(result.bookings[0].status,.partial)
    }
    func testFareExtractionAndPickupDistance() {
        let b=LalamoveOCRParser.parse([OCRLine(text:"(~12.9 km) Pick Up Now"),OCRLine(text:"San Mateo"),OCRLine(text:"Commonwealth"),OCRLine(text:"Motorcycle"),OCRLine(text:"Delivery"),OCRLine(text:"₱107.00")]).bookings[0]
        XCTAssertEqual(b.fare,107)
        XCTAssertEqual(b.pickupDistanceKm,12.9)
    }
    func testNoCoordinatesRequiresVerification() {
        let r=RouteCompatibilityEngine.evaluate(referencePickup:nil,referenceDropoff:nil,candidatePickup:nil,candidateDropoff:nil)
        XCTAssertEqual(r.label,"POSSIBLE COMPATIBILITY")
    }

    func testThreeVisibleCardsKeepPartialThirdSeparate() {
        let text=["(~12.9 km) Pick Up Now","Delivery","Regular","San Mateo","Commonwealth","Motorcycle","₱107.00",
                  "(~4.3 km) Pick Up Now","Delivery","Regular","San Mateo","San Mateo","Motorcycle","2kls talaba ipipick up","₱81.00",
                  "(~5.8 km) Pick Up Now"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.bookings.count,3)
        XCTAssertEqual(result.bookings[0].fare,107)
        XCTAssertEqual(result.bookings[1].fare,81)
        XCTAssertEqual(result.bookings[2].status,.partial)
    }
    func testExpandedScreenKeepsFullAddresses() {
        let text=["Pick Up Now","~6.8 km from you","San Mateo","Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
                  "Commonwealth","544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
                  "Motorcycle","₱107.00","Settle with customer","Report Order"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.expanded)
        XCTAssertTrue(result.bookings.first?.pickupFullAddress?.contains("Infinite Powertech") == true)
        XCTAssertTrue(result.bookings.first?.dropoffFullAddress?.contains("Quezon City") == true)
    }
    func testPSGCResolverKeepsAmbiguousLocalityAmbiguous() throws {
        let url=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let resolver=try PSGCResolver(data:Data(contentsOf:url))
        XCTAssertGreaterThan(resolver.recordCount,20_000)
        if case .ambiguous = resolver.resolve("San Mateo") { } else { XCTFail("San Mateo must remain ambiguous without parent context") }
    }
    func testProfitDoesNotInventFuelCost() {
        let b=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107)
        let p=ProfitCalculator.calculate(bookings:[b],deliveryDistanceKm:nil,durationHours:nil,fuelPricePerLiter:nil,kmPerLiter:nil)
        XCTAssertEqual(p.grossFare,107); XCTAssertNil(p.fuelCost); XCTAssertNil(p.netAfterFuel)
    }
    func testSameLocalityLabelsAreRetainedForFullAddressVerification() {
        let lines=["(~4.3 km) Pick Up Now","Delivery","Regular","San Mateo","San Mateo","Motorcycle","2kls talaba ipipick up","₱81.00"].map{OCRLine(text:$0)}
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count,1)
        XCTAssertTrue(result.bookings[0].isComplete)
        XCTAssertEqual(result.bookings[0].pickup,"San Mateo")
        XCTAssertEqual(result.bookings[0].dropoff,"San Mateo")
        XCTAssertEqual(result.bookings[0].notes,"2kls talaba ipipick up")
        XCTAssertEqual(result.bookings[0].pickupDistanceKm,4.3)
    }

    func testFarePairAndAdditionalFareArePreserved() {
        let pair=LalamoveOCRParser.parseFareComponents("₱100.00 + ₱25.00")
        XCTAssertEqual(pair?.base,100)
        XCTAssertEqual(pair?.additional,25)
        XCTAssertEqual(pair?.total,125)
    }

    func testPesoSignReadAsLetterPStillExtractsFare() {
        // The supplied iPhone screenshots may OCR the peso glyph as a plain P.
        XCTAssertEqual(LalamoveOCRParser.parseFareComponents("P107.00")?.total,107)
        XCTAssertEqual(LalamoveOCRParser.parseFareComponents("P81.00")?.total,81)
        let pair=LalamoveOCRParser.parseFareComponents("P100.00 + P25.00")
        XCTAssertEqual(pair?.total,125)
    }

    func testAcceptedScreenCapturesBookingCodeAndPaymentMethod() {
        let text=["Pick Up At 9:42 AM","# 36333344750352044516","Delivery","Regular",
                  "Infinite Powertech Warehouse","Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
                  "544 B,Kamagong Street","544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
                  "Motorcycle","₱107.00","Collect Cash","Call Customer","Proof of delivery required at dropoff."]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.accepted)
        XCTAssertEqual(result.bookings.first?.status,.accepted)
        XCTAssertEqual(result.bookings.first?.bookingCode,"36333344750352044516")
        XCTAssertEqual(result.bookings.first?.paymentMethod,"Collect cash")
        XCTAssertTrue(result.bookings.first?.pickupFullAddress?.contains("San Mateo") == true)
        XCTAssertTrue(result.bookings.first?.dropoffFullAddress?.contains("Quezon City") == true)
    }

    func testExpandedBookingMatchesCollapsedCardOnlyWhenUnique() {
        let collapsed=Booking(bookingCode:nil,pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",confidence:0.9,status:.detected)
        let expanded=Booking(pickup:"Infinite Powertech Warehouse, 1850 San Mateo, Philippines",dropoff:"Commonwealth, 544 B Kamagong St, Quezon City",fare:107,vehicleType:"Motorcycle",confidence:0.9,status:.needsVerification,screenKind:.expanded)
        XCTAssertEqual(BookingMatcher.uniqueMatch(for:expanded,among:[collapsed]),0)
        XCTAssertNil(BookingMatcher.uniqueMatch(for:expanded,among:[collapsed,collapsed]))
    }

    func testLegacyCentroidDatasetIsExplicitlyApproximate() throws {
        let url=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let resolver=try CentroidResolver(data:Data(contentsOf:url))
        XCTAssertGreaterThan(resolver.recordCount,50)
        guard case .unique(let commonwealth)=resolver.resolve("Commonwealth") else { return XCTFail("Expected one Commonwealth centroid") }
        XCTAssertEqual(commonwealth.coordinateStatus,"APPROXIMATE_CENTROID")
        XCTAssertNotNil(commonwealth.point)
    }

    func testThirtyVisibleCardsAreSegmentedIndependently() {
        var lines:[OCRLine]=[]
        for i in 0..<30 {
            lines += [OCRLine(text:"(~2.5 km) Pick Up Now"),OCRLine(text:"Delivery"),OCRLine(text:"Regular"),
                      OCRLine(text:"San Mateo"),OCRLine(text:"Commonwealth"),OCRLine(text:"Motorcycle"),OCRLine(text:"₱\(100+i).00")]
        }
        let result=LalamoveOCRParser.parse(lines)
        XCTAssertEqual(result.bookings.count,30)
        XCTAssertTrue(result.bookings.allSatisfy{$0.isComplete})
    }

    func testPSGCAddressContextDisambiguatesSanMateoRizal() throws {
        let url=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let resolver=try PSGCResolver(data:Data(contentsOf:url))
        guard case .unique(let record)=resolver.resolveFromAddress("San Mateo, Rizal, Philippines") else { return XCTFail("Province context should narrow the locality") }
        XCTAssertEqual(record.level,"Mun")
        XCTAssertEqual(resolver.hierarchy(record).first(where:{$0.level == "Prov"})?.name,"Rizal")
    }

    func testApproximateRouteMatchNeverClaimsVerifiedRoadCompatibility() {
        let result=RouteCompatibilityEngine.evaluate(
            referencePickup:GeoPoint(latitude:14.6982,longitude:121.1236),
            referenceDropoff:GeoPoint(latitude:14.6910,longitude:121.0830),
            candidatePickup:GeoPoint(latitude:14.6917,longitude:121.0950),
            candidateDropoff:GeoPoint(latitude:14.6426,longitude:121.0380))
        XCTAssertTrue(result.requiresVerification)
        XCTAssertTrue(result.basis.contains("NOT ROAD ROUTING"))
    }

    func testGeographicActivityIsObservedHistoryNotDemandForecast() {
        let bookings=[Booking(pickup:"Commonwealth",dropoff:"Quezon Avenue",fare:100),Booking(pickup:"Commonwealth",dropoff:"Diliman",fare:120)]
        let summary=GeographicIntelligence.analyze(bookings:bookings,centroids:nil)
        XCTAssertEqual(summary.pickupObservations,2)
        XCTAssertEqual(summary.hotspots.first?.observations,2)
        XCTAssertTrue(summary.disclaimer.contains("Not a live heatmap"))
    }

    func testAmbiguousSanMateoDoesNotReceiveLegacyCentroidCoordinates() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let reference=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,status:.accepted)
        let candidate=Booking(pickup:"San Mateo",dropoff:"Quezon Avenue",fare:120)
        let recs=RecommendationEngine.referenceBased(reference:reference,candidates:[candidate],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.isEmpty, "Reference-based routing must not use an ambiguous short locality centroid.")
    }

    func testReferenceFreeSimilarRoutesAreSurfacedWithAmbiguityWarning() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let a=Booking(pickup:"San Mateo",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",firstSeen:Date(timeIntervalSince1970:1))
        let b=Booking(pickup:"San Mateo",dropoff:"Quezon Avenue",fare:120,vehicleType:"Motorcycle",firstSeen:Date(timeIntervalSince1970:2))
        let recs=RecommendationEngine.referenceFree(bookings:[a,b],centroids:centroids,psgc:psgc)
        XCTAssertEqual(recs.count,1)
        XCTAssertTrue(recs[0].requiresVerification)
        XCTAssertTrue(recs[0].label.contains("VERIFY ADDRESS"))
        XCTAssertTrue(recs[0].basis.contains("NOT ROAD ROUTING"))
    }

    func testReferenceBasedEngineCanRecommendMultipleBookingCombination() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let ref=Booking(pickup:"Quezon City",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let one=Booking(pickup:"Commonwealth",dropoff:"Quezon Avenue",fare:120,vehicleType:"Motorcycle")
        let two=Booking(pickup:"Quezon Avenue",dropoff:"Diliman",fare:130,vehicleType:"Motorcycle")
        let recs=RecommendationEngine.referenceBased(reference:ref,candidates:[one,two],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.contains{$0.candidateBookingIDs.count==2})
        XCTAssertTrue(recs.allSatisfy{$0.requiresVerification == false})
    }

    func testReferenceBasedEngineRejectsKnownVehicleMismatch() throws {
        let psgcURL=Bundle.module.url(forResource:"luzon_psgc_3q_2026",withExtension:"json")!
        let centroidURL=Bundle.module.url(forResource:"geographic_centroids_legacy",withExtension:"json")!
        let psgc=try PSGCResolver(data:Data(contentsOf:psgcURL))
        let centroids=try CentroidResolver(data:Data(contentsOf:centroidURL))
        let ref=Booking(pickup:"Quezon City",dropoff:"Commonwealth",fare:107,vehicleType:"Motorcycle",status:.accepted)
        let car=Booking(pickup:"Commonwealth",dropoff:"Quezon Avenue",fare:120,vehicleType:"Car")
        let recs=RecommendationEngine.referenceBased(reference:ref,candidates:[car],centroids:centroids,psgc:psgc)
        XCTAssertTrue(recs.isEmpty)
    }

    func testProvidedIPhoneAvailableBookingScreenshotLayout() {
        let text=["Home Along the way Above 50 km",
            "(~12.9 km) Pick Up Now","Delivery","Regular","San Mateo","Commonwealth","Motorcycle","₱107.00",
            "(~4.3 km) Pick Up Now","Delivery","Regular","San Mateo","San Mateo","Motorcycle","2kls talaba ipipick up","₱81.00",
            "(~5.8 km) Pick Up Now","Find more orders at these locations"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.list)
        XCTAssertEqual(result.bookings.count,3)
        XCTAssertEqual(result.bookings[0].pickupDistanceKm,12.9)
        XCTAssertEqual(result.bookings[0].fare,107)
        XCTAssertEqual(result.bookings[1].notes,"2kls talaba ipipick up")
        XCTAssertEqual(result.bookings[1].pickup,result.bookings[1].dropoff)
        XCTAssertEqual(result.bookings[2].status,.partial)
    }

    func testProvidedIPhoneExpandedBookingScreenshotLayout() {
        let text=["Pick Up Now","~6.8 km from you","San Mateo",
            "Infinite Powertech Warehouse, 1850 San Mateo, Philippines","Commonwealth",
            "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines","Motorcycle","₱107.00",
            "Settle with customer","Does this order look suspicious?","Report Order","Slide to Take Order"]
        let result=LalamoveOCRParser.parse(text.map{OCRLine(text:$0)})
        XCTAssertEqual(result.screenKind,.expanded)
        XCTAssertEqual(result.bookings.first?.pickupDistanceKm,6.8)
        XCTAssertEqual(result.bookings.first?.fare,107)
        XCTAssertTrue(result.bookings.first?.pickupFullAddress?.contains("Infinite Powertech") == true)
        XCTAssertTrue(result.bookings.first?.dropoffFullAddress?.contains("Quezon City") == true)
        XCTAssertNil(result.bookings.first?.notes)
    }

    func testAcceptedBookingDetectedFromActualIPhoneAcceptedScreenMarkers() {
        let lines = [
            "Pick Up At 9:42 AM", "Client: Roy Vincent", "₱107.00", "Today, 9:42 AM",
            "# 36333344750352044516", "Delivery", "Regular", "Proof of delivery required at dropoff",
            "Infinite Powertech Warehouse", "Infinite Powertech Warehouse, 1850 San Mateo, Philippines",
            "544 B, Kamagong Street", "544 B Kamagong St, Quezon City, 1121 Metro Manila, Philippines",
            "Motorcycle", "Collect Cash", "Call Customer"
        ].map { OCRLine(text: $0) }
        let result = AcceptedBookingDetector.detect(lines: lines)
        XCTAssertNotNil(result)
        XCTAssertEqual(result?.booking.status, .accepted)
        XCTAssertEqual(result?.bookingCode, "36333344750352044516")
        XCTAssertEqual(result?.booking.fare, 107)
        XCTAssertTrue(result?.evidence.contains("POST_ACCEPTANCE_PICKUP_TIME") == true)
    }

    func testOrdinaryAvailableBookingCardCannotBeMistakenAsAccepted() {
        let lines = ["(~12.9 km) Pick Up Now", "Delivery", "Regular", "San Mateo", "Commonwealth", "Motorcycle", "₱107.00"].map { OCRLine(text: $0) }
        XCTAssertNil(AcceptedBookingDetector.detect(lines: lines))
    }

    func testFirstAcceptedBookingIsProtectedUntilExplicitReplacementOrClear() async throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let store = AcceptedBookingReferenceStore(fileURL: dir.appendingPathComponent("reference.json"))
        let first = Booking(bookingCode: "ORDER-000001", pickup: "San Mateo, Rizal", dropoff: "Commonwealth", fare: 107, status: .accepted, screenKind: .accepted)
        let second = Booking(bookingCode: "ORDER-000002", pickup: "San Mateo, Rizal", dropoff: "Quezon Avenue", fare: 120, status: .accepted, screenKind: .accepted)
        let d1 = AcceptedBookingDetection(booking: first, bookingCode: first.bookingCode, matchedPreAcceptanceBookingID: nil, confidence: 0.95, evidence: ["test"])
        let d2 = AcceptedBookingDetection(booking: second, bookingCode: second.bookingCode, matchedPreAcceptanceBookingID: nil, confidence: 0.95, evidence: ["test"])
        let acceptedFirst = try await store.recordFirstAccepted(d1)
        let acceptedSecond = try await store.recordFirstAccepted(d2)
        XCTAssertTrue(acceptedFirst)
        XCTAssertFalse(acceptedSecond)
        let protectedReference = await store.current()
        XCTAssertEqual(protectedReference?.bookingCode, "ORDER-000001")
        try await store.replace(with: second)
        let replacedReference = await store.current()
        XCTAssertEqual(replacedReference?.bookingCode, "ORDER-000002")
        try await store.clear()
        let clearedReference = await store.current()
        XCTAssertNil(clearedReference)
        try? FileManager.default.removeItem(at: dir)
    }

    func testBookingHistoryPolicyKeepsSevenDaysAndCapsAt1500() {
        let now=Date(timeIntervalSince1970:1_000_000)
        let recent=(0..<1520).map { index in
            Booking(id:"b\(index)",pickup:"A\(index)",dropoff:"B\(index)",fare:100,
                    firstSeen:now.addingTimeInterval(-Double(index)),lastSeen:now.addingTimeInterval(-Double(index)))
        }
        let old=Booking(id:"old",pickup:"Old",dropoff:"History",fare:100,
                        firstSeen:now.addingTimeInterval(-8*24*3600),lastSeen:now.addingTimeInterval(-8*24*3600))
        let pruned=BookingHistoryPolicy.prune(recent+[old],now:now)
        XCTAssertEqual(pruned.count,1500)
        XCTAssertFalse(pruned.contains{$0.id=="old"})
        XCTAssertEqual(pruned.first?.id,"b0")
    }

}
