import ReplayKit
import Vision
import CoreMedia
import CoreVideo
import Foundation

/// Receives only frames explicitly shared through the iOS Broadcast UI.
/// No audio is processed and no screen frames are permanently archived.
private struct OCRLine: Codable {
    let text: String
    let confidence: Double
    let x: Double
    let y: Double
    let width: Double
    let height: Double
}

final class SampleHandler: RPBroadcastSampleHandler {
    private let appGroup = "group.ph.riderwise.ai"
    private let defaultInterval: TimeInterval = 2.5
    private var lastSampleTime: TimeInterval = 0
    private var sequence: UInt64 = 0

    override func broadcastStarted(withSetupInfo setupInfo: [String : NSObject]?) {
        writeStatus(active: true, message: "Broadcast active. Switch to Lalamove to analyze visible bookings.")
    }

    override func broadcastPaused() {
        writeStatus(active: false, message: "Broadcast paused by iOS.")
    }

    override func broadcastResumed() {
        writeStatus(active: true, message: "Broadcast resumed.")
    }

    override func broadcastFinished() {
        writeStatus(active: false, message: "Broadcast stopped. No further screen frames are being analyzed.")
    }

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType: RPSampleBufferType) {
        guard sampleBufferType == .video,
              CMSampleBufferIsValid(sampleBuffer),
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let now = ProcessInfo.processInfo.systemUptime
        let interval = configuredInterval()
        guard now - lastSampleTime >= interval else { return }
        lastSampleTime = now

        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        request.recognitionLanguages = ["en-US"]
        do {
            try VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up).perform([request])
            let lines: [OCRLine] = (request.results ?? []).compactMap { observation in
                guard let candidate = observation.topCandidates(1).first else { return nil }
                let box = observation.boundingBox
                return OCRLine(text: candidate.string, confidence: Double(candidate.confidence),
                               x: box.minX, y: box.minY, width: box.width, height: box.height)
            }
            sequence &+= 1
            let payload = Payload(id: "\(sequence)-\(Int(now * 1000))", lines: lines)
            write(payload: payload)
        } catch {
            writeStatus(active: true, message: "On-device OCR error: \(error.localizedDescription)")
        }
    }

    private func configuredInterval() -> TimeInterval {
        guard let url = sharedURL("scan-interval.json"),
              let data = try? Data(contentsOf: url),
              let value = try? JSONDecoder().decode(ScanInterval.self, from: data).value else { return defaultInterval }
        return min(10, max(2.5, value))
    }

    private func sharedURL(_ name: String) -> URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroup)?.appendingPathComponent(name)
    }

    private func writeStatus(active: Bool, message: String) {
        guard let url = sharedURL("broadcast-status.json") else { return }
        let value = Status(active: active, message: message)
        guard let data = try? JSONEncoder().encode(value) else { return }
        try? data.write(to: url, options: .atomic)
    }

    private func write(payload: Payload) {
        guard let url = sharedURL("ocr-queue.json") else { return }
        let decoder = JSONDecoder()
        var queue = (try? Data(contentsOf: url)).flatMap { try? decoder.decode([Payload].self, from: $0) } ?? []
        queue.append(payload)
        if queue.count > 120 { queue.removeFirst(queue.count - 120) }
        guard let data = try? JSONEncoder().encode(queue) else { return }
        try? data.write(to: url, options: .atomic)
    }

    private struct ScanInterval: Codable { let value: TimeInterval }
    private struct Status: Codable { let active: Bool; let message: String }
    private struct Payload: Codable { let id: String; let lines: [OCRLine] }
}
