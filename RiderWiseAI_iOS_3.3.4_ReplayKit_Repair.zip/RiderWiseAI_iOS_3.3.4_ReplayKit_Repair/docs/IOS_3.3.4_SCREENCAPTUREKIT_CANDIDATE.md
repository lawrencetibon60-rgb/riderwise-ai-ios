# RiderWise AI iOS 3.3.4 repair notes

The initial ScreenCaptureKit candidate failed its Xcode 27.1 simulator build because `ScreenCaptureKit` could not be resolved as an iOS app target module. This candidate has been corrected to remove the ScreenCaptureKit import and restore the user-approved ReplayKit Broadcast Upload Extension architecture from the earlier 3.3.3 source.

ReplayKit is deprecated in the current SDK. Deprecation is not proof of runtime support or future compatibility. The source must pass the Xcode 27.1 simulator build, unsigned device archive, and physical iPhone broadcast/OCR test before release.

The native PiP dashboard remains a separate RiderWise-rendered dashboard. OCR interval remains configurable with a 2.5-second minimum.
