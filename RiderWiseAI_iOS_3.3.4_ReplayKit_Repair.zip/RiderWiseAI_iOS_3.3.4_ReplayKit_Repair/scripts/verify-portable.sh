#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test
while IFS= read -r -d '' f; do
  swiftc -frontend -parse "$f" >/dev/null
done < <(find iOSApp Sources/RiderWiseCore BroadcastExtension -type f -name '*.swift' -print0)
python3 - <<'PY'
import gzip, json, pathlib, plistlib, collections
root=pathlib.Path('.')
plist=plistlib.loads((root/'iOSApp/Info.plist').read_bytes())
ent=plistlib.loads((root/'iOSApp/RiderWiseAI.entitlements').read_bytes())
assert 'group.ph.riderwise.ai' in ent.get('com.apple.security.application-groups', [])
project=(root/'project.yml').read_text()
assert 'RiderWiseBroadcast:' in project
assert 'ScreenCaptureKit' not in (root/'iOSApp/ScreenCaptureManager.swift').read_text()
assert (root/'BroadcastExtension/SampleHandler.swift').is_file()
ext_ent=plistlib.loads((root/'BroadcastExtension/RiderWiseBroadcast.entitlements').read_bytes())
assert 'group.ph.riderwise.ai' in ext_ent.get('com.apple.security.application-groups', [])
ext_plist=plistlib.loads((root/'BroadcastExtension/Info.plist').read_bytes())
assert ext_plist['NSExtension']['NSExtensionPointIdentifier']=='com.apple.broadcast-services-upload'
geo=root/'iOSApp/Resources/Geography'
for name in ['luzon_psgc_3q_2026.json','luzon_psgc_3q_2026.json.gz','geographic_centroids_legacy.json','riderwise_upgrade_config.json']:
    assert (geo/name).is_file(), f'Missing app geography resource: {name}'
with gzip.open(root/'Sources/RiderWiseCore/luzon_psgc_3q_2026.json.gz','rt',encoding='utf-8') as f:
    data=json.load(f)
records=data['records']
codes={r['psgc'] for r in records}
counts=collections.Counter(r['level'] for r in records)
assert len(records)==21330 and len(codes)==len(records)
assert dict(counts)=={'Reg':8,'Prov':38,'City':77,'Mun':694,'SubMun':14,'Bgy':20499}
assert all(not r.get('parentPsgc') or r['parentPsgc'] in codes for r in records)
config=json.loads((geo/'riderwise_upgrade_config.json').read_text())
assert config['scan']['interval_ms']==2500
assert config['safety']['auto_accept_bookings'] is False
assert config['safety']['auto_reject_bookings'] is False
assert config['ai']['large_local_model_autostart'] is False
print('ReplayKit extension, App Group entitlements and safety config: PASS')
print('Geographic resources: PASS')
print('PSGC dataset: PASS (21,330 records, unique codes, valid parent links)')
PY
