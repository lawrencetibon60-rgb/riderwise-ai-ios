import AVFoundation
import AVKit
import CoreMedia
import CoreVideo
import SwiftUI
import UIKit

/// Renders RiderWise's own dashboard into Apple's native PiP surface.
/// It does not mirror or draw over another app's screen.
@MainActor
final class PiPVideoRenderer: NSObject, ObservableObject {
    @Published private(set) var isSupported = AVPictureInPictureController.isPictureInPictureSupported()
    @Published private(set) var isActive = false
    @Published private(set) var status = "PiP is ready when supported."
    @Published private(set) var isReady = false
    /// Last render dimensions reported by AVKit. PiP gestures and window sizing remain iOS-controlled.
    @Published private(set) var pipRenderSizeDescription = "Waiting for iOS PiP size"

    private var displayLayer: AVSampleBufferDisplayLayer?
    private var controller: AVPictureInPictureController?
    private var controlTimebase: CMTimebase?
    private var latestImage: UIImage?
    private var isPlaybackPaused = false

    override init() {
        super.init()
    }

    /// The sample-buffer layer must be hosted by a live UIKit view before it is used
    /// as a PiP content source. The SwiftUI host below attaches this layer.
    func attach(displayLayer: AVSampleBufferDisplayLayer) {
        if self.displayLayer === displayLayer { return }
        self.displayLayer = displayLayer
        displayLayer.videoGravity = .resizeAspect
        displayLayer.backgroundColor = UIColor.black.cgColor

        var timebase: CMTimebase?
        let hostClock = CMClockGetHostTimeClock()
        if CMTimebaseCreateWithSourceClock(
            allocator: kCFAllocatorDefault,
            sourceClock: hostClock,
            timebaseOut: &timebase
        ) == noErr, let timebase {
            CMTimebaseSetTime(timebase, time: CMClockGetTime(hostClock))
            CMTimebaseSetRate(timebase, rate: 1.0)
            displayLayer.controlTimebase = timebase
            self.controlTimebase = timebase
        }
        configureController()
        isReady = controller != nil
        if let latestImage { enqueue(latestImage) }
        status = isReady ? "PiP display surface is attached and ready." : "PiP could not initialize on this device."
    }

    func start(image: UIImage) {
        latestImage = image
        guard isSupported, let controller, displayLayer != nil else {
            status = "PiP display surface is not ready yet, or PiP is unavailable on this device."
            return
        }
        enqueue(image)
        if !controller.isPictureInPictureActive {
            controller.startPictureInPicture()
            status = "Starting RiderWise PiP…"
        }
    }

    func update(image: UIImage) {
        latestImage = image
        guard isSupported, displayLayer != nil, !isPlaybackPaused else { return }
        enqueue(image)
    }

    func stop() {
        controller?.stopPictureInPicture()
    }

    private func configureController() {
        guard isSupported, let displayLayer else { return }
        let source = AVPictureInPictureController.ContentSource(
            sampleBufferDisplayLayer: displayLayer,
            playbackDelegate: self
        )
        let pip = AVPictureInPictureController(contentSource: source)
        pip.delegate = self
        pip.requiresLinearPlayback = true
        pip.canStartPictureInPictureAutomaticallyFromInline = true
        controller = pip
    }

    private func enqueue(_ image: UIImage) {
        guard let displayLayer,
              let cgImage = image.cgImage,
              let pixelBuffer = makePixelBuffer(cgImage) else {
            status = "Could not render the PiP dashboard frame."
            return
        }
        var format: CMVideoFormatDescription?
        guard CMVideoFormatDescriptionCreateForImageBuffer(
            allocator: kCFAllocatorDefault,
            imageBuffer: pixelBuffer,
            formatDescriptionOut: &format
        ) == noErr, let format else { return }

        var timing = CMSampleTimingInfo(
            duration: CMTime(value: 1, timescale: 2),
            presentationTimeStamp: CMClockGetTime(CMClockGetHostTimeClock()),
            decodeTimeStamp: .invalid
        )
        var sample: CMSampleBuffer?
        guard CMSampleBufferCreateReadyWithImageBuffer(
            allocator: kCFAllocatorDefault,
            imageBuffer: pixelBuffer,
            formatDescription: format,
            sampleTiming: &timing,
            sampleBufferOut: &sample
        ) == noErr, let sample else {
            status = "Could not prepare PiP video frame."
            return
        }
        // Flush only a failed layer. A temporarily back-pressured layer should
        // retain its queued frames; flushing on every not-ready frame can cause
        // visible flicker and unnecessary decoder resets.
        let renderer = displayLayer.sampleBufferRenderer
        if renderer.status == .failed {
            renderer.flush(removingDisplayedImage: false, completionHandler: nil)
        }
        guard renderer.isReadyForMoreMediaData else { return }
        renderer.enqueue(sample)
    }

    private func makePixelBuffer(_ cgImage: CGImage) -> CVPixelBuffer? {
        let width = 640, height = 360
        let attrs: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]
        var output: CVPixelBuffer?
        guard CVPixelBufferCreate(
            kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
            attrs as CFDictionary, &output
        ) == kCVReturnSuccess, let buffer = output else { return nil }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width, height: height, bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue |
                CGBitmapInfo.byteOrder32Little.rawValue
        ) else { return nil }
        context.interpolationQuality = .high
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        return buffer
    }

    static func makeDashboardFrame(
        reference: String,
        topRecommendation: String,
        detail: String,
        count: Int,
        scanning: Bool
    ) -> UIImage {
        let size = CGSize(width: 640, height: 360)
        return UIGraphicsImageRenderer(size: size).image { renderer in
            let c = renderer.cgContext
            c.setFillColor(UIColor(red: 0.055, green: 0.075, blue: 0.11, alpha: 1).cgColor)
            c.fill(CGRect(origin: .zero, size: size))

            func text(_ value: String, _ rect: CGRect, _ font: UIFont, _ color: UIColor) {
                (value as NSString).draw(in: rect, withAttributes: [
                    .font: font, .foregroundColor: color,
                    .paragraphStyle: {
                        let p = NSMutableParagraphStyle()
                        p.lineBreakMode = .byTruncatingTail
                        return p
                    }()
                ])
            }

            text("RIDERWISE AI", CGRect(x: 28, y: 22, width: 350, height: 30),
                 .boldSystemFont(ofSize: 22), .white)
            text(scanning ? "LIVE OCR" : "SCAN PAUSED",
                 CGRect(x: 470, y: 26, width: 145, height: 22),
                 .boldSystemFont(ofSize: 13), scanning ? .systemGreen : .systemOrange)

            c.setFillColor(UIColor(white: 1, alpha: 0.08).cgColor)
            c.fill(CGRect(x: 24, y: 70, width: 592, height: 76))
            text("ACCEPTED REFERENCE", CGRect(x: 42, y: 83, width: 300, height: 18),
                 .boldSystemFont(ofSize: 12), .systemTeal)
            text(reference.isEmpty ? "No accepted booking selected" : reference,
                 CGRect(x: 42, y: 105, width: 550, height: 28),
                 .boldSystemFont(ofSize: 18), .white)

            c.setFillColor(UIColor(red: 0.10, green: 0.27, blue: 0.22, alpha: 1).cgColor)
            c.fill(CGRect(x: 24, y: 164, width: 592, height: 112))
            text("TOP RECOMMENDATION", CGRect(x: 42, y: 178, width: 340, height: 18),
                 .boldSystemFont(ofSize: 12), .systemGreen)
            text(topRecommendation.isEmpty ? "Waiting for compatible bookings" : topRecommendation,
                 CGRect(x: 42, y: 205, width: 550, height: 30),
                 .boldSystemFont(ofSize: 21), .white)
            text(detail.isEmpty ? "New OCR results refresh this dashboard." : detail,
                 CGRect(x: 42, y: 240, width: 550, height: 24),
                 .systemFont(ofSize: 13), UIColor(white: 0.83, alpha: 1))
            text("\(count) recommendation(s) · Driver confirms every booking",
                 CGRect(x: 28, y: 312, width: 584, height: 22),
                 .systemFont(ofSize: 13), UIColor(white: 0.72, alpha: 1))
        }
    }
}

@MainActor
extension PiPVideoRenderer: AVPictureInPictureControllerDelegate {
    func pictureInPictureControllerDidStartPictureInPicture(_ controller: AVPictureInPictureController) {
        isActive = true
        status = "RiderWise PiP dashboard is active."
    }

    func pictureInPictureControllerDidStopPictureInPicture(_ controller: AVPictureInPictureController) {
        isActive = false
        status = "RiderWise PiP dashboard is closed."
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        failedToStartPictureInPictureWithError error: Error
    ) {
        isActive = false
        status = "PiP failed: \(error.localizedDescription)"
    }
}

@MainActor
extension PiPVideoRenderer: AVPictureInPictureSampleBufferPlaybackDelegate {
    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        setPlaying playing: Bool
    ) {
        isPlaybackPaused = !playing
        if let controlTimebase {
            CMTimebaseSetRate(controlTimebase, rate: playing ? 1.0 : 0.0)
        }
        if playing, let latestImage { enqueue(latestImage) }
        controller.invalidatePlaybackState()
    }

    func pictureInPictureControllerIsPlaybackPaused(
        _ controller: AVPictureInPictureController
    ) -> Bool { isPlaybackPaused }

    func pictureInPictureControllerTimeRangeForPlayback(
        _ controller: AVPictureInPictureController
    ) -> CMTimeRange {
        // This is a continuously refreshed live dashboard, not a finite video clip.
        CMTimeRange(start: .zero, duration: .positiveInfinity)
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        didTransitionToRenderSize newRenderSize: CMVideoDimensions
    ) {
        // AVKit reports the native PiP window's new render size after system-managed
        // gestures (for example, a size change). Never intercept or replace those gestures.
        pipRenderSizeDescription = "\(newRenderSize.width) × \(newRenderSize.height)"
        // Refresh the live dashboard after the transition so the latest information
        // remains visible at the new system-selected PiP size.
        if let latestImage, !isPlaybackPaused {
            enqueue(latestImage)
        }
    }

    func pictureInPictureController(
        _ controller: AVPictureInPictureController,
        skipByInterval interval: CMTime,
        completion completionHandler: @escaping @Sendable () -> Void
    ) {
        // A live dashboard has no seekable timeline; always finish the system request.
        completionHandler()
    }

    nonisolated func pictureInPictureControllerShouldProhibitBackgroundAudioPlayback(
        _ controller: AVPictureInPictureController
    ) -> Bool {
        true
    }
}


/// UIKit host for AVSampleBufferDisplayLayer. Keeping the layer in the view hierarchy
/// gives AVKit a real render surface for its sample-buffer PiP content source.
final class PiPSampleBufferDisplayView: UIView {
    override class var layerClass: AnyClass { AVSampleBufferDisplayLayer.self }
    var sampleBufferDisplayLayer: AVSampleBufferDisplayLayer {
        layer as! AVSampleBufferDisplayLayer
    }
}

struct PiPDisplayLayerHost: UIViewRepresentable {
    @ObservedObject var renderer: PiPVideoRenderer

    func makeUIView(context: Context) -> PiPSampleBufferDisplayView {
        let view = PiPSampleBufferDisplayView(frame: .zero)
        renderer.attach(displayLayer: view.sampleBufferDisplayLayer)
        return view
    }

    func updateUIView(_ uiView: PiPSampleBufferDisplayView, context: Context) {
        renderer.attach(displayLayer: uiView.sampleBufferDisplayLayer)
    }
}
