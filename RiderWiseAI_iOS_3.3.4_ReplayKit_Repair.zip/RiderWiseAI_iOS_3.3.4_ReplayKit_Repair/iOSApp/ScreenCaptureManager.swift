import Foundation
import Combine
import SwiftUI
import ReplayKit
import RiderWiseCore

/// Starts Apple's user-approved ReplayKit broadcast extension. iOS displays its own
/// broadcast confirmation UI; the app never captures another app's screen silently.
@MainActor final class ScreenCaptureManager: ObservableObject {
    @Published private(set) var isCapturing = false
    @Published private(set) var status = "Screen broadcast is off. Tap Start and approve the iOS broadcast prompt."
    @Published var scanInterval: TimeInterval = 2.5 {
        didSet { writeScanInterval() }
    }
    @Published var showBroadcastPicker = false
    @Published var showStopInstructions = false
    var onOCRLines: (([OCRLine]) async -> Void)?

    private let appGroup = "group.ph.riderwise.ai"
    private var pollTask: Task<Void, Never>?
    private var processedPayloadIDs = Set<String>()
    private var processedPayloadOrder: [String] = []

    func presentSystemPicker() {
        showBroadcastPicker = true
        status = "Tap Start Broadcast in Apple's system panel, then switch to Lalamove. You remain in control of screen sharing."
    }

    /// Start monitoring even when RiderWise is reopened while an iOS broadcast is already active.
    func beginMonitoring() { startPolling() }

    func pickerPresented() { startPolling() }

    func stop() {
        // iOS owns ReplayKit broadcast termination; an app button cannot terminate the system broadcast.
        status = "The iOS broadcast is still controlled by iOS. Open Control Center → Screen Recording → Stop Broadcast."
        showStopInstructions = true
    }

    private func writeScanInterval() {
        guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroup) else { return }
        let url = container.appendingPathComponent("scan-interval.json")
        let data = try? JSONEncoder().encode(ScanInterval(value: scanInterval))
        if let data { try? data.write(to: url, options: .atomic) }
    }

    private func startPolling() {
        guard pollTask == nil else { return }
        pollTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let self else { break }
                await self.readLatestFrame()
                try? await Task.sleep(for: .seconds(1))
            }
        }
    }

    private func readLatestFrame() async {
        guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroup) else {
            status = "App Group is not available. The app's App Group entitlement must be enabled before broadcast can exchange OCR data."
            return
        }
        let statusURL = container.appendingPathComponent("broadcast-status.json")
        if let data = try? Data(contentsOf: statusURL),
           let state = try? JSONDecoder().decode(BroadcastStatus.self, from: data) {
            isCapturing = state.active
            if state.active {
                showBroadcastPicker = false
                status = String(format: "User-authorized Lalamove broadcast active · on-device OCR every %.1f seconds", scanInterval)
            } else if !state.message.isEmpty {
                status = state.message
            }
        }
        let frameURL = container.appendingPathComponent("ocr-queue.json")
        guard let data = try? Data(contentsOf: frameURL),
              let payloads = try? JSONDecoder().decode([BroadcastOCRPayload].self, from: data) else { return }
        let now = Date()
        for payload in payloads {
            guard !payload.id.isEmpty, processedPayloadIDs.insert(payload.id).inserted else { continue }
            processedPayloadOrder.append(payload.id)
            // Keep the in-memory de-duplication window bounded. The extension queue itself
            // is capped at 120 entries, so retaining 240 IDs covers the complete queue.
            if processedPayloadOrder.count > 240 {
                let expired = processedPayloadOrder.removeFirst()
                processedPayloadIDs.remove(expired)
            }
            // A restarted app must not replay old offers from the persisted App Group queue.
            if let createdAt = payload.createdAt, now.timeIntervalSince(createdAt) > 20 { continue }
            if !payload.lines.isEmpty { await onOCRLines?(payload.lines) }
        }
    }
}

private struct ScanInterval: Codable { let value: TimeInterval }
private struct BroadcastStatus: Decodable {
    let active: Bool
    let message: String
}
private struct BroadcastOCRPayload: Decodable {
    let id: String
    let lines: [OCRLine]
    let createdAt: Date?
}

struct RiderWiseBroadcastPicker: UIViewRepresentable {
    let onReady: () -> Void
    func makeUIView(context: Context) -> RPSystemBroadcastPickerView {
        let picker = RPSystemBroadcastPickerView(frame: .zero)
        picker.preferredExtension = "ph.riderwise.ai.broadcast"
        picker.showsMicrophoneButton = false
        DispatchQueue.main.async { onReady() }
        return picker
    }
    func updateUIView(_ uiView: RPSystemBroadcastPickerView, context: Context) {}
}
